((buffer-size . 261) (buffer-checksum . "2f28da95b0552d3258963e1649c24eafc14864f5"))
((emacs-buffer-undo-list (261 . 262) nil ("
" . -261) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 248) . -1) ((marker . 248) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker . 261) . -1) ((marker) . -1) 262 (t 26015 21103 589738 639000) nil (218 . 225) nil (")" . 218) nil ("(" . 218) nil ("json" . 218) ((marker . 261) . -3) (t 26015 21096 873072 437000) nil (apply -2 151 200 undo--wrap-and-run-primitive-undo 151 200 ((153 . 155))) nil (nil rear-nonsticky nil 199 . 200) ("
" . -244) (197 . 245) 174 nil (173 . 175) (t 26015 21084 663073 282000) nil (")" . 173) nil ("(" . 173) ((marker . 248) . -1) (t 26015 21063 753074 727000) nil (168 . 175) (t 26015 20951 183082 502000) nil (169 . 170) ("/" . -169) ((marker . 248) . -1) ("/" . -170) ((marker . 248) . -1) 171 (163 . 171) ("p" . -163) ((marker . 248) . -1) ("n" . -164) ((marker . 248) . -1) ("s" . -165) ((marker . 248) . -1) ("e" . -166) ((marker . 248) . -1) 167 (160 . 167) (t 26015 20587 123107 678000) nil (194 . 195) nil ("_" . -194) 195 (183 . 195) (182 . 183) (180 . 181) (174 . 180) (172 . 174) (171 . 172) (168 . 171) ("," . -168) ("p" . -169) ("s" . -170) 171 (153 . 171) (t 26015 20544 526443 959000) nil (151 . 154) (t 26015 20544 526443 959000) ("
" . 151) (152 . 152) ("    " . 151) nil (150 . 155) (135 . 150) ("s" . -135) 136 (119 . 136) (118 . 119) (117 . 118) (t 26015 20531 786444 839000) 100 nil (17 . 28) (16 . 17) (t 26015 20467 629782 607000) 15 nil (105 . 106) nil (101 . 105) nil (17 . 18) 74 nil (nil rear-nonsticky nil 74 . 75) (nil fontified nil 17 . 75) (17 . 75) nil (41 . 42) (39 . 41) (18 . 39) (16 . 18) (1 . 16) nil ("import leetcode

configuration = leetcode.Configuration()
configuration.api_key[\"x-csrftoken\"] = csrf_token
configuration.api_key[\"csrftoken\"] = csrf_token
configuration.api_key[\"LEETCODE_SESSION\"] = leetcode_session
configuration.api_key[\"Referer\"] = \"https://leetcode.com\"
configuration.debug = False

api_instance = leetcode.DefaultApi(leetcode.ApiClient(configuration))
graphql_request = leetcode.GraphqlQuery(
query=\"\"\"
     {
       user {
            username
            isCurrentUserPremium
         }
     }
     \"\"\",
variables=leetcode.GraphqlQueryVariables(),
)
print(api_instance.graphql_post(body=graphql_request))
" . 1) 6 (t 26015 19883 529822 922000) nil (319 . 320) nil (nil rear-nonsticky nil 627 . 628) (nil fontified nil 305 . 628) (305 . 628) nil (304 . 305) (303 . 304) (t 26015 19817 49827 507000) 302 nil (303 . 304) nil (nil rear-nonsticky nil 302 . 303) (nil fontified nil 18 . 303) (18 . 303) nil (16 . 18) (" " . -16) 17 (16 . 17) (" " . -16) 17 (8 . 17) ("p" . -8) ("y" . -9) ("t" . -10) ("h" . -11) 12 (7 . 12) (1 . 7) ("impor" . -1) 6 (1 . 6) (t 26015 18834 253228 740000)) (emacs-pending-undo-list ("
" . 9679) nil ("#+RESULTS:
: ((elpa . 2) (melpa . 1))
" . 9679) 9699 (t 26011 5107 188415 876000) nil (9690 . 9692) (9679 . 9715) ("
" . 9679) (9678 . 9680) 9663 (t 26011 5104 701749 380000) nil (9663 . 9664) ("2" . 9663) nil (9641 . 9642) ("3" . 9641) (t 26011 5094 248416 769000) nil ("
" . 9679) nil ("#+RESULTS:
: ((elpa . 3) (melpa . 2))
" . 9679) 9699 nil (9690 . 9692) (9679 . 9715) ("
" . 9679) (9678 . 9680) 9540 (t 26011 5086 938417 273000) nil ("
" . -9665) (" " . -9666) (" " . -9667) (" " . -9668) (" " . -9669) (" " . -9670) (" " . -9671) (" " . -9672) (" " . -9673) 9674 nil ("(\"nongnu\" . 1)" . 9674) nil ("
" . -9515) (" " . -9516) (" " . -9517) (" " . -9518) (" " . -9519) (" " . -9520) (" " . -9521) (" " . -9522) (" " . -9523) 9524 nil (")" . 9524) nil ("(\"nongnu\" . \"https://elpa.nongnu.org/nongnu/\"" . 9524) (t 26011 3016 665226 838000) nil ("
" . 40532) nil ("** Convert from Org to Markdown
#+begin_src emacs-lisp :tangle \"lisp/org-config.el\" :mkdirp yes
  (use-package ox-md
    :after 'org
    :ensure t)
#+end_src

#+RESULTS:
" . 40532) 40701 nil (40691 . 40703) ("
" . 40691) (40690 . 40692) 40650 nil ("
" . 40680) (t 26010 63537 492239 850000) nil (40677 . 40678) ("t" . -40677) ("
" . -40678) (" " . -40679) (" " . -40680) (" " . -40681) 40682 nil (" " . 40682) (t 26010 63531 552240 259000) nil (40683 . 40684) (40681 . 40683) 40628 (40678 . 40681) 40677 nil (40659 . 40664) (40654 . 40659) (" " . -40654) ("a" . -40655) ("f" . -40656) ("t" . -40657) ("e" . -40658) 40659 (40653 . 40659) (40651 . 40653) 40628 (40649 . 40651) (40649 . 40650) 40661 (t 26010 63517 132241 256000) nil (40653 . 40662) (40651 . 40653) 40628 (40648 . 40651) (40630 . 40648) (40627 . 40630) (t 26010 63504 355575 473000) 40564 nil ("#+begin_src emacs-lisp :tangle \"init.el\" :mkdirp yes
" . 40564) nil (nil rear-nonsticky nil 40616 . 40617) ("
" . -40680) (40616 . 40681) 40564 nil (40564 . 40627) ("<ini" . -40564) 40568 (40564 . 40568) (40563 . 40564) (40556 . 40563) (40535 . 40556) (40532 . 40535) (40531 . 40532) (40530 . 40531) (t 26010 7020 655041 453000) 40521 nil (16101 . 16102) nil (";" . 15729) (t 26007 32551 648260 196000) nil (51697 . 51813) ("
" . 51697) (51696 . 51698) 51287 (t 26007 32427 631585 938000) nil (51287 . 51288) (51281 . 51287) nil ("ivy" . 51281) (t 26007 32370 261582 430000) nil (51098 . 51682) ("  (use-package projectile
    :diminish projectile-mode
    :config (projectile-mode)
    :custom ((projectile-completion-system 'ivy))
    :custom ((projectile-completion-system 'ivy))
    :bind-keymap
    (\"C-c p\" . projectile-command-map)
    :init
    ;; NOTE: Set this to the folder where you keep your Git repos!
    (when (file-directory-p \"~/git\")
      (setq projectile-project-search-path '(\"~/git\")))
    (setq projectile-switch-project-action #'projectile-dired))

  ;; (use-package counsel-projectile
  ;;   :after projectile
  ;;   :config (counsel-projectile-mode))
" . 51098) 51188 nil (nil rear-nonsticky nil 51237 . 51238) ("
" . -51283) (51233 . 51284) 51228 (t 26007 32040 864895 592000) nil (51098 . 51629) ("  (use-package projectile
    :diminish projectile-mode
    :config (projectile-mode)
    :custom ((projectile-completion-system 'ivy))
    :bind-keymap
    (\"C-c p\" . projectile-command-map)
    :init
    ;; NOTE: Set this to the folder where you keep your Git repos!
    (when (file-directory-p \"~/git\")
      (setq projectile-project-search-path '(\"~/git\")))
    (setq projectile-switch-project-action #'projectile-dired))

  (use-package counsel-projectile
    :after projectile
    :config (counsel-projectile-mode))
" . -51098) 51620 (t 26007 31643 314871 258000) nil ("
" . 12116) nil ("        ;; Org Roam
        ;; (define-key evil-normal-state-map (kbd \"SPC n l\") 'org-roam-buffer-toggle)
        ;; (define-key evil-normal-state-map (kbd \"SPC n f\") 'org-roam-node-find)
        ;; (define-key evil-normal-state-map (kbd \"SPC n i\") 'org-roam-node-insert)

        ;; Manage buffers
        ;; (define-key evil-normal-state-map (kbd \"SPC k\") 'kill-buffer)
        ;; (define-key evil-normal-state-map (kbd \"SPC eb\") 'eval-buffer)

        ;; Manage windows
        ;; (evil-global-set-key 'normal (kbd \"C-a <backspace>\") 'delete-window)
        ;; (evil-global-set-key 'normal (kbd \"C-a \\\\\") 'split-window-right)
        ;; (evil-global-set-key 'normal (kbd \"C-a -\") 'split-window-below)
        ;; ;; Windmove keys for additional window navigation
        ;; (evil-global-set-key 'normal (kbd \"C-a h\")  'windmove-left)
        ;; (evil-global-set-key 'normal (kbd \"C-a l\")  'windmove-right)
        ;; (evil-global-set-key 'normal (kbd \"C-a k\")  'windmove-up)
        ;; (evil-global-set-key 'normal (kbd \"C-a j\")  'windmove-down)

        ;; ;; Use visual line motions even outside of visual-line-mode buffers
        ;; (evil-global-set-key 'motion \"j\" 'evil-next-visual-line)
        ;; (evil-global-set-key 'motion \"k\" 'evil-previous-visual-line)
" . 12117) 13313 (t 26007 31627 964870 317000) nil ("        ;; (define-key evil-insert-state-map (kbd \"C-g\") 'evil-normal-state)
        ;; (define-key evil-insert-state-map (kbd \"C-h\") 'evil-delete-backward-char-and-join)

        ;; Define key bindings for SPC followed by a single key
        ;; (define-key evil-normal-state-map (kbd \"SPC f\") 'find-file)
        ;; (define-key evil-normal-state-map (kbd \"SPC p\") 'projectile-command-map)
        ;; (define-key evil-normal-state-map (kbd \"SPC b\") 'switch-to-buffer)
        ;; (define-key evil-normal-state-map (kbd \"SPC s\") 'counsel-projectile-rg)

        ;; Background transparency
        ;; (define-key evil-normal-state-map (kbd \"SPC z\") 'toggle-transparency)
" . 11478) 12066 (t 25993 63154 774667 829000) nil ("* " . 286) ("
" . 286) nil (286 . 287) (286 . 288) (t 25993 63154 774667 829000) nil ("

* " . 285) nil (285 . 289) 286 (t 25993 63154 774667 829000) nil ("

" . 1351) (1352 . 1353) ("#+RESULTS:
ns-emacs-with-desktop-session
" . 1352) (": " . 1363) nil ("z" . 28541) nil (28541 . 28542) nil ("** " . 25946) nil ("

** " . 25980) nil (25980 . 25985) 25949 nil (25946 . 25949) nil (nil ws-butler-chg delete 24557 . 24558) (24556 . 24557) nil ("
" . 24556) nil (1363 . 1395) ("ns-emacs-with-desktop-session
" . 1363) (": " . 1363) nil (1363 . 1365) (1363 . 1393) (": ns-emacs-with-desktop-session
" . 1363) 1055 nil (1363 . 1365) (1352 . 1393) ("
" . 1352) (1351 . 1353) 1055 (t 25993 63154 774667 829000) nil ("

" . 1351) (1352 . 1353) ("#+RESULTS:
ns-emacs-with-desktop-session
" . 1352) (": " . 1363) nil (1 . 2) ("#" . 1) nil (1 . 2) ("#" . 1) nil ("
" . 26) nil (26 . 27) 1 nil ("
  " . 1109) (nil ws-butler-chg delete 1112 . 1113) (1110 . 1112) nil ("  " . -1110) 1112 (1109 . 1112) 1055 nil (1363 . 1365) (1352 . 1393) ("
" . 1352) (1351 . 1353) 1055 (t 25993 63154 774667 829000) nil ("󰓠" . 64) nil (64 . 65) nil ("<el" . 62) (nil ws-butler-chg delete 65 . 66) (62 . 65) ("#+begin_src emacs-lisp

#+end_src" . 62) nil (62 . 95) ("<el" . -62) 65 (62 . 65) nil (47 . 287) ("* Introduction

My config was heavily inspired by David Wilson's [[https://github.com/daviwil/emacs-from-scratch/blob/master/Emacs.org][emacs-from-scratch]] series. Check it out! To update this, just run =C-c C-v t= or =org-babel-tangle=.

" . 6707) nil (6707 . 6947) ("* Introduction

My config was heavily inspired by David Wilson's [[https://github.com/daviwil/emacs-from-scratch/blob/master/Emacs.org][emacs-from-scratch]] series. Check it out! To update this, just run =C-c C-v t= or =org-babel-tangle=.

" . 47) (t 25991 52135 972097 217000) nil (nil ws-butler-chg delete 1853 . 1854) (1852 . 1853) ("```u" . 1852) nil (1852 . 1856) ("#" . 1852) (t 25991 52135 972097 217000) nil (19460 . 19465) nil (19460 . 19469) nil ("init" . 19460) nil ("#+RESULTS:
: t
" . 15322) 15336 (t 25991 52101 992098 329000) nil (19393 . 19399) nil ("Fu" . 19393) nil ("*** " . 19385) (19389 . 19392) 19385 nil (nil rear-nonsticky nil 19384 . 19385) ("
" . -19768) (19384 . 19769) nil ("*** Undo Fu
Linear undo while maintaining all history.
#+begin_src emacs-lisp :tangle \"init.el\" :mkdirp yes
  (use-package undo-fu
    :general
    ('normal
     \"u\" #'undo-fu-only-undo
     \"U\" #'undo-fu-only-redo
     \"C-r\" #'undo-fu-only-redo))

  ;; ignores encrypted files by default
  (use-package undo-fu-session
    :init (undo-fu-session-global-mode))
#+end_src

#+RESULTS:

" . 9836) 9837 (t 25991 52023 502100 879000) nil (14465 . 14467) (14465 . 14467) (": t
" . 14465) 13192 (t 25991 52012 668767 898000) nil ("        ;; (setq evil-undo-system 'undo-fu)
" . 11704) 11715 (t 25991 52008 215434 708000) nil (14509 . 14511) (14509 . 14511) (": t
" . 14509) 11715 (t 25991 51909 235437 938000) nil (11303 . 14487) ("  ;; Bind C-x C-b to ibuffer
  (global-set-key (kbd \"C-x C-b\") 'ibuffer)
    ;; Make ESC quit prompts
    (global-set-key (kbd \"<escape>\") 'keyboard-escape-quit)

    (use-package evil
        :init
        (setq evil-want-integration t)
        (setq evil-want-keybinding nil)
        (setq evil-want-C-u-scroll t)
        (setq evil-want-C-i-jump nil)
        (setq evil-respect-visual-line-mode t)
        (setq evil-undo-system 'undo-fu)
        :config
        (evil-mode 1)
        (evil-set-initial-state 'messages-buffer-mode 'normal)
        (evil-set-initial-state 'dashboard-mode 'normal)
        ;; (define-key evil-insert-state-map (kbd \"C-g\") 'evil-normal-state)
        ;; (define-key evil-insert-state-map (kbd \"C-h\") 'evil-delete-backward-char-and-join)

        ;; Define key bindings for SPC followed by a single key
        ;; (define-key evil-normal-state-map (kbd \"SPC f\") 'find-file)
        ;; (define-key evil-normal-state-map (kbd \"SPC p\") 'projectile-command-map)
        ;; (define-key evil-normal-state-map (kbd \"SPC b\") 'switch-to-buffer)
        ;; (define-key evil-normal-state-map (kbd \"SPC s\") 'counsel-projectile-rg)

        ;; Background transparency
        ;; (define-key evil-normal-state-map (kbd \"SPC z\") 'toggle-transparency)

        ;; Org Agenda
        (define-key evil-normal-state-map (kbd \"SPC o\") 'org-agenda)

        ;; Open TODO agenda file as a pop-up buffer
        (define-key evil-normal-state-map (kbd \"SPC r\")
          (lambda ()
            (interactive)
            (let ((file \"~/org/agenda/todo.org\")
                    (pop-up-buffer \"*TODO*\"))
                (pop-to-buffer pop-up-buffer)
                (find-file file))))

        (defun open-custom-agenda ()
          \"Open the custom agenda view.\"
          (interactive)
          (org-agenda nil \"A\"))

        (define-key evil-normal-state-map (kbd \"SPC a\") 'open-custom-agenda)

        ;; Org Roam
        ;; (define-key evil-normal-state-map (kbd \"SPC n l\") 'org-roam-buffer-toggle)
        ;; (define-key evil-normal-state-map (kbd \"SPC n f\") 'org-roam-node-find)
        ;; (define-key evil-normal-state-map (kbd \"SPC n i\") 'org-roam-node-insert)

        ;; Manage buffers
        ;; (define-key evil-normal-state-map (kbd \"SPC k\") 'kill-buffer)
        ;; (define-key evil-normal-state-map (kbd \"SPC eb\") 'eval-buffer)

        ;; Manage windows
        ;; (evil-global-set-key 'normal (kbd \"C-a <backspace>\") 'delete-window)
        ;; (evil-global-set-key 'normal (kbd \"C-a \\\\\") 'split-window-right)
        ;; (evil-global-set-key 'normal (kbd \"C-a -\") 'split-window-below)
        ;; ;; Windmove keys for additional window navigation
        ;; (evil-global-set-key 'normal (kbd \"C-a h\")  'windmove-left)
        ;; (evil-global-set-key 'normal (kbd \"C-a l\")  'windmove-right)
        ;; (evil-global-set-key 'normal (kbd \"C-a k\")  'windmove-up)
        ;; (evil-global-set-key 'normal (kbd \"C-a j\")  'windmove-down)

        ;; ;; Use visual line motions even outside of visual-line-mode buffers
        ;; (evil-global-set-key 'motion \"j\" 'evil-next-visual-line)
        ;; (evil-global-set-key 'motion \"k\" 'evil-previous-visual-line)
  )

" . 11303) 11715 (t 25991 51854 18773 63000) nil (": t
" . 10219) 10154 (t 25991 51851 728773 138000) nil (10219 . 10221) (10219 . 10221) (10208 . 10220) ("
" . 10208) (10207 . 10209) 10154 nil (9944 . 9946) (9965 . 9966) (9967 . 9968) (9976 . 9977) (9978 . 9979) (9987 . 9988) (9990 . 9991) (10014 . 10015) (10017 . 10018) (10041 . 10043) (10073 . 10075) (10111 . 10113) (10140 . 10142) 9944 nil (nil rear-nonsticky nil 10177 . 10178) (nil fontified nil 10140 . 10178) (nil fontified nil 10111 . 10140) (nil fontified nil 10073 . 10111) (nil fontified nil 10072 . 10073) (nil fontified nil 10041 . 10072) (nil fontified nil 10014 . 10041) (nil fontified nil 9987 . 10014) (nil fontified nil 9976 . 9987) (nil fontified nil 9965 . 9976) (nil fontified nil 9944 . 9965) (9944 . 10178) nil (9835 . 9836) 9839 nil (9890 . 9953) ("<ini" . -9890) 9894 (9890 . 9894) (9889 . 9890) 9854 nil ("*** Undohist
Make Emacs undo persistent.
#+begin_src emacs-lisp :tangle \"init.el\" :mkdirp yes

#+end_src
" . 9835) 9930 nil (nil rear-nonsticky nil 9993 . 9994) (9952 . 9994) nil ("Linear undo while maintaining all history." . 9952) (nil rear-nonsticky t 9993 . 9994) nil ("(use-package undohist
  :disabled t
  :init (undohist-initialize))" . 9919) (nil rear-nonsticky t 9984 . 9985) nil (nil rear-nonsticky nil 9984 . 9985) (nil fontified nil 9955 . 9985) (nil fontified nil 9941 . 9955) (nil fontified nil 9919 . 9941) (9919 . 9985) 9918 nil (nil rear-nonsticky nil 9993 . 9994) (nil fontified nil 9952 . 9994) (9952 . 9994) nil (9951 . 9952) (t 25991 51745 608776 586000) 9950 nil (9944 . 9951) (9940 . 9944) (9939 . 9940) (t 25991 51734 192110 292000) 9930 nil (9876 . 9939) ("<ini" . -9876) 9880 (9876 . 9880) (9875 . 9876) 9873 nil (9874 . 9875) (t 25991 51726 458777 209000) nil (9869 . 9874) (9848 . 9869) (9847 . 9848) (9843 . 9847) (9835 . 9843) (9834 . 9835) 9789 nil (10423 . 10627) ("*** Clean Whitespaces
Automatically trim extraneous whitespaces.

#+begin_src emacs-lisp :tangle \"init.el\" :mkdirp yes
(use-package ws-butler
  :ensure t
  :config
  (ws-butler-global-mode 1))
#+end_src

" . 10279) 10283 nil (10279 . 10483) ("*** Clean Whitespaces
Automatically trim extraneous whitespaces.

#+begin_src emacs-lisp :tangle \"init.el\" :mkdirp yes
(use-package ws-butler
  :ensure t
  :config
  (ws-butler-global-mode 1))
#+end_src

" . 10064) 10068 nil (10064 . 10268) ("*** Clean Whitespaces
Automatically trim extraneous whitespaces.

#+begin_src emacs-lisp :tangle \"init.el\" :mkdirp yes
(use-package ws-butler
  :ensure t
  :config
  (ws-butler-global-mode 1))
#+end_src

" . 9835) 9839 (t 25991 51647 328779 783000) nil ("
" . 11376) nil ("        " . 11376) (nil ws-butler-chg nil 11384 . 11385) (11375 . 11384) (t 25991 51617 85447 429000) nil (14121 . 14123) (14110 . 14123) ("
" . 14110) (14109 . 14111) nil ("

" . 14109) (14110 . 14111) ("#+RESULTS:
t
" . 14110) (": " . 14121) (t 25991 51617 85447 429000) nil ("
        " . 11375) (nil ws-butler-chg nil 11384 . 11385) (nil ws-butler-chg delete 11384 . 11385) (11376 . 11384) nil ("        " . 11376) (nil ws-butler-chg nil 11384 . 11385) (11375 . 11384) (t 25991 51617 85447 429000) nil (14121 . 14123) (14110 . 14123) ("
" . 14110) (14109 . 14111) nil ("

" . 14109) (14110 . 14111) ("#+RESULTS:
t
" . 14110) (": " . 14121) (t 25991 51617 85447 429000) nil ("
  " . 11375) ("      " . 11378) (nil ws-butler-chg delete 11384 . 11385) (11376 . 11384) nil ("        " . -11376) 11384 (11378 . 11384) 10918 (11375 . 11378) (t 25991 51617 85447 429000) 11374 nil (14121 . 14123) (14110 . 14123) ("
" . 14110) (14109 . 14111) 11357 (t 25991 51615 175447 493000) nil (11356 . 11358) nil ("tree" . 11356) nil (10918 . 14101) ("  ;; Bind C-x C-b to ibuffer
  (global-set-key (kbd \"C-x C-b\") 'ibuffer)
    ;; Make ESC quit prompts
    (global-set-key (kbd \"<escape>\") 'keyboard-escape-quit)

    (use-package evil
        :init
        (setq evil-want-integration t)
        (setq evil-want-keybinding nil)
        (setq evil-want-C-u-scroll t)
        (setq evil-want-C-i-jump nil)
        (setq evil-respect-visual-line-mode t)
        ;; (setq evil-undo-system 'undo-tree)
        :config
        (evil-mode 1)
        (evil-set-initial-state 'messages-buffer-mode 'normal)
        (evil-set-initial-state 'dashboard-mode 'normal)
        ;; (define-key evil-insert-state-map (kbd \"C-g\") 'evil-normal-state)
        ;; (define-key evil-insert-state-map (kbd \"C-h\") 'evil-delete-backward-char-and-join)

        ;; Define key bindings for SPC followed by a single key
        ;; (define-key evil-normal-state-map (kbd \"SPC f\") 'find-file)
        ;; (define-key evil-normal-state-map (kbd \"SPC p\") 'projectile-command-map)
        ;; (define-key evil-normal-state-map (kbd \"SPC b\") 'switch-to-buffer)
        ;; (define-key evil-normal-state-map (kbd \"SPC s\") 'counsel-projectile-rg)

        ;; Background transparency
        ;; (define-key evil-normal-state-map (kbd \"SPC z\") 'toggle-transparency)

        ;; Org Agenda
        (define-key evil-normal-state-map (kbd \"SPC o\") 'org-agenda)

        ;; Open TODO agenda file as a pop-up buffer
        (define-key evil-normal-state-map (kbd \"SPC r\")
          (lambda ()
            (interactive)
            (let ((file \"~/org/agenda/todo.org\")
                    (pop-up-buffer \"*TODO*\"))
                (pop-to-buffer pop-up-buffer)
                (find-file file))))

        (defun open-custom-agenda ()
          \"Open the custom agenda view.\"
          (interactive)
          (org-agenda nil \"A\"))

        (define-key evil-normal-state-map (kbd \"SPC a\") 'open-custom-agenda)

        ;; Org Roam
        ;; (define-key evil-normal-state-map (kbd \"SPC n l\") 'org-roam-buffer-toggle)
        ;; (define-key evil-normal-state-map (kbd \"SPC n f\") 'org-roam-node-find)
        ;; (define-key evil-normal-state-map (kbd \"SPC n i\") 'org-roam-node-insert)

        ;; Manage buffers
        ;; (define-key evil-normal-state-map (kbd \"SPC k\") 'kill-buffer)
        ;; (define-key evil-normal-state-map (kbd \"SPC eb\") 'eval-buffer)

        ;; Manage windows
        ;; (evil-global-set-key 'normal (kbd \"C-a <backspace>\") 'delete-window)
        ;; (evil-global-set-key 'normal (kbd \"C-a \\\\\") 'split-window-right)
        ;; (evil-global-set-key 'normal (kbd \"C-a -\") 'split-window-below)
        ;; ;; Windmove keys for additional window navigation
        ;; (evil-global-set-key 'normal (kbd \"C-a h\")  'windmove-left)
        ;; (evil-global-set-key 'normal (kbd \"C-a l\")  'windmove-right)
        ;; (evil-global-set-key 'normal (kbd \"C-a k\")  'windmove-up)
        ;; (evil-global-set-key 'normal (kbd \"C-a j\")  'windmove-down)

        ;; ;; Use visual line motions even outside of visual-line-mode buffers
        ;; (evil-global-set-key 'motion \"j\" 'evil-next-visual-line)
        ;; (evil-global-set-key 'motion \"k\" 'evil-previous-visual-line)
  )

" . 10918) 11327 (t 25991 51550 815449 585000) nil (52292 . 52303) ("
" . 52292) (52291 . 52293) 52279 (t 25991 51546 75449 737000) nil (52194 . 52196) (52225 . 52227) 52194 nil (nil rear-nonsticky nil 52275 . 52276) (nil fontified nil 52225 . 52276) (nil fontified nil 52194 . 52225) (52194 . 52276) (t 25991 51525 32117 86000) nil (52170 . 52177) (52154 . 52170) nil ("init" . 52154) nil (52122 . 52185) ("<ini" . -52122) 52126 (52122 . 52126) (52121 . 52122) (t 25991 51502 712117 809000) 52091 nil (52119 . 52120) nil (52100 . 52101) (t 25991 51494 902118 62000) nil (52118 . 52119) nil (52112 . 52118) (52091 . 52112) (52090 . 52091) (t 25991 51478 318785 264000) 52089 nil (52073 . 52090) (52069 . 52073) (52068 . 52069) (52067 . 52068) (t 25991 51437 978786 579000) 52059 nil ("
" . 52069) nil ("#+RESULTS:
: t
" . 52069) 52070 nil ("#+caption:  caption of the table
|column 1 |  column 2 |
|--------------+----------------|
" . 52084) (apply yas--snippet-revive 52084 52175 #s(yas--snippet nil (#s(yas--field 1 52095 52116 nil nil nil nil #s(yas--field 2 52118 52126 nil nil nil nil #s(yas--field 3 52129 52138 nil nil nil nil nil))) #s(yas--field 2 52118 52126 nil nil nil nil #s(yas--field 3 52129 52138 nil nil nil nil nil)) #s(yas--field 3 52129 52138 nil nil nil nil nil)) nil 33 nil #s(yas--field 1 52095 52116 nil nil nil nil #s(yas--field 2 52118 52126 nil nil nil nil #s(yas--field 3 52129 52138 nil nil nil nil nil))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 52095 52116 nil nil nil nil #s(yas--field 2 52118 52126 nil nil nil nil #s(yas--field 3 52129 52138 nil nil nil nil nil))) #s(yas--field 2 52118 52126 nil nil nil nil #s(yas--field 3 52129 52138 nil nil nil nil nil)) #s(yas--field 3 52129 52138 nil nil nil nil nil)) nil 33 nil #s(yas--field 1 52095 52116 nil nil nil nil #s(yas--field 2 52118 52126 nil nil nil nil #s(yas--field 3 52129 52138 nil nil nil nil nil))) nil nil)) (52084 . 52175) nil (apply yas--snippet-revive 52084 52084 #s(yas--snippet nil (#s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))))) #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))) #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--exit 52084 nil) 16 nil #s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) nil nil)) ("<img src=\"\" alt=\"\" align=\"left\" title=\"image title\" class=\"img\" />
" . 52084) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))))) #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))) #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--exit 52084 nil) 16 nil #s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) nil nil)) (apply yas--snippet-revive 52084 52150 #s(yas--snippet nil (#s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))))) #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))) #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--exit 52084 nil) 16 nil #s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))))) #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))) #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--exit 52084 nil) 16 nil #s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) nil nil)) nil (apply yas--snippet-revive 52084 52150 #s(yas--snippet nil (#s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))))) #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))) #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--exit 52084 nil) 16 nil #s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) nil nil)) nil (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))))) #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))) #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil))) #s(yas--exit 52084 nil) 16 nil #s(yas--field 1 52084 52084 nil nil nil nil #s(yas--field 2 52084 52084 nil nil nil nil #s(yas--field 3 52084 52084 nil nil nil nil #s(yas--field 4 52084 52084 nil nil nil nil #s(yas--field 5 52084 52084 nil nil nil nil #s(yas--exit 52084 nil)))))) nil nil)) (52084 . 52150) ("img_" . 52084) 52088 (52084 . 52088) ("m" . -52084) ("g" . -52085) ("_" . -52086) 52087 (52084 . 52087) (t 25991 51350 525456 83000) nil (52080 . 52082) (52069 . 52082) ("
" . 52069) (52068 . 52070) 52029 (t 25991 51348 335456 155000) nil (" " . 52029) nil (" " . 52029) nil (" " . 52029) nil ("o" . 52029) nil ("nessary " . 51987) nil ("some " . 51987) nil (";; " . 52046) nil ("for " . 51987) nil (51979 . 51987) nil (51962 . 51969) (51960 . 51962) 51889 (51957 . 51960) 51956 nil (51949 . 51957) nil ("[[link]]" . 51949) nil ("reason " . 51976) nil ("this " . 51983) nil (51983 . 51988) nil ("this " . 51983) nil (51983 . 51988) nil ("this " . 51983) nil (51983 . 51988) nil ("this " . 51983) nil (51983 . 51988) nil (51976 . 51983) nil (51971 . 51976) nil (nil ws-butler-chg delete 51971 . 51972) (51967 . 51971) nil (51967 . 51968) ("c" . 51967) nil (nil ws-butler-chg delete 52032 . 52033) (52024 . 52032) nil (" these
 " . 52018) (nil rear-nonsticky nil 52025 . 52026) nil ("f" . 52018) nil (52028 . 52034) nil ("

" . 52058) (52059 . 52060) ("#+RESULTS:
t
" . 52059) (": " . 52070) nil (52070 . 52074) ("t
" . 52070) (": " . 52070) nil (52070 . 52072) (52070 . 52072) (": t
" . 52070) 51964 (t 25991 51246 725459 455000) nil (52070 . 52072) (52059 . 52072) ("
" . 52059) (52058 . 52060) 51963 (t 25991 51207 25460 743000) nil ("  ;; 
" . 52028) 52032 nil (52018 . 52019) nil (nil rear-nonsticky nil 52025 . 52026) (nil fontified nil 52018 . 52026) (52018 . 52026) 52017 nil ("of these" . 52024) nil (51967 . 51968) ("n" . 51967) nil ("for " . 51967) 51971 nil ("some " . 51971) 51976 nil ("reason " . 51976) 51983 nil ("this " . 51983) 51988 nil ("is " . 51988) 51991 nil (nil rear-nonsticky nil 52075 . 52076) (nil fontified nil 52057 . 52076) (nil fontified nil 52043 . 52057) (nil fontified nil 51962 . 52043) (nil fontified nil 51952 . 51962) (nil fontified nil 51940 . 51952) (nil fontified nil 51921 . 51940) (nil fontified nil 51889 . 51921) (51889 . 52076) (t 25991 51169 892128 622000) nil ("
" . 51798) nil ("#+RESULTS:
" . 51798) 51807 nil (51798 . 51809) ("
" . 51798) (51797 . 51799) 51784 nil ("
" . -51785) (" " . -51786) (" " . -51787) (" " . -51788) (" " . -51789) 51790 (t 25991 51154 248795 797000) nil (53390 . 53397) (t 25991 51137 528796 341000) nil (51870 . 51877) (51854 . 51870) nil ("init" . 51854) nil (51822 . 51885) ("<ini" . -51822) 51826 (51822 . 51826) (51821 . 51822) (51803 . 51821) (51802 . 51803) (51801 . 51802) 51792 nil ("#+RESULTS:
" . 51803) nil ("
" . 51792) (t 25991 51049 798799 195000) nil (51762 . 51764) 51437 nil (51716 . 51718) 51437 nil (51669 . 51671) 51437 (t 25991 51041 668799 456000) nil (nil rear-nonsticky nil 51778 . 51779) (nil fontified nil 51754 . 51779) (nil fontified nil 51712 . 51754) (nil fontified nil 51667 . 51712) (51667 . 51779) nil ("    " . -51667) 51671 (51669 . 51671) 51437 (51666 . 51669) (t 25991 51000 385467 465000) 51664 nil (51636 . 51638) 51437 nil ("  " . 51592) 51437 nil (nil rear-nonsticky nil 51665 . 51666) (nil fontified nil 51634 . 51666) (nil fontified nil 51592 . 51634) (51592 . 51666) 51591 nil ("(" . -51592) ("g" . -51593) ("e" . -51594) 51595 (51592 . 51595) (51590 . 51592) 51437 (51587 . 51590) (51585 . 51587) (51564 . 51585) (51548 . 51564) (51546 . 51548) 51437 (51543 . 51546) (51540 . 51543) ("i" . -51540) ("f" . -51541) 51542 (51536 . 51542) (51534 . 51536) 51437 (51531 . 51534) 51505 nil ("    :blackout 'yas-minor-mode
" . 51532) 51547 (t 25991 50943 765469 306000) nil (51546 . 51547) (t 25991 50934 992136 257000) nil (51557 . 51560) (51536 . 51557) ("  " . 51439) (" " . 51464) (" " . 51469) (" " . 51479) (" " . 51484) ("  " . 51509) ("
" . 51542) (51545 . 51546) 51437 (51539 . 51542) (t 25991 50826 862139 764000) 51517) (emacs-undo-equiv-table))