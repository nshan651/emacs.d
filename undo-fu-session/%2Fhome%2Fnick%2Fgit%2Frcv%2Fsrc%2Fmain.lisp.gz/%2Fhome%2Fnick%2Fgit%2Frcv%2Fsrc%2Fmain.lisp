((buffer-size . 3702) (buffer-checksum . "04d89af4e4454b29dfec3b00fdc086bbbdf5d4a7"))
((emacs-buffer-undo-list nil (apply -3 562 588 undo--wrap-and-run-primitive-undo 562 588 ((562 . 565) 577)) nil (741 . 742) (t 26136 21303 732779 206000) nil (561 . 562) 582 nil (nil rear-nonsticky nil 582 . 583) (nil fontified nil 561 . 583) (561 . 583) (t 26136 20983 746134 641000) nil (718 . 719) (t 26136 20972 422802 93000) nil (":" . 718) nil ("#" . 718) (t 26135 11255 584859 348000) nil (718 . 719) (t 26135 11244 391525 327000) nil (588 . 589) (t 26135 11218 711523 758000) nil (574 . 576) nil (":" . 574) (t 26135 11165 104853 819000) nil (apply -6 446 562 undo--wrap-and-run-primitive-undo 446 562 ((504 . 507) (446 . 449) 555)) nil (537 . 541) nil ("fiveam" . 537) (t 26135 6994 927931 978000) nil (537 . 543) nil ("5am" . 537) (t 26135 6622 927909 245000) nil (535 . 540) (t 26135 6104 511210 874000) nil (1 . 3628) (t 26135 6101 171210 669000) nil (";;; Ranked choice voting program
;;; Instant Runoff Voting(IRV)
;;; The instant-runoff vote counting procedure is as follows:
;;;    1. Eliminate the candidate appearing as the first preference on the fewest ballots.
;;;    2. If only one candidate remains, elect this candidate and stop.
;;;    3. Otherwise go to 1.
;;; https://en.wikipedia.org/wiki/Instant-runoff_voting
;;; Python project for IRV: https://github.com/jontingvold/pyrankvote

(eval-when (:compile-toplevel :load-toplevel :execute)
  (ql:quickload '(:cl-csv :clingon) :silent t))

(defpackage :rcv
  (:use :cl)
  (:export :ballots :display-results :complete-rankings :main))

;; Paste this into a repl to switch namespaces
(in-package :rcv)

;; Vars for testing
(defvar ballots
  '((\"Bush\" \"Nader\" \"Gore\")
    (\"Bush\" \"Nader\" \"Gore\")
    (\"Bush\" \"Nader\")
    (\"Bush\" \"Nader\")
    (\"Nader\" \"Gore\" \"Bush\")
    (\"Nader\" \"Gore\")
    (\"Gore\" \"Nader\" \"Bush\")
    (\"Gore\" \"Nader\")
    (\"Gore\" \"Nader\" \"Yeet\")))

(defvar *ballots*
  (cl-csv:read-csv #P\"/home/nick/git/rcv/data/ballots.csv\"))

(defvar *candidates*
  (remove-duplicates (reduce #'append *ballots* :key #'identity)
		     :test #'string=))

(defun rank-prefs (top-choices)
  \"Return the rankings of each ballot's top choice candidates.\"
  (let ((ranking '()))
    (dolist (choice top-choices)
      ;; Add a new cons pair if the key doesn't already exist.
      (pushnew (cons choice 0) ranking :key #'car)
      ;; Increment the cons cdr
      (let ((existing (assoc choice ranking)))
	(setf (cdr existing) (1+ (cdr existing)))))

    ;; Return a sorted assoc list of candidates
    (sort ranking #'(lambda (a b) (> (cdr a) (cdr b))))))

(defun get-last (alist)
  \"Find the last place candidate.\"
  (car (car (last alist))))

(defun eliminate (rankings ballots)
  \"Eliminate the candidate with the fewest votes from the ballot.\"
  (let ((candidate (get-last rankings)))
    (mapcar (lambda (ballot)
	      (remove-if (lambda (c) (string= c candidate)) ballot))
	      ballots)))

;; TODO: Revise this to be more concise/efficient
(defun add-eliminated (rankings candidates)
  \"Compare the current rankings with the list of candidates.\"
  (let ((complete-rankings (copy-list rankings)))
    (dolist (candidate candidates)
      (unless (assoc candidate rankings :test #'string=)
	(nconc complete-rankings (list (cons candidate 0)))))
    complete-rankings))

(defun has-majority (rankings)
  \"Check if there is a majority winner in the rankings.\"
  (let ((total-votes (reduce '+ rankings :key #'cdr)))
    (if (and (>= (cdr (first rankings)) (/ total-votes 2))
	     (= (length rankings) 2))
	t
	nil)))

(defun update-ranking-history (candidates rankings ranking-history)
  \"Add the current rankings to the history data structure.\"
  (append ranking-history
	  ;; Add back in previously eliminated candidates with vote total 0.
	  (list (add-eliminated rankings candidates))))

(defun rcv (ballots candidates counter ranking-history)
  \"Ranked choice voting.
1. Eliminate the candidate with the fewest votes.
2. If only one candidate remains, elect this candidate and stop.
3. Otherwise, go back to 1.\"
  (let* ((top-choices (mapcar #'car ballots))
	 (rankings (rank-prefs top-choices))
	 (rhist (update-ranking-history candidates rankings ranking-history)))
    (if (has-majority rankings)
	;; Terminal case: print end results and/or return ranking hist
	(progn
	  (format t \"TODO: show final results here~%\")
	  (format t \"counter: ~A~%\" counter)
	  rhist)
	;; Move to next tourn round; eliminating last place candidates
	(rcv
	 (eliminate rankings ballots)
	 candidates
	 (incf counter)
	 rhist))))

" . -1) (t 26135 6091 624543 419000) nil ("*" . 3640) nil ("*" . 3633) (t 26135 6086 117876 415000) nil (apply 30 731 973 undo--wrap-and-run-primitive-undo 731 973 ((";; " . -943) (";; " . -922) (";; " . -894) (";; " . -873) (";; " . -845) (";; " . -824) (";; " . -803) (";; " . -775) (";; " . -747) (";; " . -731) 1003)) nil (3685 . 3686) nil (nil rear-nonsticky nil 3684 . 3685) (nil fontified nil 3673 . 3685) (3673 . 3685) 3672 nil ("*candidates*" . 3679) 3690 nil ("
" . -3652) (" " . -3653) (" " . -3654) (" " . -3655) (" " . -3656) (" " . -3657) (" " . -3658) (" " . -3659) (" " . -3660) ("	" . 3661) (3653 . 3661) 3654 (" " . -3654) 3655 nil (3615 . 3617) 3624 nil (nil rear-nonsticky nil 3624 . 3625) (nil fontified nil 3615 . 3625) (3615 . 3625) nil ("	 " . -3615) 3617 (3614 . 3617) 3586 nil ("candidates" . 3642) nil (" " . -2987) 2988 nil ("candidates" . 2988) nil (2953 . 2964) (t 26135 5954 281201 659000) nil (3671 . 3672) nil (3663 . 3664) (t 26135 5931 651200 273000) nil ("
" . -3655) (" " . -3656) (" " . -3657) 3658 nil ("
" . -3654) (" " . -3655) (" " . -3656) (" " . -3657) (" " . -3658) 3659 (t 26135 5923 187866 423000) nil (3567 . 3577) ("caniddat" . -3567) 3575 (3565 . 3575) (3557 . 3565) (3536 . 3557) ("a" . -3536) ("m" . -3537) 3538 (3531 . 3538) ("tournamnet" . -3531) 3541 (3532 . 3541) (3517 . 3532) (" " . -3517) 3518 (3515 . 3518) (3513 . 3515) (t 26135 5828 144527 248000) 3512 nil (2869 . 2882) (2849 . 2869) (2828 . 2849) ("u" . -2828) ("i" . -2829) 2830 (2819 . 2830) (2816 . 2819) (2812 . 2816) (t 26135 5774 657857 292000) 2811 nil (1851 . 1867) (1845 . 1851) nil (1831 . 1834) nil ("a" . 1831) (t 26135 5762 501189 877000) nil ("
" . 1781) nil ("(defun get-eliminated (contenders candidates)
  \"Get all elimated candidates.\"
  (remove-if #'(lambda (c) (member c contenders)) candidates))

(defun eliminate-candidate (candidate ballot)
  \"Remove the candidate with the fewest votes from a single list.\"
  (remove-if (lambda (c) (string= c candidate)) ballot))
" . 1782) 1825 (t 26135 5648 371182 846000) nil (3072 . 3075) (3051 . 3072) (3043 . 3051) ("i" . -3043) ("n" . -3044) ("g" . -3045) ("s" . -3046) (" " . -3047) 3048 (3036 . 3048) ("ite" . -3036) 3039 (3020 . 3039) (" " . -3020) 3021 (3020 . 3021) (3019 . 3021) ("\"" . -3019) (3019 . 3020) (3016 . 3019) (t 26135 5560 651177 437000) 2980 nil (3676 . 3679) ("tournament" . 3676) (t 26135 5540 267842 850000) nil (3745 . 3755) (3742 . 3745) (t 26135 5453 731170 846000) nil (3076 . 3087) (t 26135 5420 874502 150000) nil (3764 . 3776) (t 26135 5406 757834 614000) nil ("optional " . 3126) nil ("&" . 3126) (t 26135 5352 954497 962000) nil (3464 . 3469) (3458 . 3464) (3437 . 3458) (t 26135 5326 997829 699000) nil (3132 . 3146) (3125 . 3132) nil (3404 . 3416) (t 26135 5305 221161 694000) nil (2967 . 2970) nil (3387 . 3401) nil ("append ranking-history (list rankings)" . 3387) (t 26135 5265 597825 927000) nil ("
" . -3076) (" " . -3077) (" " . -3078) 3079 (t 26135 5260 521158 949000) nil (3040 . 3043) (" " . 3039) (3040 . 3041) (t 26135 5214 754489 464000) nil ("
" . 3046) (nil ws-butler-chg delete 3046 . 3047) (3045 . 3046) ("			   " . 3046) nil (3046 . 3052) (" " . 3045) (3046 . 3047) (t 26135 5214 754489 464000) nil ("
" . 2096) nil ("(defun eliminate-candidate-from-tbl (candidate ballots)
  \"Eliminate the candidate with the fewest votes.\"
  (mapcar (lambda (ballot)
	    (eliminate-candidate candidate ballot))
	  ballots))
" . 2096) 2114 (t 26135 5197 281155 51000) nil ("  (let ((complete-rankings (add-eliminated)))) 
" . 3207) 3253 nil (3313 . 3314) nil (")" . 3303) nil (3288 . 3303) (3287 . 3289) ("(" . -3287) (3287 . 3288) nil (3247 . 3249) (3235 . 3247) nil (3234 . 3236) ("(" . -3234) (3234 . 3235) (3233 . 3234) (" " . -3233) 3234 (3228 . 3234) (3216 . 3228) (3215 . 3217) ("(" . -3215) (3215 . 3216) (3214 . 3216) ("(" . -3214) (3210 . 3215) (3209 . 3211) ("(" . -3209) (3207 . 3210) (t 26135 5117 987816 842000) nil (3207 . 3208) (t 26135 5117 987816 842000) ("  " . 3207) nil (" " . -3209) 3210 (3209 . 3210) (3206 . 3209) (t 26135 5113 301149 886000) 3183 nil (")" . 3249) nil ("(" . 3209) nil ("rhist " . 3210) (t 26135 5102 214482 539000) nil (3189 . 3205) (t 26135 5058 361146 505000) nil (")" . -3241) 3242 nil ("
" . 3191) nil (3192 . 3194) ("	 " . -3192) 3194 nil (nil rear-nonsticky nil 3193 . 3194) ("
" . -3243) (3191 . 3244) nil ("  " . -3191) 3193 (3190 . 3193) 3143 nil (3190 . 3193) (t 26135 4989 921142 286000) nil (3170 . 3189) (t 26135 4957 944473 650000) nil (" " . -3170) 3171 (3170 . 3171) (3169 . 3171) ("(" . -3169) (3160 . 3170) (3148 . 3160) (" " . -3148) 3149 (3143 . 3149) (3142 . 3144) ("(" . -3142) (3142 . 3143) (3141 . 3142) (3140 . 3141) (t 26135 4815 907798 235000) 3139 nil (3775 . 3778) ("tournament" . 3775) nil (3772 . 3773) 3771 nil (3149 . 3152) ("tournament" . 3149) nil ("
" . 3808) nil ("(defun rcv (ballots)

  (setq res (tournament ballots 1 '(()) ))

  )

(rcv ballots)
" . 3809) 3882 (t 26135 4795 27796 950000) nil (nil rear-nonsticky nil 3195 . 3196) ("
" . -3362) (3193 . 3363) 3142 nil ("  \"Ranked choice voting.
1. Eliminate the candidate with the fewest votes.
2. If only one candidate remains, elect this candidate and stop.
3. Otherwise, go back to 1.\"
" . 3661) 3818 (t 26134 60869 97216 390000) nil (1925 . 2288) nil (1924 . 1925) (t 26134 60846 410548 336000) nil ("
" . 1924) nil ("(defun eliminate-candidate (candidate ballot)
  \"Remove the candidate with the fewest votes from a single list.\"
  (remove-if (lambda (c) (string= c candidate)) ballot))

(defun eliminate-candidate-from-tbl (candidate ballots)
  \"Eliminate the candidate with the fewest votes.\"
  (mapcar (lambda (ballot)
	    (eliminate-candidate candidate ballot))
	  ballots))
" . 1925) 1933 (t 26134 60759 443876 344000) nil (3593 . 3598) nil ("history" . 3593) nil ("-" . 3593) nil ("ranking" . 3593) nil (3523 . 3528) nil ("ranking" . 3523) 3530 nil ("-" . 3530) 3531 nil ("history" . 3531) 3538 (t 26134 60749 83875 712000) nil (3295 . 3310) ("rhist" . 3295) nil (3282 . 3286) ("anking-history" . 3282) nil (3177 . 3192) nil ("rhist" . 3177) (t 26134 60722 373874 77000) nil ("	 ;; (append ranking-history (list rankings))))
" . 3591) 3609 nil ("	  ;; (append ranking-history (list rankings)))
" . 3510) 3556 (t 26134 60687 173871 922000) nil ("
" . -3318) (" " . -3319) (" " . -3320) (" " . -3321) (" " . -3322) (" " . -3323) (" " . -3324) (" " . -3325) (" " . -3326) ("	" . 3327) (3319 . 3327) 3320 (" " . -3320) 3321 nil ("    ;; Modify the ranking-history
" . 3323) 3349 nil ("    ;; (setq ranking-history (append rhist (list rankings)))
" . 3357) 3383 (t 26134 60661 653870 360000) nil (apply -3 3357 3418 undo--wrap-and-run-primitive-undo 3357 3418 ((3361 . 3364) 3413)) nil (3316 . 3318) (")" . 3316) (3315 . 3316) (" " . -3315) (3315 . 3316) (")" . -3315) (3315 . 3316) nil (nil rear-nonsticky nil 3314 . 3315) (nil fontified nil 3287 . 3315) (3287 . 3315) 3286 nil (3271 . 3287) (" " . -3271) 3272 (3271 . 3272) (3270 . 3272) ("(" . -3270) (3270 . 3271) (3267 . 3270) (t 26134 60565 420531 137000) 3232 nil (3340 . 3346) nil ("ranking-history " . 3340) nil (" " . -3182) 3183 (3177 . 3183) nil ("ranking-history" . 3177) (t 26134 60509 570527 718000) nil (3310 . 3315) (3289 . 3310) ("m" . -3289) 3290 (3286 . 3290) (3281 . 3286) (t 26134 60499 233860 419000) 3280 nil (3282 . 3350) nil (apply -3 3472 3519 undo--wrap-and-run-primitive-undo 3472 3519 ((3475 . 3478) 3627)) nil (apply -3 3598 3645 undo--wrap-and-run-primitive-undo 3598 3645 ((3600 . 3603) 3661)) nil (3643 . 3663) nil (3517 . 3537) nil (3279 . 3280) ("        " . 3278) (3277 . 3287) (t 26134 60429 33856 119000) nil ("
" . -3277) (" " . -3278) (" " . -3279) (" " . -3280) (" " . -3281) (" " . -3282) (" " . -3283) (" " . -3284) (" " . -3285) ("	" . 3286) (3278 . 3286) 3279 (" " . -3279) 3280 (t 26134 60417 523855 416000) nil ("	  ranking-history)
" . 3517) nil ("	 ranking-history))
" . 3643) 3661 (t 26134 60410 267188 305000) nil (apply 3 3598 3642 undo--wrap-and-run-primitive-undo 3598 3642 ((";; " . -3600) 3627)) nil (apply 3 3472 3516 undo--wrap-and-run-primitive-undo 3472 3516 ((";; " . -3475) 3494)) nil ("    (setq ranking-history (append ranking-history (list rankings)))
" . 3282) 3311 (t 26134 60369 537185 812000) nil (apply 3 3282 3349 undo--wrap-and-run-primitive-undo 3282 3349 ((";; " . -3286) 3309)) nil ("    (nconc ranking-history (list rankings))
" . 3353) 3380 (t 26134 60330 763850 103000) nil (apply -3 3282 3353 undo--wrap-and-run-primitive-undo 3282 3353 ((3286 . 3289) 3324)) nil (")" . -3393) 3394 nil ("append " . 3361) nil ("(" . 3361) nil (3355 . 3361) nil ("history " . 3355) nil ("-" . 3355) nil ("ranking" . 3355) nil ("setq " . 3355) nil (nil rear-nonsticky nil 3353 . 3354) ("
" . -3417) (3349 . 3418) 3340 (t 26134 60263 103845 960000) nil (3348 . 3349) nil (3292 . 3308) nil (")" . 3293) nil (3292 . 3294) ("(" . -3292) (3287 . 3293) (t 26134 60224 910510 289000) nil (")" . 3711) nil ("(" . 3696) nil ("(" . 3568) nil (")" . 3584) (t 26134 60196 843841 904000) nil (")" . -3717) 3718 (3716 . 3718) (3715 . 3716) (")" . 3715) (3714 . 3715) (" " . -3714) (3714 . 3715) (")" . -3714) (3714 . 3715) nil (3699 . 3714) (3698 . 3700) ("(" . -3698) (3698 . 3699) ("r" . -3698) ("a" . -3699) ("n" . -3700) 3701 (3698 . 3701) (3695 . 3698) 3675 nil (apply -3 3648 3696 undo--wrap-and-run-primitive-undo 3648 3696 ((3650 . 3653) 3668)) nil (3585 . 3586) (")" . 3585) (3569 . 3585) (3568 . 3570) ("(" . -3568) (3568 . 3569) (3564 . 3568) 3527 nil (apply -3 3517 3565 undo--wrap-and-run-primitive-undo 3517 3565 ((3520 . 3523))) nil (3282 . 3286) ("	 " . -3282) 3284 nil (nil rear-nonsticky nil 3283 . 3284) ("
" . -3324) (3281 . 3325) 3280 nil ("	 (append ranking-history (list rankings))
" . 3278) 3319 nil (3278 . 3280) 3317 nil (nil rear-nonsticky nil 3317 . 3318) (nil fontified nil 3278 . 3318) (3278 . 3318) nil ("	 " . -3278) 3280 (3277 . 3280) 3241 nil (3277 . 3280) (t 26134 60007 757163 660000) nil (3512 . 3513) nil (")" . 3502) nil (3497 . 3502) (3496 . 3498) ("(" . -3496) (3496 . 3497) nil (3611 . 3612) nil (")" . 3609) (3608 . 3609) (" " . -3608) (3608 . 3609) (")" . -3608) (3608 . 3609) nil (")" . 3600) nil (3595 . 3600) (3594 . 3596) ("(" . -3594) (3594 . 3595) (t 26134 59927 397158 742000) nil (3505 . 3506) (t 26134 59915 417158 9000) (")" . 3505) (3504 . 3505) (" " . -3504) (3504 . 3505) (")" . -3504) (3504 . 3505) (t 26134 59915 417158 9000) nil (3495 . 3504) nil (")" . 3480) nil (3473 . 3480) ("p" . -3473) 3474 (3473 . 3474) (3472 . 3474) ("(" . -3472) (3472 . 3473) (t 26134 59631 60473 926000) nil (3426 . 3428) (t 26134 59618 340473 147000) nil (3457 . 3465) nil (3443 . 3452) nil (3443 . 3447) nil ("TODO: show final results here" . 3443) nil (nil rear-nonsticky nil 3431 . 3432) ("
" . -3474) (3428 . 3475) 3401 nil (3585 . 3586) (t 26134 59574 523803 802000) 3582 nil (")" . 3582) nil ("(" . 3582) nil (nil rear-nonsticky nil 3586 . 3587) (nil fontified nil 3558 . 3587) (3558 . 3587) (t 26134 59545 943802 55000) nil (")" . 3535) nil (3513 . 3520) nil ("list " . 3513) nil ("(" . 3513) nil ("cons " . 3513) nil (3794 . 3795) (t 26134 59231 83782 778000) nil (3791 . 3793) ("(" . -3791) (3791 . 3792) (t 26134 59172 533779 195000) nil (3539 . 3540) nil (")" . 3524) nil (3519 . 3524) (3518 . 3520) ("(" . -3518) (3518 . 3519) (t 26134 58978 963767 344000) nil (apply -30 731 1004 undo--wrap-and-run-primitive-undo 731 1004 ((970 . 973) (946 . 949) (915 . 918) (891 . 894) (860 . 863) (836 . 839) (812 . 815) (781 . 784) (750 . 753) (731 . 734) 973)) nil (444 . 445) (t 26134 58960 607099 554000) 375 nil (";; (asdf:load-system :cl-csv)
" . 445) nil ("
" . 740) nil (";; (ql:quickload \"cl-csv\")
" . 740) (t 26134 58940 670431 668000) nil (apply 15 1031 1222 undo--wrap-and-run-primitive-undo 1031 1222 ((";; " . -1197) (";; " . -1132) (";; " . -1111) (";; " . -1049) (";; " . -1031) 1237)) nil (766 . 767) (t 26134 58933 193764 543000) 763 nil (apply -3 740 767 undo--wrap-and-run-primitive-undo 740 767 ((740 . 743) 762)) nil (nil ws-butler-chg delete 764 . 765) (740 . 764) nil ("(ql:quickload \"cl-csv\")
" . 740) 762 nil (apply 6 475 578 undo--wrap-and-run-primitive-undo 475 578 ((";; " . -530) (";; " . -475) 584)) nil (724 . 726) (703 . 724) (696 . 703) ("o" . -696) ("t" . -697) 698 (692 . 698) (" " . -692) ("s" . -693) ("i" . -694) ("n" . -695) 696 (683 . 696) ("Psate" . -683) 688 (683 . 688) ("Run " . -683) 687 ("this " . -687) 692 ("comm" . -692) 696 (680 . 696) (679 . 680) (t 26134 58893 710428 796000) 679 nil (apply -6 475 585 undo--wrap-and-run-primitive-undo 475 585 ((533 . 536) (475 . 478) 578)) nil (apply 6 475 578 undo--wrap-and-run-primitive-undo 475 578 ((";; " . -530) ((marker . 744) . -2) ((marker . 504) . -1) ((marker . 504) . -1) ((marker . 504) . -1) ((marker . 504) . -1) ((marker . 504) . -1) ((marker . 504) . -1) ((marker . 504) . -1) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 83) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) ((marker . 504) . -2) (";; " . -475) ((marker . 748) . -2) ((marker . 446) . -1) ((marker . 446) . -1) ((marker . 446) . -1) ((marker . 446) . -1) ((marker . 446) . -1) ((marker . 446) . -1) ((marker . 446) . -1) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) ((marker . 446) . -2) 584)) nil (nil rear-nonsticky nil 698 . 699) ("
" . -722) (698 . 723) nil ("(ql:quickload \"cl-csv\")
" . 445) 449 nil (apply 3 445 468 undo--wrap-and-run-primitive-undo 445 468 ((";; " . -445) 449)) nil (apply -6 502 612 undo--wrap-and-run-primitive-undo 502 612 ((560 . 563) (502 . 505) 605)) nil (apply -9 1069 1190 undo--wrap-and-run-primitive-undo 1069 1190 ((1161 . 1164) (1093 . 1096) (1069 . 1072) 1180)) nil (apply -6 983 1069 undo--wrap-and-run-primitive-undo 983 1069 ((1004 . 1007) (983 . 986) 1062)) nil (718 . 719) (t 26134 55526 680222 662000) 701 nil (";" . 700) nil (700 . 701) nil ("

" . 700) (nil ws-butler-chg delete 702 . 703) (701 . 702) (nil rear-nonsticky t 700 . 701) nil (nil rear-nonsticky nil 700 . 701) ("
" . -701) (700 . 702) nil ("

" . 700) (nil ws-butler-chg delete 702 . 703) (701 . 702) (nil rear-nonsticky t 700 . 701) nil (nil rear-nonsticky nil 700 . 701) ("
" . -701) (700 . 702) nil ("(tes)
" . 719) 722 nil (720 . 723) (719 . 721) ("(" . -719) (719 . 720) (t 26134 53258 470083 948000) nil (718 . 719) 704 nil ("test
" . 719) 722 nil ("d" . -723) ("d" . -724) 725 (723 . 725) (719 . 723) (t 26134 53232 613415 699000) nil (699 . 700) 639 nil ("fork
" . 700) 703 nil (nil fontified t 700 . 704) (nil ws-butler-chg chg 700 . 704) ("force" . -700) (705 . 709) 705 (nil fontified t 700 . 705) (nil ws-butler-chg chg 700 . 705) ("format" . -700) (706 . 711) 706 (nil fontified t 703 . 706) (nil ws-butler-chg chg 703 . 706) ("for" . -700) (703 . 709) 703 (702 . 703) ("r" . -702) ("m" . -703) ("a" . -704) ("t" . -705) ("-" . -706) ("c" . -707) ("o" . -708) ("n" . -709) ("t" . -710) ("r" . -711) ("o" . -712) ("l" . -713) ("d" . -714) 715 (714 . 715) (nil fontified t 705 . 714) (nil ws-butler-chg chg 705 . 714) ("formatter" . -700) (709 . 723) 709 (nil fontified t 703 . 709) (nil ws-butler-chg chg 703 . 709) ("format" . -700) (706 . 715) 706 nil (705 . 706) ("t" . -705) ("t" . -706) ("e" . -707) ("r" . -708) ("j" . -709) 710 (709 . 710) (nil fontified t 703 . 709) (nil ws-butler-chg chg 703 . 709) ("format" . -700) (706 . 715) 706 (nil fontified t 702 . 706) (nil ws-butler-chg chg 702 . 706) ("form" . -700) (704 . 710) 704 (700 . 704) (700 . 701) 706 nil ("logtest
" . 700) 706 nil (700 . 703) 704 (700 . 704) nil (699 . 700) 640 nil ("test
" . 700) 703 nil (700 . 704) (t 26134 53138 443409 935000) nil ("i" . -700) ("t" . -701) 702 (700 . 702) (t 26134 53092 433407 124000) nil ("test" . -605) 609 (605 . 609) nil (981 . 982) 960 nil ("slynk:mop
" . 982) 990 nil (982 . 991) ("sly" . -982) 985 (984 . 985) (982 . 984) (t 26134 52741 953385 707000) nil ("
" . 719) ("(" . 720) (nil ws-butler-chg delete 721 . 722) (720 . 721) ("()" . 720) ("form" . 721) ("at" . 725) (" tes" . 727) ("b" . 731) (731 . 732) ("-" . 731) (nil ws-butler-chg delete 732 . 733) (731 . 732) ("; 
;           |\\___/|
;           )     (             .              '
;          =\\     /=
;            )===(       *
;           /     \\
;           |     |   Hack and be merry!
;          /       \\
;          \\       /
;   jgs_/\\_/\\__  _/_/\\_/\\_/\\_/\\_/\\_/\\_/\\_/\\_/\\_
;   |  |  |  |( (  |  |  |  |  |  |  |  |  |  |
;   |  |  |  | ) ) |  |  |  |  |  |  |  |  |  |
;   |  |  |  |(_(  |  |  |  |  |  |  |  |  |  |
;   |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
;   |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
; 
; Dedicated output stream setup (port 36237)
; Redirecting all output to this MREPL
; SLY 1.0.43 (#<MREPL mrepl-1-1>)
CL-USER> " . 731) (nil fontified t 1331 . 1363) (nil fontified t 1329 . 1331) (nil fontified t 1328 . 1329) (nil fontified t 1292 . 1328) (nil fontified t 1291 . 1292) (nil fontified t 1290 . 1291) (nil fontified t 1247 . 1290) (nil fontified t 1245 . 1247) (nil fontified t 1244 . 1245) (nil fontified t 1242 . 1244) (nil fontified t 1198 . 1242) (nil fontified t 1194 . 1198) (nil fontified t 1150 . 1194) (nil fontified t 1146 . 1150) (nil fontified t 1102 . 1146) (nil fontified t 1098 . 1102) (nil fontified t 1054 . 1098) (nil fontified t 1050 . 1054) (nil fontified t 1006 . 1050) (nil fontified t 1002 . 1006) (nil fontified t 958 . 1002) (nil fontified t 954 . 958) (nil fontified t 944 . 954) (nil fontified t 933 . 944) (nil fontified t 923 . 933) (nil fontified t 912 . 923) (nil fontified t 883 . 912) (nil fontified t 871 . 883) (nil fontified t 863 . 871) (nil fontified t 851 . 863) (nil fontified t 837 . 851) (nil fontified t 824 . 837) (nil fontified t 814 . 824) (nil fontified t 803 . 814) (nil fontified t 766 . 803) (nil fontified t 754 . 766) (nil fontified t 746 . 754) (nil fontified t 734 . 746) (nil fontified t 731 . 734) (nil rear-nonsticky t 1371 . 1372) nil (nil ws-butler-chg delete 1290 . 1291) (1245 . 1290) nil ("; Dedicated output stream setup (port 36237)
" . 1245) 1253 nil (nil rear-nonsticky nil 1371 . 1372) (nil fontified nil 731 . 1372) (731 . 1372) ("-" . -731) 732 (731 . 732) ("b" . -731) 732 (731 . 732) (727 . 731) (725 . 727) (721 . 725) (720 . 722) ("(" . -720) (720 . 721) (719 . 720) 719 nil ("(form)
" . 720) 724 nil (721 . 725) (720 . 722) ("(" . -720) (720 . 721) (719 . 720) nil ("(form)
" . 720) (t 26134 52651 693380 197000) nil (721 . 725) (720 . 722) ("(" . -720) (720 . 721) nil ("(force-outputdd)
" . 720) nil ("(format t ql:help)
" . 737) nil (755 . 756) (t 26134 52633 726712 433000) 742 nil ("(form)
" . 756) 760 nil (760 . 761) ("k" . -760) ("f" . -761) ("o" . -762) 763 (761 . 763) (nil fontified t 757 . 761) (nil ws-butler-chg chg 757 . 761) ("force" . -757) (762 . 766) 762 (nil fontified t 757 . 762) (nil ws-butler-chg chg 757 . 762) ("format" . -757) (763 . 768) 763 (nil fontified t 760 . 763) (nil ws-butler-chg chg 760 . 763) ("for" . -757) (760 . 766) 760 (757 . 760) (756 . 758) ("(" . -756) (756 . 757) ("i" . -756) 757 (756 . 757) (755 . 756) 754 nil ("he" . 754) (747 . 754) 749 (747 . 749) ("\"" . -747) ("\"" . 748) ("h" . -748) 749 (748 . 749) (747 . 749) ("\"" . -747) (745 . 748) (744 . 745) (742 . 744) (741 . 742) (738 . 741) (737 . 739) ("(" . -737) (737 . 738) (736 . 737) 734 nil (733 . 735) (nil fontified t 728 . 733) (nil ws-butler-chg chg 728 . 733) ("force" . -721) (726 . 738) 726 (nil fontified t 721 . 726) (nil ws-butler-chg chg 721 . 726) ("format" . -721) (727 . 732) 727 (nil fontified t 724 . 727) (nil ws-butler-chg chg 724 . 727) ("for" . -721) (724 . 730) 724 (721 . 724) ("f" . -721) ("o" . -722) ("r" . -723) ("m" . -724) ("a" . -725) ("t" . -726) 727 (725 . 727) (724 . 725) (721 . 724) (720 . 722) ("(" . -720) (720 . 721) (719 . 720) (t 26134 52047 840009 921000) 719 nil (718 . 719) 704 nil ("(for)
" . 719) 722 nil (720 . 723) (719 . 721) ("(" . -719) (719 . 720) (t 26134 51924 226669 32000) nil ("d" . -605) ("w" . -606) 607 (605 . 607) (t 26134 51791 116660 887000) nil ("(" . -719) (")" . 720) (719 . 721) ("(" . -719) (719 . 720) nil ("(format)
" . 502) 508 nil (507 . 509) (503 . 507) (502 . 504) ("(" . -502) (502 . 503) (t 26134 51216 136625 678000) nil (719 . 720) 705 nil ("(qui)
" . 720) 723 nil (721 . 724) (720 . 722) ("(" . -720) (720 . 721) (t 26134 49400 79847 575000) nil (3763 . 3765) ("(" . -3763) (3762 . 3764) (" " . -3762) (3762 . 3763) ("'" . -3762) (3762 . 3763) ("nil" . 3762) (t 26134 49388 569846 869000) nil (" " . 3767) nil (3762 . 3767) (3761 . 3762) nil ("'()))" . 3762) (t 26134 49370 426512 424000) nil (3763 . 3765) ("(" . -3763) (3762 . 3764) (" " . -3762) (3762 . 3763) ("'" . -3762) (3762 . 3763) nil ("nil" . 3762) (t 26134 49343 289844 93000) nil (3739 . 3740) (3736 . 3739) nil ("rhist " . 3736) (t 26134 49252 443171 855000) nil (3412 . 3427) nil ("rhist" . 3412) (t 26134 49238 973171 29000) nil (3487 . 3488) (3483 . 3487) nil ("rhist " . 3499) (t 26134 49231 519837 238000) nil (3164 . 3172) (" " . -3164) 3165 (3164 . 3165) (3157 . 3164) ("rhist" . 3157) nil ("
" . 3122) nil ("(defun ranking-history (rhist rankings)
  (append rhist (list rankings)))
" . 3122) 3132 (t 26134 47900 16422 293000) nil (apply 30 741 983 undo--wrap-and-run-primitive-undo 741 983 ((";; " . -953) (";; " . -932) (";; " . -904) (";; " . -883) (";; " . -855) (";; " . -834) (";; " . -813) (";; " . -785) (";; " . -757) (";; " . -741) 1013)) nil (720 . 721) (t 26134 47570 189735 406000) nil ("  ;; (ql:quickload '(:with-user-abort …) :silent t))
" . 606) 607 nil (nil rear-nonsticky nil 502 . 503) ("
" . -772) (502 . 773) (t 26134 6755 887235 640000) nil (nil ws-butler-chg delete 3007 . 3008) (2974 . 3007) nil ("  (append rhist (list rankings)))" . 2974) (t 26134 6755 887235 640000) nil ("(setq ballots
  (cl-csv:read-csv #P\"/home/nick/git/rcv/data/ballots.csv\"))
" . 3644) 3658 (t 26134 6703 140565 737000) nil (3632 . 3635) nil (")" . 3632) nil ("(" . 3632) nil ("'" . 3632) nil (")" . -3637) 3638 nil ("(" . 3622) (t 26134 6678 593897 565000) nil (apply 3 3596 3639 undo--wrap-and-run-primitive-undo 3596 3639 ((";; " . -3598) 3608)) nil ("  (format t \"TEST\")
" . 3596) 3608 (t 26134 6658 347229 659000) nil (apply -3 3616 3663 undo--wrap-and-run-primitive-undo 3616 3663 ((3618 . 3621) 3632)) nil (3609 . 3613) (3608 . 3610) ("\"" . -3608) (3606 . 3609) ("n" . -3606) ("i" . -3607) 3608 ("l" . -3608) (" " . -3609) ("\"" . -3610) ("\"" . 3611) (3610 . 3612) ("\"" . -3610) (3610 . 3611) ("\"" . -3610) ("\"" . 3611) (3610 . 3612) ("\"" . -3610) (3609 . 3611) (" " . -3609) 3610 (3606 . 3610) ("t" . -3606) (" " . -3607) 3608 (3606 . 3608) ("n" . -3606) 3607 (3599 . 3607) (3598 . 3600) ("(" . -3598) (3598 . 3599) (3596 . 3598) ("  " . 3595) (3597 . 3598) (3594 . 3597) (t 26134 6555 163889 991000) 3582 nil (")" . 3732) nil ("(" . 3725) nil (3734 . 3735) nil (")" . 3726) nil (3725 . 3727) ("(" . -3725) (3725 . 3726) (t 26134 6516 367220 940000) nil ("*" . 3658) nil ("*" . 3651) nil (3646 . 3651) ("l" . -3646) ("e" . -3647) ("t" . -3648) 3649 (3646 . 3649) nil ("defvar " . 3646) nil (nil rear-nonsticky nil 3644 . 3645) ("
" . -3723) (3644 . 3724) (t 26134 6493 350552 863000) nil ("*" . 3657) nil ("*" . 3650) (t 26134 6450 363883 558000) nil (3658 . 3659) nil (3650 . 3651) (t 26134 6441 720549 694000) nil (3646 . 3657) (3645 . 3647) ("(" . -3645) (3645 . 3646) (3644 . 3645) (3643 . 3644) (t 26134 6285 487206 778000) 3642 nil (3637 . 3638) nil (")" . 3622) nil (3621 . 3623) ("(" . -3621) (3621 . 3622) (t 26134 6269 403872 459000) nil (")" . 3634) (3633 . 3634) (3632 . 3634) ("(" . -3632) (3631 . 3633) (" " . -3631) (3631 . 3632) ("'" . -3631) (3631 . 3632) (3630 . 3631) (" " . -3630) 3631 (3620 . 3631) (3610 . 3620) (3609 . 3611) ("(" . -3609) (3608 . 3610) (" " . -3608) 3609 (3598 . 3609) (3597 . 3599) ("(" . -3597) (3597 . 3598) (3595 . 3597) (t 26134 6221 370536 182000) nil (3322 . 3331) (t 26134 6150 557198 510000) nil (")" . 2309) nil (2290 . 2291) (t 26134 6127 130530 407000) nil ("s" . 2228) (t 26134 6015 537190 229000) nil (3291 . 3295) (3290 . 3291) (t 26134 6001 757189 385000) nil (3220 . 3228) nil (3210 . 3213) (3209 . 3210) (" " . -3209) 3210 (t 26134 5993 883855 569000) nil ("  " . 3572) nil (3215 . 3221) (3194 . 3215) ("end" . -3194) 3197 (3194 . 3197) (3173 . 3194) (" " . -3173) 3174 (3173 . 3174) nil ("(display-results rankings)" . 3173) nil (3208 . 3211) ("	" . -3208) nil ("
" . 3208) nil (nil rear-nonsticky nil 3209 . 3210) ("
" . -3252) (3208 . 3253) nil ("	  " . -3208) 3211 (3207 . 3211) 3202 nil (3208 . 3211) (" " . 3207) (3208 . 3209) nil ("	(format t \"TODO: show final results here\")
" . 3200) 3207 nil (3246 . 3252) (3245 . 3247) ("(" . -3245) (3245 . 3246) (3243 . 3245) 3200 nil (3535 . 3537) ("  " . 3534) (3536 . 3537) (3534 . 3536) (t 26134 5874 693848 258000) nil ("    ;; Entrypoint
" . 3535) 3539 nil ("    (tournament-round ballots nil 1))
" . 3553) 3557 nil ("
" . 3535) nil ("  (labels ((tournament-round (ballots rankings counter)
	     (setq rankings (tournament ballots))
	     (if (has-majority rankings)
		 (display-results rankings)
		 (tournament-round result (incf counter)))))
" . 3535) 3583 (t 26134 5861 217180 764000) nil (3222 . 3241) (3218 . 3222) (" " . -3218) 3219 (3212 . 3219) (3211 . 3213) ("\"" . -3211) (3202 . 3212) (" " . -3202) 3203 (3202 . 3203) (3201 . 3203) ("(" . -3201) (3201 . 3202) (3199 . 3201) 3179 nil (apply -3 3169 3200 undo--wrap-and-run-primitive-undo 3169 3200 ((3170 . 3173) 3172)) nil (3249 . 3251) (" " . 3248) (3249 . 3250) nil (3232 . 3234) (" " . 3231) (3232 . 3233) nil (3269 . 3278) (3264 . 3269) (" " . -3264) 3265 (3259 . 3265) (3248 . 3259) (3247 . 3249) ("(" . -3247) (3246 . 3248) nil (3210 . 3212) (" " . 3209) (3210 . 3211) (t 26134 5656 990501 568000) nil (3220 . 3221) nil ("-" . 3220) nil ("candidate " . 3221) (t 26134 5639 953833 853000) nil (2157 . 2158) nil (2151 . 2157) (2130 . 2151) (2120 . 2130) ("Final" . -2120) 2125 (2120 . 2125) (2119 . 2121) ("\"" . -2119) (2119 . 2120) (2116 . 2119) (t 26134 5623 233832 831000) 2105 nil ("
" . -2266) (" " . -2267) (" " . -2268) 2269 (t 26134 5612 17165 477000) nil (2126 . 2136) nil ("place " . 2126) nil ("-" . 2126) nil ("last" . 2126) (t 26134 5597 207164 568000) nil (2250 . 2257) ("	    " . -2250) 2264 nil (2189 . 2196) ("	    " . -2189) 2205 nil (2159 . 2163) ("  " . -2159) 2180 nil (2259 . 2261) nil (")" . 2158) nil (2143 . 2155) ("s" . -2143) ("a" . -2144) ("t" . -2145) (" " . -2146) 2147 (2138 . 2147) (2137 . 2139) ("(" . -2137) (2136 . 2138) (2126 . 2136) (2125 . 2127) ("(" . -2125) (2125 . 2126) (2124 . 2126) ("(" . -2124) (2120 . 2125) (2119 . 2121) ("(" . -2119) (2119 . 2120) (2116 . 2119) (t 26134 5537 377160 902000) 2100 nil (2142 . 2143) 2156 nil (2203 . 2208) ("	  " . -2203) 2213 nil (2144 . 2149) ("  " . -2144) 2198 nil (")" . -2199) 2200 nil (nil rear-nonsticky nil 2145 . 2146) (2144 . 2201) ("	    (eliminate-candidate candidate ballot))
" . 2144) 2189 (t 26134 5502 233825 414000) nil (")" . -2200) 2201 nil ("
" . 2117) nil (nil rear-nonsticky nil 2119 . 2120) ("
" . -2202) (2117 . 2203) nil ("  " . -2117) 2119 (2116 . 2119) 2083 nil (2116 . 2119) (t 26134 5465 233823 147000) nil (2099 . 2108) (t 26134 5454 143822 465000) nil (2099 . 2106) (2098 . 2100) ("(" . -2098) (2097 . 2099) (2082 . 2097) (2081 . 2083) ("(" . -2081) (2081 . 2082) (2080 . 2081) (2079 . 2080) (t 26134 5414 273820 18000) 2078 nil (3007 . 3008) nil (")" . 3000) nil (2980 . 3000) (2979 . 2981) ("(" . -2979) (2979 . 2980) (t 26134 5382 617151 412000) nil (2979 . 2986) ("rankings" . -2979) 2987 (2979 . 2987) ("result" . 2979) (t 26134 5323 647147 798000) nil (2814 . 2819) ("v" . -2814) ("o" . -2815) ("t" . -2816) ("e" . -2817) ("-" . -2818) 2819 (2806 . 2819) (2805 . 2806) (t 26134 5263 573810 781000) nil (2964 . 2965) nil ("round " . 2964) nil ("-" . 2964) (t 26134 5252 813810 121000) nil (2890 . 2891) nil (")" . 2866) nil (2865 . 2867) ("(" . -2865) (2856 . 2866) nil (2879 . 2880) nil (2853 . 2855) ("    " . -2853) 2880 nil (")" . -2852) 2853 nil (2813 . 2814) (t 26134 5216 993807 922000) nil (2983 . 2984) nil (")" . -2983) (")" . -2984) (")" . -2985) 2986 nil (2942 . 2943) ("		 " . -2942) 2943 nil (2914 . 2915) ("		 " . -2914) nil (2882 . 2886) ("	     " . -2882) 2888 nil (nil rear-nonsticky nil 2887 . 2888) ("
" . -2992) (2881 . 2993) 2853 (t 26134 4610 127104 48000) nil (2776 . 2777) nil (")" . 2766) nil (2761 . 2766) (2760 . 2762) ("(" . -2760) (2760 . 2761) (t 26134 4590 330436 168000) nil (2753 . 2768) (2747 . 2753) (2746 . 2748) ("(" . -2746) (2746 . 2747) (2743 . 2746) (t 26134 4578 837102 128000) nil (2729 . 2730) nil ("h" . 2729) nil ("-" . 2729) nil ("ank" . 2729) nil (2732 . 2746) (2728 . 2732) ("hist " . -2728) 2733 (2728 . 2733) ("rhist " . -2728) 2734 (2730 . 2734) ("s" . -2730) 2731 (2728 . 2731) (2727 . 2729) ("(" . -2727) (2727 . 2728) (2718 . 2727) (" " . -2718) 2719 (2705 . 2719) (2704 . 2706) ("(" . -2704) (2704 . 2705) (2703 . 2704) (2702 . 2703) (t 26134 4306 580418 782000) 2695 nil (3279 . 3280) nil ("
" . -3279) 3280 nil ("
" . 3280) nil ("(defun test ()
  (labels ((tournament-round (counter)
	     (if (>= counter 10)
		 (format t \"WINNER!\")
		 (tournament-round (incf counter)))))
    (tournament-round 1)))
" . 3281) 3283 (t 26134 4237 323747 874000) nil (2794 . 2805) (2793 . 2794) (t 26134 4226 610413 884000) nil (nil ws-butler-chg delete 2752 . 2753) (2741 . 2752) nil ("top-choices" . 2741) 2793 (t 26134 4226 610413 884000) nil (2783 . 2793) (t 26134 4212 557079 691000) nil (1000 . 1006) nil ("choices " . 1000) nil ("-" . 1000) nil ("top" . 1000) nil (" " . -2789) 2790 (2789 . 2790) (2788 . 2790) ("(" . -2788) (2788 . 2789) (2783 . 2788) (t 26134 4043 807069 339000) 2782 nil (2783 . 2788) nil (2769 . 2780) (" " . -2769) 2770 (2768 . 2770) (" " . -2768) (2768 . 2769) ("'" . -2768) (2767 . 2769) ("'" . -2767) ("#" . -2768) 2769 (2767 . 2769) (" " . -2767) (2767 . 2768) ("'" . -2767) (2767 . 2768) ("#" . -2767) ("'" . -2768) 2769 (2768 . 2769) (" " . -2768) (2768 . 2769) ("'" . -2768) (2768 . 2769) ("+" . -2768) 2769 (2760 . 2769) (2759 . 2761) ("(" . -2759) (2756 . 2760) (2753 . 2756) ("p" . -2753) ("o" . -2754) ("i" . -2755) 2756 (2747 . 2756) ("ballot" . -2747) 2753 (2747 . 2753) ("t" . -2747) ("o" . -2748) ("p" . -2749) (" " . -2750) 2751 (2750 . 2751) (2747 . 2750) (2746 . 2748) ("(" . -2746) (2746 . 2747) (2745 . 2747) ("(" . -2745) (2741 . 2746) (2740 . 2742) ("(" . -2740) (2740 . 2741) (2738 . 2740) (t 26134 3998 323733 216000) nil (2739 . 2741) ("  " . 2738) (2737 . 2741) (")" . 2737) (2731 . 2737) (2729 . 2731) (2728 . 2730) ("(" . -2728) (2711 . 2729) (2710 . 2712) ("(" . -2710) (2710 . 2711) (2709 . 2710) (2708 . 2709) (t 26134 3960 357064 223000) 2707 nil (2990 . 2997) nil (2991 . 2992) (")" . 2991) (2990 . 2991) (" " . -2990) (2990 . 2991) (")" . -2990) (2989 . 2991) nil (")" . 2979) nil (2978 . 2980) ("(" . -2978) (2978 . 2979) nil (2982 . 2988) (2964 . 2982) (2963 . 2965) ("(" . -2963) (2963 . 2964) (2956 . 2963) (t 26134 3907 773727 667000) 2936 nil (3117 . 3121) (t 26134 3895 967060 277000) nil (2939 . 2948) (t 26134 3069 200342 934000) nil ("
" . 2086) nil (";; (defun tournament (ballots)
;;   (let* ((top-choices (mapcar #'car ballots))
;; 	 (rankings (rank-top-choices top-choices)))
;;     ;; (print-tournament)
;;     rankings)
;;   )
" . 2087) 2267 (t 26134 3060 30342 372000) nil (" " . -1998) 1999 ("from " . -1999) 2004 ("the " . -2004) 2008 ("b" . -2008) 2009 (1998 . 2009) (t 26134 3031 290340 611000) nil (1829 . 1833) nil ("ballot" . 1829) (t 26134 2990 190338 92000) nil (1831 . 1835) (1814 . 1831) nil (1772 . 1779) nil ("Eliminate " . 1772) (t 26134 2968 447003 426000) nil ("
" . 1492) nil ("(rank-top-choices '(Bush Gore Bush Gore Nader Gore Yeet))
" . 1492) 1548 (t 26134 2945 553668 690000) nil ("
" . 988) nil ("(defun unique-candidates (ballots)
  \"Get a list of the unique candidates.\"
  (remove-duplicates (loop for sublist in ballots append sublist)
                     :test #'string=))

(defun get-candidates (ballots)
  (unless (null ballots)
    (remove-duplicates (reduce #'append ballots :key #'identity)
		       :test #'string=)))
" . 988) 1292 (t 26134 2916 463666 907000) nil (apply -30 523 795 undo--wrap-and-run-primitive-undo 523 795 ((762 . 765) (738 . 741) (707 . 710) (683 . 686) (652 . 655) (628 . 631) (604 . 607) (573 . 576) (542 . 545) (523 . 526))) nil ("
" . 766) nil (nil rear-nonsticky nil 766 . 767) ("
" . -957) (766 . 958) nil (765 . 766) (764 . 765) 743 nil ("
" . 2801) nil (nil rear-nonsticky nil 2801 . 2802) ("
" . -3045) (2801 . 3046) nil (2800 . 2801) (2799 . 2800) (t 26134 2457 720305 455000) 2791 nil (nil ws-butler-chg delete 3071 . 3072) (3063 . 3071) nil ("rankings" . 3063) 3045 (t 26134 2457 720305 455000) nil (3147 . 3149) (t 26134 2444 446971 308000) nil (nil ws-butler-chg delete 3144 . 3145) (3137 . 3144) nil ("counter" . 3137) 3101 nil (3137 . 3144) ("r" . -3137) 3138 (3132 . 3138) (3131 . 3133) ("(" . -3131) (3123 . 3132) (3112 . 3123) ("m" . -3112) ("a" . -3113) 3114 (3107 . 3114) (" " . -3107) 3108 (3107 . 3108) (" " . -3107) 3108 (3107 . 3108) (3106 . 3108) ("(" . -3106) (3106 . 3107) (3102 . 3106) nil (3084 . 3101) (" " . -3084) 3085 (3077 . 3085) (3076 . 3078) ("(" . -3076) (3076 . 3077) (3072 . 3076) nil (3061 . 3071) (3050 . 3061) (3049 . 3051) ("(" . -3049) (3046 . 3050) (3045 . 3047) ("(" . -3045) (3045 . 3046) ("i" . -3045) 3046 (3045 . 3046) (3038 . 3045) 3037 nil ("    (display-results rankings)))
" . 3039) 3070 nil ("      (tournament-round result (incf round-num)))
" . 3039) 3073 nil ("    (unless (has-majority rankings)
" . 3039) 3073 nil (3030 . 3037) nil ("round-num" . 3030) (t 26134 2250 800292 775000) nil (3349 . 3356) ("r" . -3349) ("o" . -3350) ("u" . -3351) ("n" . -3352) 3353 (3349 . 3353) ("round-num" . 3349) (t 26134 2233 210291 696000)) (emacs-pending-undo-list (260 . 261) nil ("\"" . 254) ((marker* . 796) . 1) nil (253 . 255) ("\"" . -253) (253 . 254) nil (":" . 253) nil (243 . 244) nil ("\"" . 236) ((marker* . 796) . 1) nil (235 . 237) ("\"" . -235) (235 . 236) nil (":" . 235) ((marker . 1) . -1) ((marker . 1212) . -1) (t 26135 10621 618153 940000) nil (373 . 377) ("rcv" . 373) ((marker . 614) . -2) (t 26135 10615 561486 904000) nil (apply -9 433 525 undo--wrap-and-run-primitive-undo 433 525 ((497 . 500) (470 . 473) (435 . 438) 516)) nil (":" . 27) nil ("asdf" . 27) ((marker . 614) . -3) nil (apply -3 1 26 undo--wrap-and-run-primitive-undo 1 26 ((1 . 4))) nil (nil rear-nonsticky nil 22 . 23) ("
" . -44) (22 . 45) 21 (t 26135 10483 601478 836000) nil (574 . 575) nil ("\"" . 564) nil (564 . 566) ("\"" . -564) (564 . 565) nil (":" . 564) ((marker . 601) . -1) nil ("#" . 564) (t 26135 10474 88144 920000) nil (21 . 22) nil ("\"" . 18) ((marker* . 796) . 1) nil (17 . 19) ("\"" . -17) (17 . 18) nil (":" . 17) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) (t 26135 10453 571476 998000) nil (530 . 533) nil ("params" . 530) ((marker . 614) . -5) nil ("-" . 530) nil ("safety" . 530) ((marker . 614) . -5) (t 26135 10435 688142 572000) nil (")" . 553) nil (nil rear-nonsticky nil 553 . 554) (nil fontified nil 495 . 554) (495 . 554) ("  :in-ord" . 495) ((marker . 614) . -8) ((marker . 1) . -8) ((marker . 1212) . -8) ((marker . 614) . -8) 505 nil (497 . 504) (494 . 497) (t 26135 10268 658132 345000) 483 nil (nil ws-butler-chg delete 198 . 199) (181 . 198) nil ("  :version \"0.1\"
" . 181) ((marker . 614) . -16) ((marker . 614) . -15) 196 (t 26135 10268 658132 345000) nil (514 . 515) nil ("#" . 514) nil (514 . 515) (t 26135 9473 521417 7000) nil (352 . 355) ("i" . -352) ((marker . 614) . -1) 353 (352 . 353) ("main" . 352) ((marker . 614) . -3) nil (352 . 356) ("i" . -352) ((marker . 614) . -1) ("m" . -353) ((marker . 614) . -1) 354 (352 . 354) ("rcv" . 352) ((marker . 614) . -2) (t 26135 9460 634749 550000) nil (792 . 796) nil ("test" . 792) ((marker . 614) . -3) nil ("-" . 792) nil ("rcv" . 792) ((marker . 614) . -2) (t 26135 9452 404749 47000) nil (523 . 524) (t 26135 9360 838076 772000) nil (518 . 519) ("." . 518) (t 26135 9185 958066 58000) nil (518 . 519) ("/" . 518) (t 26135 8952 938051 800000) nil (669 . 677) (" " . 668) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1212) . -1) ((marker . 185) . -1) (669 . 670) (t 26135 8947 4718 104000) nil (253 . 261) (" " . 252) ((marker . 275) . -1) ((marker . 275) . -1) ((marker . 275) . -1) ((marker . 185) . -1) (253 . 254) nil (239 . 247) (" " . 238) ((marker . 185) . -1) (239 . 240) nil (223 . 231) (" " . 222) ((marker . 185) . -1) (223 . 224) (t 26135 8907 121382 331000) nil (896 . 897) nil (":rcv/test" . 896) ((marker* . 796) . 9) ((marker . 614) . -8) nil (895 . 896) (" " . -895) ((marker . 185) . -1) 896 (891 . 896) (" " . -891) ((marker . 185) . -1) 892 (891 . 892) (" " . -891) ((marker . 185) . -1) 892 (889 . 892) nil ("suite " . 889) ((marker . 614) . -5) nil ("-" . 889) nil ("run" . 889) ((marker . 614) . -2) nil (":" . 889) (t 26135 8869 324713 357000) nil (nil ws-butler-chg delete 849 . 850) (845 . 849) nil (845 . 846) (t 26135 8856 828045 927000) nil (":" . 845) nil ("asdf" . 845) ((marker . 614) . -3) ((marker . 185) . -1) ((marker . 185) . -4) 849 (t 26135 8419 374685 809000) nil (nil ws-butler-chg delete 849 . 850) (845 . 849) nil (845 . 846) (t 26135 8406 461351 687000) nil (":" . 845) nil ("asdf" . 845) ((marker . 614) . -3) (t 26135 8394 624684 297000) nil (646 . 650) (" " . -646) ((marker . 185) . -1) 647 (646 . 647) nil ("fiveam" . 646) ((marker . 614) . -5) ((marker) . -6) (t 26135 8045 321329 589000) nil (849 . 850) nil ("d" . 848) nil (":" . 852) (t 26135 8019 904661 366000) nil (847 . 853) nil (910 . 1018) (t 26135 7999 614660 126000) nil ("  ;; :perform (asdf:test-op (op system)
  ;;            (funcall (read-from-string \"rcv.test:run-tests\"))))
" . 910) ((marker . 1) . -78) ((marker . 614) . -107) ((marker . 1142) . -38) ((marker . 1142) . -38) ((marker . 1) . -38) ((marker . 1212) . -78) ((marker . 185) . -78) 988 (t 26135 7990 877992 924000) nil (901 . 902) nil ("." . 901) ((marker* . 796) . 1) nil (898 . 901) ("clingon" . 898) ((marker . 614) . -6) (t 26135 7675 374640 290000) nil (apply -6 914 1022 undo--wrap-and-run-primitive-undo 914 1022 ((956 . 959) (916 . 919) 1016)) nil (nil rear-nonsticky nil 912 . 913) (nil fontified nil 835 . 913) (835 . 913) (t 26135 7646 241305 171000) nil (695 . 696) (t 26135 7627 901304 51000) nil (apply -3 771 819 undo--wrap-and-run-primitive-undo 771 819 ((800 . 803) 799)) nil (815 . 824) nil (816 . 819) (t 26135 7610 637969 663000) nil (760 . 768) ("package" . 760) ((marker . 1) . -3) ((marker . 614) . -6) ((marker . 1) . -3) ((marker* . 1212) . 2) ((marker . 1) . -3) ((marker . 1212) . -4) (t 26135 7539 197965 293000) nil (apply 39 474 921 undo--wrap-and-run-primitive-undo 474 921 ((";; " . -856) ((marker . 1212) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 185) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) (";; " . -819) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) ((marker . 1104) . -1) (";; " . -770) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) ((marker . 912) . -1) (";; " . -723) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) ((marker . 868) . -1) (";; " . -697) ((marker . 842) . -1) ((marker . 842) . -1) ((marker . 842) . -1) ((marker . 842) . -1) ((marker . 842) . -1) ((marker . 842) . -1) ((marker . 842) . -1) (";; " . -666) ((marker . 810) . -1) ((marker . 810) . -1) ((marker . 810) . -1) ((marker . 810) . -1) ((marker . 810) . -1) ((marker . 810) . -1) ((marker . 810) . -1) (";; " . -654) ((marker . 798) . -1) ((marker . 798) . -1) ((marker . 798) . -1) ((marker . 798) . -1) ((marker . 798) . -1) ((marker . 798) . -1) ((marker . 798) . -1) (";; " . -625) ((marker . 761) . -1) ((marker . 761) . -1) ((marker . 761) . -1) ((marker . 761) . -1) ((marker . 761) . -1) ((marker . 761) . -1) ((marker . 761) . -1) ((marker . 761) . -1) (";; " . -607) ((marker . 743) . -1) ((marker . 743) . -1) ((marker . 743) . -1) ((marker . 743) . -1) ((marker . 743) . -1) ((marker . 743) . -1) ((marker . 743) . -1) (";; " . -585) ((marker . 721) . -1) ((marker . 721) . -1) ((marker . 721) . -1) ((marker . 721) . -1) ((marker . 721) . -1) ((marker . 721) . -1) ((marker . 721) . -1) ((marker . 721) . -1) (";; " . -537) ((marker . 673) . -1) ((marker . 673) . -1) ((marker . 673) . -1) ((marker . 673) . -1) ((marker . 673) . -1) ((marker . 673) . -1) ((marker . 673) . -1) (";; " . -500) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) ((marker . 636) . -1) (";; " . -474) ((marker . 1) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) ((marker . 582) . -1) 960)) nil ("
" . 474) ((marker* . 1212) . 1) nil (";; (asdf:defsystem :rcv/bin
;;   :depends-on (:rcv)
;;   :components ((:module \"src\"
;; 		:components ((:file \"main\")))))
" . 474) ((marker . 1) . -100) ((marker . 614) . -121) ((marker . 582) . -26) ((marker . 582) . -26) ((marker . 1) . -26) ((marker . 1212) . -100) ((marker . 185) . -100) 574 (t 26135 7327 871285 693000) nil (236 . 237) (232 . 236) nil ("fiveam " . 232) ((marker . 1) . -6) ((marker . 614) . -6) ((marker . 814) . -6) ((marker . 270) . -6) ((marker . 185) . -6) (t 26135 6984 904598 33000) nil (231 . 239) nil (" " . 236) nil ("5am" . 237) ((marker . 614) . -2) nil (":" . 237) (t 26135 6706 954581 36000) nil (236 . 241) (t 25908 35303 116669 640000)) (emacs-undo-equiv-table (-56 . -60) (-57 . -59) (-61 . -63) (-70 . -72) (-31 . -33) (18 . 20) (124 . 130) (126 . 128) (125 . 129) (204 . 206) (286 . 288) (243 . 245) (242 . 246) (122 . 132) (91 . 95) (60 . 62) (92 . 94) (221 . 223) (219 . 221) (217 . 219) (121 . 133) (123 . 131) (7 . 9) (-60 . -64)))