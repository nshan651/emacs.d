((buffer-size . 220) (buffer-checksum . "635f857a389791d193716449071caa1c41964695"))
((emacs-buffer-undo-list nil ("'" . 140) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker) . -1) ((marker) . -1) (t 26050 44855 936461 136000) nil (140 . 141) (t 26050 44683 799783 896000) nil ("`" . 140) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker . 140) . -1) ((marker) . -1) ((marker) . -1) (t 26050 44667 66449 533000) nil ("
" . 140) ((marker . 140) . -1) nil (140 . 141) (t 26050 44667 66449 533000) nil (140 . 141) (t 26050 44646 106448 246000) nil (43 . 46) (t 26050 44634 966447 562000) nil ("
" . 28) ((marker* . 88) . 1) nil ("(defmacro defshell (command)
  `(shell-command ,(if (listp command)
                       (mapconcat 'identity command \" \")
                     (format \"%s\" command))))
" . 28) ((marker . 140) . -170) ((marker . 140) . -137) ((marker . 87) . -137) ((marker . 87) . -12) ((marker . 140) . -12) 40 nil (210 . 213) nil (nil ws-butler-chg delete 365 . 366) (200 . 365) nil ("(defmacro sh (command)
  `(shell-command ,(if (listp command)
                       (mapconcat 'identity command \" \")
                     (format \"%s\" command))))
" . 200) ((marker . 140) . -164) ((marker* . 140) . 1) ((marker . 140) . -163) ((marker . 87) . -163) ((marker . 87) . -22) ((marker . 140) . -22) 222 nil (199 . 200) nil (nil rear-nonsticky nil 363 . 364) (nil fontified nil 199 . 364) (199 . 364) nil (198 . 199) (t 26050 44484 646438 331000) 171 nil (206 . 209) (t 26050 44459 499770 122000) nil (201 . 204) (t 26050 44454 233103 134000) nil (43 . 46) (t 26050 44448 713102 794000) nil (38 . 41) (t 26050 44421 973101 152000) nil ("
" . 28) ((marker . 28) . -1) ((marker* . 88) . 1) ((marker . 140) . -1) nil ("
" . 28) ((marker* . 88) . 1) nil ("(defmacro sh (command)
  `(shell-command ,command))
" . 28) ((marker . 140) . -51) ((marker . 140) . -23) ((marker . 87) . -23) nil (nil rear-nonsticky nil 247 . 248) ("
" . -261) (247 . 262) nil ("(sh '(ls -l))
" . 81) ((marker . 140) . -13) nil (nil rear-nonsticky nil 260 . 261) (nil fontified nil 96 . 261) (96 . 261) nil ("l" . -96) ((marker . 140) . -1) ("i" . -97) ((marker . 140) . -1) ("s" . -98) ((marker . 140) . -1) ("t" . -99) ((marker . 140) . -1) 100 (96 . 100) (95 . 96) (94 . 95) (t 26050 44169 289752 314000) 93 nil (92 . 94) (" " . -92) ((marker . 140) . -1) 93 (81 . 93) (80 . 81) (79 . 80) (t 26050 44146 176417 563000) 53) (emacs-pending-undo-list (140 . 141) (t 26050 44646 106448 246000) nil (43 . 46) (t 26050 44634 966447 562000) nil ("
" . 28) ((marker* . 88) . 1) nil ("(defmacro defshell (command)
  `(shell-command ,(if (listp command)
                       (mapconcat 'identity command \" \")
                     (format \"%s\" command))))
" . 28) ((marker . 140) . -170) ((marker . 140) . -137) ((marker . 87) . -137) ((marker . 87) . -12) ((marker . 140) . -12) 40 nil (210 . 213) nil (nil ws-butler-chg delete 365 . 366) (200 . 365) nil ("(defmacro sh (command)
  `(shell-command ,(if (listp command)
                       (mapconcat 'identity command \" \")
                     (format \"%s\" command))))
" . 200) ((marker . 140) . -164) ((marker* . 140) . 1) ((marker . 140) . -163) ((marker . 87) . -163) ((marker . 87) . -22) ((marker . 140) . -22) 222 nil (199 . 200) nil (nil rear-nonsticky nil 363 . 364) (nil fontified nil 199 . 364) (199 . 364) nil (198 . 199) (t 26050 44484 646438 331000) 171 nil (206 . 209) (t 26050 44459 499770 122000) nil (201 . 204) (t 26050 44454 233103 134000) nil (43 . 46) (t 26050 44448 713102 794000) nil (38 . 41) (t 26050 44421 973101 152000) nil ("
" . 28) ((marker . 28) . -1) ((marker* . 88) . 1) ((marker . 140) . -1) nil ("
" . 28) ((marker* . 88) . 1) nil ("(defmacro sh (command)
  `(shell-command ,command))
" . 28) ((marker . 140) . -51) ((marker . 140) . -23) ((marker . 87) . -23) nil (nil rear-nonsticky nil 247 . 248) ("
" . -261) (247 . 262) nil ("(sh '(ls -l))
" . 81) ((marker . 140) . -13) nil (nil rear-nonsticky nil 260 . 261) (nil fontified nil 96 . 261) (96 . 261) nil ("l" . -96) ((marker . 140) . -1) ("i" . -97) ((marker . 140) . -1) ("s" . -98) ((marker . 140) . -1) ("t" . -99) ((marker . 140) . -1) 100 (96 . 100) (95 . 96) (94 . 95) (t 26050 44169 289752 314000) 93 nil (92 . 94) (" " . -92) ((marker . 140) . -1) 93 (81 . 93) (80 . 81) (79 . 80) (t 26050 44146 176417 563000) 53) (emacs-undo-equiv-table (4 . -1) (-6 . -8)))