((buffer-size . 867) (buffer-checksum . "f22952f5561ad81a7ca0b5486cbac82f42cdf64e"))
((emacs-buffer-undo-list nil (apply 9 95 159 undo--wrap-and-run-primitive-undo 95 159 ((";; " . -132) (";; " . -105) (";; " . -97) 169))) (emacs-pending-undo-list (nil rear-nonsticky nil 59867 . 59868) (nil fontified nil 59805 . 59868) (59805 . 59868) nil ("  " . -59805) ((marker . 49810) . -2) 59807 (59804 . 59807) 59745 nil (59841 . 59843) ("de" . 59841) (t 26061 3899 271701 952000) nil ("** GPTel
An LLM client for Emacs.
#+begin_src emacs-lisp :tangle \"lisp/applications-config.el\" :mkdirp yes
  (use-package gptel)

#+end_src
" . 70066) 70199 (t 26061 3860 375032 910000) nil (" " . 70193) nil (70188 . 70193) ("c" . -70188) ("h" . -70189) ("a" . -70190) ("t" . -70191) 70192 (70188 . 70192) nil (70181 . 70188) ("g" . -70181) 70182 (70181 . 70182) (70176 . 70181) ("p" . -70176) ("k" . -70177) ("g" . -70178) ("-" . -70179) 70180 (70176 . 70180) nil ("package" . 70176) 70183 nil ("-" . 70183) 70184 nil ("install" . 70184) 70191 nil (70183 . 70192) (70181 . 70183) ("c" . -70181) ("k" . -70182) ("a" . -70183) ("g" . -70184) ("e" . -70185) (" " . -70186) 70187 (70181 . 70187) ("k" . -70181) 70182 (70176 . 70182) (70175 . 70177) ("(" . -70175) (70175 . 70176) (70172 . 70175) (t 26061 3769 411694 11000) 70155 nil (70148 . 70156) nil (70132 . 70137) nil (70132 . 70143) nil ("init" . 70132) nil (70100 . 70163) ("<ini" . -70100) 70104 (70100 . 70104) (70099 . 70100) (t 26061 3746 908359 301000) 70098 nil (70097 . 70099) (70076 . 70097) (" " . -70076) 70077 (70075 . 70077) (70074 . 70075) (" " . -70074) 70075 (70070 . 70075) ("p" . -70070) ("t" . -70071) ("e" . -70072) ("l" . -70073) 70074 (70070 . 70074) ("P" . -70070) 70071 (70069 . 70071) ("G" . -70069) ("P" . -70070) ("T" . -70071) ("e" . -70072) 70073 (70066 . 70073) (70065 . 70066) (t 26061 1921 41581 23000) 69756 nil (54916 . 54918) (54905 . 54920) ("
" . 54905) (54904 . 54906) 54840 (t 26061 1917 798247 492000) nil (54836 . 54838) (54856 . 54858) 54836 nil (54899 . 54900) (t 26061 1912 168247 145000) 54898 nil (54890 . 54899) (54889 . 54890) 54886 nil (54884 . 54887) (54883 . 54885) ("\"" . -54883) (54882 . 54884) (54870 . 54882) ("a" . -54870) ("f" . -54871) ("u" . -54872) ("l" . -54873) ("t" . -54874) 54875 (54857 . 54875) (54856 . 54858) ("(" . -54856) (54856 . 54857) (54855 . 54856) (54836 . 54855) (54835 . 54836) 54764 nil ("
" . 54764) nil (nil rear-nonsticky nil 54764 . 54765) ("
" . -54836) (54764 . 54837) nil (54763 . 54764) (54762 . 54763) (t 26061 1874 364911 497000) 54682 nil (54761 . 54762) (54749 . 54761) ("e" . -54749) 54750 (54748 . 54750) (54727 . 54748) nil (54715 . 54726) (54714 . 54715) (54693 . 54714) ("R" . -54693) ("e" . -54694) ("m" . -54695) 54696 (54681 . 54696) (54680 . 54682) ("(" . -54680) (54680 . 54681) (" " . -54680) 54681 (54679 . 54681) (54674 . 54679) (54673 . 54674) (t 26061 1849 58243 282000) 54672 nil (54664 . 54673) ("r" . -54664) ("a" . -54665) ("m" . -54666) ("p" . -54667) 54668 (54663 . 54668) (54662 . 54663) ("*" . -54662) 54663 (54660 . 54663) (54659 . 54660) (t 26058 34488 720572 763000) 53634 nil ("
" . 59425) nil ("#+RESULTS:
: t
" . 59426) 59437 nil (59437 . 59439) (59426 . 59439) ("
" . 59426) (59425 . 59427) 59353 (t 26058 34481 157238 969000) nil ("#+RESULTS:
: t
" . 59425) 59438 nil ("{}
" . 59425) nil (59425 . 59427) ("{" . -59425) (59425 . 59426) nil ("()
" . 59425) 59426 nil ("A" . -59426) 59427 (59426 . 59427) (59425 . 59427) ("(" . -59425) (59425 . 59426) (59424 . 59425) (t 26058 34465 647238 23000) 59415 nil (59437 . 59439) (59437 . 59439) (": t
" . 59437) 59188 (t 26058 34459 563904 318000) nil (59160 . 59415) ("  (use-package smartparens
    :ensure smartparens
    ;; :hook (prog-mode text-mode markdown-mode) ;; add `smartparens-mode` to these hooks
    ;; :init
    ;; (smartparens-global-mode)
    :config
    ;; load default config
    (require 'smartparens-config))
" . 59160) 59347 (t 26058 34456 920570 824000) nil (59443 . 59445) (59443 . 59445) (": t
" . 59443) 59239 nil (59443 . 59445) (59443 . 59445) (": t
" . 59443) 59185 (t 26058 34453 500570 615000) nil ("-" . -59186) ("m" . -59187) ("o" . -59188) ("d" . -59189) ("e" . -59190) 59191 nil (59448 . 59450) (59448 . 59450) (": t
" . 59448) 59306 (t 26058 34441 983903 243000) nil (59160 . 59426) ("  (use-package smartparens-mode
    :ensure smartparens
    ;; :hook (prog-mode text-mode markdown-mode) ;; add `smartparens-mode` to these hooks
    :init
    (smartparens-global-mode)
    :config
    ;; load default config
    (require 'smartparens-config))
" . 59160) 59346 nil (59442 . 59444) (59442 . 59444) (": t
" . 59442) 59314 (t 26058 34427 900569 51000) nil (59442 . 59444) (59442 . 59444) (": t
" . 59442) 59214 (t 26058 34415 67234 933000) nil (59204 . 59215) nil ("t" . 59204) nil (59432 . 59434) (59432 . 59434) 59373 (t 26058 34391 397233 486000) nil (59421 . 59432) ("
" . 59421) (59420 . 59422) 59408 (t 26058 34347 700564 147000) nil (59334 . 59335) (59331 . 59334) (59310 . 59331) ("s" . -59310) 59311 (59310 . 59311) nil (nil ws-butler-chg delete 59163 . 59164) (59162 . 59163) ("mar" . 59162) nil (59162 . 59165) ("(" . 59162) nil (59308 . 59310) 59160 (59305 . 59308) (59300 . 59305) (" " . -59300) 59301 (59300 . 59301) (59298 . 59300) 59160 (59295 . 59298) 59217 nil (59160 . 59370) ("  (use-package smartparens-mode
    :ensure t
    :hook (prog-mode text-mode markdown-mode) ;; add `smartparens-mode` to these hooks
    :config
    ;; load default config
    (require 'smartparens-config))
" . 59160) 59217 (t 26058 34315 703895 523000) nil (" " . 59205) nil (";; install the package" . 59206) nil (59204 . 59206) nil ("smartparens  " . 59204) nil (59160 . 59162) (59190 . 59191) (59192 . 59193) (59236 . 59238) (59323 . 59325) (59331 . 59332) (59333 . 59334) (59356 . 59358) 59160 nil (nil rear-nonsticky nil 59387 . 59388) (nil fontified nil 59356 . 59388) (nil fontified nil 59331 . 59356) (nil fontified nil 59321 . 59331) (nil fontified nil 59236 . 59321) (nil fontified nil 59190 . 59236) (nil fontified nil 59160 . 59190) (59160 . 59388) nil ("  " . -59160) 59162 (59159 . 59162) (t 26058 34231 407223 703000) 59099 nil (59035 . 59036) (t 26058 34224 257223 266000) nil (nil rear-nonsticky nil 59021 . 59022) (nil fontified nil 58986 . 59022) (58986 . 59022) 58985 (t 26058 34217 187222 833000) nil (59124 . 59132) (59123 . 59124) (59122 . 59123) 59051 nil (nil rear-nonsticky nil 59050 . 59051) ("
" . -59122) (59050 . 59123) nil (59049 . 59050) (t 26058 34206 363888 839000) 59027 nil (59045 . 59049) (59042 . 59045) (" " . -59042) ("e" . -59043) ("m" . -59044) ("a" . -59045) ("c" . -59046) ("s" . -59047) 59048 (59046 . 59048) (59025 . 59046) (59004 . 59025) (58997 . 59004) ("s" . -58997) ("n" . -58998) 58999 (58984 . 58999) ("S" . -58984) 58985 (58984 . 58985) (58983 . 58984) (t 26058 34180 103887 236000) 58982 nil (58972 . 58983) ("s" . -58972) 58973 (58969 . 58973) (58968 . 58969) (58967 . 58968) (t 26058 32181 363764 952000) 58966 nil ("          (common-lisp . t)
" . 42629) 42647 (t 26058 32163 213763 844000) nil (42640 . 42648) nil ("l" . 42640) nil ("-" . 42640) nil ("emacs" . 42640) nil (nil rear-nonsticky nil 42638 . 42639) ("
" . -42655) (42628 . 42656) 42614 (t 26057 26631 142295 517000) nil ("  ;; \"C-j\"         (lambda () (interactive) (enlarge-window 11))
  ;; \"C-k\"        (lambda () (interactive) (shrink-window 11))
" . 15957) 16082 nil (15954 . 15955) (")" . -15954) ("
" . -15955) (" " . -15956) (" " . -15957) (" " . -15958) (" " . -15959) 15960 nil (15896 . 15898) 13715 nil (15832 . 15834) 13715 nil (";; " . 15894) nil (";; " . 15832) nil (nil rear-nonsticky nil 15831 . 15832) ("
" . -15957) (15829 . 15958) 15793 (t 26057 26594 615626 609000) nil ("| lambda | nil | (interactive) | (ns/win-resize-right) |
" . 15986) 15792 (t 26057 26590 405626 350000) nil (15834 . 15835) (15832 . 15834) 13715 (15829 . 15832) nil ("     " . 15807) 13715 nil (15748 . 15750) 13715 nil ("      " . 15724) 13715 nil (15667 . 15669) 13715 nil (nil rear-nonsticky nil 15640 . 15641) ("
" . -15664) (15638 . 15665) (t 26057 26438 328950 357000) nil (15520 . 15525) nil ("left" . 15520) (t 26057 26410 82281 957000) nil (15960 . 16017) ("| lambda | nil | (interactive) | (shrink-window 11) |
" . 15960) 15531 (t 26057 26395 802281 82000) nil (")" . -15532) 15533 nil ("(" . 15513) nil ("or " . 15513) nil (15278 . 15279) nil (")" . -15298) 15299 nil ("(" . 15278) nil ("or " . 15278) nil ("(" . 15278) (t 26057 26288 625607 839000) nil (13715 . 15948) ("  ;; Use visual line motions even outside of visual-line-mode buffers
  (general-def 'motion
    \"j\" 'evil-next-visual-line
    \"k\" 'evil-previous-visual-line)

  ;; Choose a theme
  ;; TODO move this to consult
  (ns/leader-t
    \"t\" '(consult-theme :wk \"Choose a theme\"))

  (ns/leader-spc
    \"f\"  'find-file
    ;; \"b\"  'switch-to-buffer
    \"k\"  'kill-buffer
    \"eb\" 'eval-buffer)

  ;; Manage windows
  (ns/leader-ca 'override
    \"<backspace>\" 'delete-window
    \"\\\\\"          'split-window-right
    \"-\"           'split-window-below
    ;; Windmove keys for additional window navigation
    \"h\"          'windmove-left
    \"l\"           'windmove-right
    \"k\"          'windmove-up
    \"j\"           'windmove-down)
  ;; Window resizing
  ;; \"C-h\"        (lambda () (interactive) (shrink-window-horizontally 21))
  ;; \"C-l\"         (lambda () (interactive) (enlarge-window-horizontally 21))
  ;; \"C-j\"         (lambda () (interactive) (enlarge-window 11))
  ;; \"C-k\"        (lambda () (interactive) (shrink-window 11))

  ;; https://www.emacswiki.org/emacs/WindowResize
  (defun ns/define-x-pos ()
    \"Find the window's position on the x-axis.\"
    (let* ((win-edges (window-edges))
           (x-min (nth 0 win-edges))
           (x-max (nth 2 win-edges))
           (max-width (+ 2 (frame-width))))
      (cond
       ((equal max-width x-max)
        \"right\")
       ((and (> x-min 0) (< x-max max-width))
        \"mid\")
       (t \"left\"))))

  (defun ns/win-resize-left ()
    (interactive)
    (let ((x-pos (ns/define-x-pos)))
      (cond
       ((or (equal \"right\" x-pos))
        (enlarge-window-horizontally +15))
       (t (enlarge-window-horizontally -15))
       ))
    )

  (defun ns/win-resize-right ()
    (interactive)
    (let ((x-pos (ns/define-x-pos)))
      (cond
       ((or (equal \"left\" x-pos))
        (enlarge-window-horizontally -15))
       (t (enlarge-window-horizontally +15))
       ))
    )

  \"C-h\"       (lambda () (interactive)
                        (ns/win-resize-left))
  \"C-l\"        (lambda () (interactive)
                        (ns/win-resize-right))
  \"C-j\"         (lambda () (interactive) (enlarge-window 11))
  \"C-k\"        (lambda () (interactive) (shrink-window 11))
" . -13715) 15942 (t 26057 26282 242274 113000) nil (15964 . 16018) ("| lambda | nil | (interactive) | (shrink-window 11) |
" . 15964) 15533 nil (15964 . 16018) ("| lambda | nil | (interactive) | (shrink-window 11) |
" . 15964) 15533 (t 26057 26257 652272 605000) nil (15529 . 15533) nil ("right" . 15529) (t 26057 26193 382268 666000) nil (15965 . 16019) ("| lambda | nil | (interactive) | (shrink-window 11) |
" . 15965) 15575 (t 26057 26165 755600 309000) nil (15727 . 15731) nil ("right" . 15727) nil (15814 . 15819) nil ("left" . 15814) nil (15965 . 16019) ("| lambda | nil | (interactive) | (shrink-window 11) |
" . 15965) 15750 (t 26057 26149 215599 297000) nil (" " . 15750) nil ("                    " . -15800) (15776 . 15800) 15806 nil ("                  " . -15796) (15776 . 15796) 15806 nil ("  " . 13717) (" " . 13787) (" " . 13790) (" " . 13812) (" " . 13817) (" " . 13845) (" " . 13850) (" " . 13884) (" " . 13887) ("  " . 13906) ("  " . 13939) ("  " . 13960) ("  " . 14006) ("  " . 14029) (" " . 14047) (" " . 14052) (" " . 14079) (" " . 14084) (" " . 14103) (" " . 14108) (" " . 14129) (" " . 14132) (" " . 14151) (" " . 14154) (" " . 14179) (" " . 14184) (" " . 14214) (" " . 14219) (" " . 14254) (" " . 14259) ("  " . 14294) ("  " . 14350) ("  " . 14388) ("  " . 14420) ("  " . 14456) ("  " . 14488) ("  " . 14513) ("  " . 14589) ("  " . 14671) (" " . 14736) (" " . 14739) (" " . 14802) (" " . 14805) (" " . 14854) (" " . 14857) (" " . 14884) (" " . 14889) (" " . 14934) (" " . 14939) (" " . 14974) (" " . 14986) (" " . 15013) (" " . 15025) (" " . 15052) (" " . 15064) ("  " . 15098) ("  " . 15112) ("  " . 15154) ("  " . 15165) ("  " . 15221) (" " . 15230) (" " . 15238) (" " . 15254) (" " . 15257) (" " . 15287) (" " . 15292) (" " . 15307) (" " . 15312) ("  " . 15346) ("  " . 15360) ("  " . 15405) ("  " . 15442) ("  " . 15496) ("  " . 15501) ("  " . 15512) ("  " . 15544) ("  " . 15568) (" " . 15603) (" " . 15610) (" " . 15617) (" " . 15625) (" " . 15654) (" " . 15663) (" " . 15699) (" " . 15707) (" " . 15746) (" " . 15754) (" " . 15758) (" " . 15763) (" " . 15767) (" " . 15770) (" " . 15808) (" " . 15833) ("  " . 15857) ("      " . 15900) ("    " . 15924) ("  " . 15952) ("  " . 16014) 13715 nil ("                        " . -15928) (15900 . 15928) 15940 nil ("                    " . -15924) (15900 . 15924) 15940 nil (15940 . 15941) nil (13717 . 13719) (13785 . 13786) (13787 . 13788) (13808 . 13809) (13812 . 13813) (13839 . 13841) (13876 . 13878) (13898 . 13900) (13927 . 13928) (13929 . 13930) (13942 . 13943) (13946 . 13947) (13990 . 13991) (13992 . 13993) (14007 . 14008) (14011 . 14012) (14027 . 14029) (14057 . 14059) (14083 . 14085) (14103 . 14105) (14125 . 14127) (14149 . 14150) (14153 . 14154) (14182 . 14183) (14186 . 14187) (14220 . 14221) (14224 . 14225) (14258 . 14259) (14262 . 14263) (14312 . 14314) (14344 . 14346) (14382 . 14384) (14408 . 14409) (14412 . 14413) (14442 . 14443) (14444 . 14445) (14463 . 14465) (14539 . 14541) (14619 . 14621) (14682 . 14684) (14748 . 14750) (14796 . 14797) (14798 . 14799) (14824 . 14825) (14828 . 14829) (14872 . 14873) (14876 . 14877) (14910 . 14911) (14921 . 14922) (14947 . 14949) (14984 . 14986) (15034 . 15036) (15040 . 15042) (15080 . 15082) (15089 . 15090) (15096 . 15097) (15135 . 15136) (15143 . 15144) (15150 . 15152) (15172 . 15174) (15207 . 15209) (15221 . 15222) (15225 . 15226) (15258 . 15259) (15264 . 15265) (15270 . 15271) (15277 . 15278) (15305 . 15306) (15313 . 15314) (15348 . 15350) (15393 . 15395) (15407 . 15409) (15410 . 15412) (15446 . 15448) (15460 . 15461) (15464 . 15465) (15497 . 15498) (15503 . 15504) (15509 . 15510) (15516 . 15517) (15544 . 15545) (15552 . 15553) (15587 . 15589) (15632 . 15634) (15646 . 15648) (15649 . 15650) (15651 . 15652) (15688 . 15689) (15712 . 15713) (15735 . 15737) (15776 . 15796) (15799 . 15801) (15859 . 15861) 13715 (" " . 15775) (15776 . 15777) (15775 . 15776) nil (nil rear-nonsticky nil 15774 . 15775) (nil fontified nil 15751 . 15775) (15751 . 15775) 15750 nil ("                    " . -15712) (15688 . 15712) 15703 nil ("                " . -15708) (15688 . 15708) 15703 nil ("  " . 13717) ("  " . 13787) ("  " . 13816) ("  " . 13845) ("  " . 13886) ("  " . 13906) ("  " . 13941) ("  " . 13956) ("  " . 14008) ("  " . 14025) ("  " . 14051) ("  " . 14079) ("  " . 14107) ("  " . 14129) ("  " . 14153) ("  " . 14179) ("  " . 14218) ("  " . 14254) ("  " . 14298) ("  " . 14350) ("  " . 14388) ("  " . 14420) ("  " . 14456) ("  " . 14488) ("  " . 14513) ("  " . 14589) ("  " . 14671) ("  " . 14736) ("  " . 14804) ("  " . 14854) ("  " . 14888) ("  " . 14934) ("  " . 14985) ("  " . 15013) ("  " . 15063) ("  " . 15098) ("  " . 15119) ("  " . 15146) ("  " . 15172) ("  " . 15213) ("  " . 15237) ("  " . 15254) ("  " . 15291) ("  " . 15307) ("  " . 15352) ("  " . 15360) ("  " . 15405) ("  " . 15442) ("  " . 15496) ("  " . 15501) ("  " . 15512) ("  " . 15544) ("  " . 15568) ("  " . 15603) ("  " . 15624) ("  " . 15654) ("  " . 15706) ("  " . 15746) ("  " . 15762) ("  " . 15767) ("  " . 15824) ("  " . 15849) ("  " . 15890) ("  " . 15952) 13715 (13717 . 13719) (13785 . 13786) (13787 . 13788) (13808 . 13809) (13812 . 13813) (13839 . 13840) (13843 . 13844) (13876 . 13877) (13878 . 13879) (13896 . 13898) (13927 . 13929) (13946 . 13948) (13990 . 13992) (14011 . 14013) (14027 . 14028) (14031 . 14032) (14057 . 14058) (14061 . 14062) (14079 . 14080) (14083 . 14084) (14103 . 14104) (14105 . 14106) (14123 . 14125) (14149 . 14151) (14186 . 14188) (14220 . 14222) (14262 . 14264) (14312 . 14313) (14316 . 14317) (14344 . 14345) (14348 . 14349) (14378 . 14379) (14382 . 14383) (14408 . 14409) (14412 . 14413) (14442 . 14444) (14463 . 14465) (14541 . 14543) (14617 . 14619) (14684 . 14686) (14746 . 14747) (14748 . 14749) (14796 . 14797) (14798 . 14799) (14824 . 14825) (14828 . 14829) (14872 . 14873) (14876 . 14877) (14910 . 14912) (14947 . 14949) (14995 . 14997) (15028 . 15030) (15047 . 15049) (15072 . 15073) (15080 . 15081) (15089 . 15090) (15096 . 15097) (15135 . 15136) (15143 . 15144) (15150 . 15151) (15157 . 15158) (15172 . 15174) (15203 . 15205) (15225 . 15227) (15258 . 15260) (15277 . 15279) (15305 . 15306) (15313 . 15314) (15348 . 15349) (15355 . 15356) (15393 . 15394) (15400 . 15401) (15403 . 15404) (15407 . 15408) (15410 . 15412) (15442 . 15444) (15464 . 15466) (15497 . 15499) (15516 . 15518) (15544 . 15545) (15552 . 15553) (15587 . 15588) (15594 . 15595) (15632 . 15633) (15639 . 15640) (15642 . 15643) (15646 . 15647) (15649 . 15651) (15688 . 15706) (15711 . 15713) (15750 . 15752) (15810 . 15812) 13715 (" " . 15687) (15688 . 15689) nil (15709 . 15710) nil (" " . 15688) nil ("(" . 15688) nil ("enlarge" . 15689) 15696 nil ("-" . 15696) 15697 nil ("window " . 15697) 15704 nil ("11" . 15704) 15706 nil ("))" . 15706) 15708 nil (nil rear-nonsticky nil 15707 . 15708) (nil fontified nil 15663 . 15708) (15663 . 15708) 15662 (t 26057 26082 805595 226000) nil (15867 . 15921) 15274 (t 26057 26052 85593 339000) nil ("
" . 15544) nil ("        " . 15517) nil ("
" . 15517) (t 26057 25952 585587 242000) nil (15727 . 15731) nil ("right" . 15727) 15731 nil (nil rear-nonsticky nil 15731 . 15732) (nil fontified nil 15713 . 15732) (15713 . 15732) 15712 nil (15677 . 15694) (" " . -15677) 15678 (15675 . 15678) (t 26057 25919 632251 887000) nil ("lambda () (interactive) (shrink-window-horizontally 21)" . 15675) nil ("lambda () (interactive) " . 15749) 15773 nil ("(enlarge-window-horizontally 21)" . 15773) 15790 (t 26057 25880 912249 515000) nil ("    " . 13717) (" " . 13789) ("   " . 13792) ("  " . 13816) ("  " . 13822) ("   " . 13851) (" " . 13858) ("    " . 13892) ("    " . 13918) (" " . 13951) ("   " . 13954) ("  " . 13970) ("  " . 13976) ("   " . 14022) (" " . 14027) ("   " . 14043) (" " . 14050) ("    " . 14067) ("    " . 14105) (" " . 14127) ("   " . 14132) ("  " . 14155) ("  " . 14159) ("  " . 14179) ("  " . 14183) ("   " . 14209) (" " . 14216) ("    " . 14246) ("    " . 14292) (" " . 14330) ("   " . 14335) (" " . 14388) ("   " . 14393) ("  " . 14424) ("  " . 14430) ("   " . 14462) (" " . 14469) ("    " . 14496) ("    " . 14534) ("   " . 14540) ("  " . 14562) ("    " . 14566) (" " . 14644) ("     " . 14647) ("    " . 14728) ("  " . 14734) ("   " . 14799) ("   " . 14804) (" " . 14871) (" " . 15259) ("    " . 15268) ("     " . 15788) (" " . 15795) ("    " . 15867) ("  " . 15873) ("   " . 15948) ("   " . 15953) ("      " . 16016) 13715 nil (";; " . 15796) (" ;;" . 15877) (";; " . 15962) (" ;;" . 16032) 13715 nil ("        )

" . 16094) 16104 nil ("
" . 15300) nil ("
" . 15300) (t 26057 25850 48914 291000) nil (14532 . 14533) nil ("        ;; \"C-h\" (ns/win-resize-left 21)
        ;; \"C-l\" (ns/win-resize-right 21)
        ;; \"C-k\" (ns/win-resize-up 11)
        ;; \"C-j\" (ns/win-resize-down 11)
" . 16095) 16225 nil (nil rear-nonsticky nil 15796 . 15797) ("
" . -16094) (15788 . 16095) nil ("  " . -15788) 15790 (15787 . 15790) (t 26057 25798 92244 440000) 15786 nil (nil rear-nonsticky nil 14917 . 14918) (nil fontified nil 14874 . 14918) (14874 . 14918) 14873 nil (14871 . 14874) (" " . -14871) (" " . -14872) (" " . -14873) (" " . -14874) (" " . -14875) 14876 (13719 . 13721) (13787 . 13788) (13791 . 13792) (13812 . 13814) (13851 . 13853) (13884 . 13885) (13888 . 13889) (13906 . 13907) (13910 . 13911) (13939 . 13941) (13962 . 13964) (14006 . 14007) (14010 . 14011) (14025 . 14027) (14047 . 14049) (14085 . 14087) (14103 . 14104) (14109 . 14110) (14129 . 14131) (14155 . 14157) (14179 . 14180) (14185 . 14186) (14214 . 14215) (14220 . 14221) (14254 . 14256) (14294 . 14296) (14356 . 14358) (14384 . 14385) (14390 . 14391) (14420 . 14421) (14426 . 14427) (14452 . 14454) (14494 . 14496) (14513 . 14514) (14519 . 14520) (14593 . 14595) (14675 . 14677) (14750 . 14752) (14812 . 14815) (14814 . 14817) (14815 . 14817) (14843 . 14845) (14887 . 14888) (14889 . 14890) (14923 . 14929) ("	" . 14923) (14925 . 14929) (14951 . 14956) ("	" . 14951) (14953 . 14958) (14979 . 14984) ("	" . 14979) (14981 . 14986) (15014 . 15015) (15018 . 15019) (15024 . 15026) (15054 . 15056) (15074 . 15076) (15113 . 15121) ("	" . 15113) (15117 . 15119) (15124 . 15125) (15129 . 15130) (15146 . 15148) (15175 . 15177) (15191 . 15193) (15230 . 15232) (15236 . 15237) (15241 . 15242) (15269 . 15271) (15315 . 15317) (15353 . 15354) (15358 . 15359) (15361 . 15362) (15363 . 15364) (15366 . 15368) (15396 . 15398) (15414 . 15416) (15447 . 15448) (15451 . 15452) (15457 . 15458) (15462 . 15463) (15464 . 15466) (15504 . 15506) (15539 . 15540) (15544 . 15545) (15582 . 15584) (15590 . 15592) (15600 . 15602) (15633 . 15634) (15639 . 15640) (15673 . 15674) (15679 . 15680) (15710 . 15712) (15749 . 15751) 13715 (14811 . 14814) nil ("  
" . 14812) nil ("
" . 14812) nil ("
" . 14813) nil ("  (defun win-resize-top-or-bot ()
    \"Figure out if the current window is on top, bottom or in the
  middle\"
    (let* ((win-edges (window-edges))
           (this-window-y-min (nth 1 win-edges))
           (this-window-y-max (nth 3 win-edges))
           (fr-height (frame-height)))
      (cond
       ((eq 0 this-window-y-min) \"top\")
       ((eq (- fr-height 1) this-window-y-max) \"bot\")
       (t \"mid\"))))

  (defun win-resize-left-or-right ()
    \"Figure out if the current window is to the left, right or in the
  middle\"
    (let* ((win-edges (window-edges))
           (this-window-x-min (nth 0 win-edges))
           (this-window-x-max (nth 2 win-edges))
           (fr-width (frame-width)))
      (cond
       ((eq 0 this-window-x-min) \"left\")
       ((eq (+ fr-width 4) this-window-x-max) \"right\")
       (t \"mid\"))))

  (defun win-resize-enlarge-horiz ()
    (interactive)
    (cond
     ((equal \"top\" (win-resize-top-or-bot)) (enlarge-window -15))
     ((equal \"bot\" (win-resize-top-or-bot)) (enlarge-window 15))
     ((equal \"mid\" (win-resize-top-or-bot)) (enlarge-window -15))
     (t (message \"nil\"))))

  (defun win-resize-minimize-horiz ()
    (interactive)
    (cond
     ((equal \"top\" (win-resize-top-or-bot)) (enlarge-window 15))
     ((equal \"bot\" (win-resize-top-or-bot)) (enlarge-window -15))
     ((equal \"mid\" (win-resize-top-or-bot)) (enlarge-window 15))
     (t (message \"nil\"))))

  (defun win-resize-enlarge-vert ()
    (interactive)
    (cond
     ((equal \"left\" (win-resize-left-or-right)) (enlarge-window-horizontally -15))
     ((equal \"right\" (win-resize-left-or-right)) (enlarge-window-horizontally 15))
     ((equal \"mid\" (win-resize-left-or-right)) (enlarge-window-horizontally -15))))

  (defun win-resize-minimize-vert ()
    (interactive)
    (cond
     ((equal \"left\" (win-resize-left-or-right)) (enlarge-window-horizontally 15))
     ((equal \"right\" (win-resize-left-or-right)) (enlarge-window-horizontally -15))
     ((equal \"mid\" (win-resize-left-or-right)) (enlarge-window-horizontally 15))))

  ;; (global-set-key [C-M-down] 'win-resize-minimize-vert)
  ;; (global-set-key [C-M-up] 'win-resize-enlarge-vert)
  ;; (global-set-key [C-M-up] 'win-resize-enlarge-horiz)
  ;; (global-set-key [C-M-down] 'win-resize-minimize-horiz)

  (global-set-key [C-M-left] 'win-resize-enlarge-vert)
  (global-set-key [C-M-right] 'win-resize-minimize-vert)
" . 14813) nil (nil rear-nonsticky nil 17202 . 17203) ("
" . -17981) (17202 . 17982) 17201 nil (17200 . 17202) ("  " . 17199) (17201 . 17202) (17198 . 17201) (t 26057 18024 835101 750000) 17144 nil (17184 . 17192) nil ("shrink" . 17184) (t 26057 17984 695099 295000) nil (17184 . 17190) nil ("enlarge" . 17184) (t 26057 17909 825094 718000) nil (13715 . 17362) ("    ;; Use visual line motions even outside of visual-line-mode buffers
    (general-def 'motion
      \"j\" 'evil-next-visual-line
      \"k\" 'evil-previous-visual-line)

    ;; Choose a theme
    ;; TODO move this to consult
    (ns/leader-t
      \"t\" '(consult-theme :wk \"Choose a theme\"))

    (ns/leader-spc
      \"f\"  'find-file
      ;; \"b\"  'switch-to-buffer
      \"k\"  'kill-buffer
      \"eb\" 'eval-buffer)

    ;; Manage windows
    (ns/leader-ca 'override
      \"<backspace>\" 'delete-window
      \"\\\\\"          'split-window-right
      \"-\"           'split-window-below
      ;; Windmove keys for additional window navigation
      \"h\"          'windmove-left
      \"l\"           'windmove-right
      \"k\"          'windmove-up
      \"j\"           'windmove-down
       ;; Window resizing
      ;; \"C-h\"        (lambda () (interactive) (shrink-window-horizontally 21))
      ;; \"C-l\"         (lambda () (interactive) (enlarge-window-horizontally 21))
      ;; \"C-j\"         (lambda () (interactive) (enlarge-window 11))
      ;; \"C-k\"        (lambda () (interactive) (shrink-window 11))


  (defun win-resize-top-or-bot ()
    \"Figure out if the current window is on top, bottom or in the
  middle\"
    (let* ((win-edges (window-edges))
           (this-window-y-min (nth 1 win-edges))
           (this-window-y-max (nth 3 win-edges))
           (fr-height (frame-height)))
      (cond
       ((eq 0 this-window-y-min) \"top\")
       ((eq (- fr-height 1) this-window-y-max) \"bot\")
       (t \"mid\"))))

  (defun win-resize-left-or-right ()
    \"Figure out if the current window is to the left, right or in the
  middle\"
    (let* ((win-edges (window-edges))
           (this-window-x-min (nth 0 win-edges))
           (this-window-x-max (nth 2 win-edges))
           (fr-width (frame-width)))
      (cond
       ((eq 0 this-window-x-min) \"left\")
       ((eq (+ fr-width 4) this-window-x-max) \"right\")
       (t \"mid\"))))

  (defun win-resize-enlarge-horiz ()
    (interactive)
    (cond
     ((equal \"top\" (win-resize-top-or-bot)) (enlarge-window -15))
     ((equal \"bot\" (win-resize-top-or-bot)) (enlarge-window 15))
     ((equal \"mid\" (win-resize-top-or-bot)) (enlarge-window -15))
     (t (message \"nil\"))))

  (defun win-resize-minimize-horiz ()
    (interactive)
    (cond
     ((equal \"top\" (win-resize-top-or-bot)) (enlarge-window 15))
     ((equal \"bot\" (win-resize-top-or-bot)) (enlarge-window -15))
     ((equal \"mid\" (win-resize-top-or-bot)) (enlarge-window 15))
     (t (message \"nil\"))))

  (defun win-resize-enlarge-vert ()
    (interactive)
    (cond
     ((equal \"left\" (win-resize-left-or-right)) (enlarge-window-horizontally -15))
     ((equal \"right\" (win-resize-left-or-right)) (enlarge-window-horizontally 15))
     ((equal \"mid\" (win-resize-left-or-right)) (enlarge-window-horizontally -15))))

  (defun win-resize-minimize-vert ()
    (interactive)
    (cond
     ((equal \"left\" (win-resize-left-or-right)) (enlarge-window-horizontally 15))
     ((equal \"right\" (win-resize-left-or-right)) (enlarge-window-horizontally -15))
     ((equal \"mid\" (win-resize-left-or-right)) (enlarge-window-horizontally 15))))

  (global-set-key [C-M-down] 'win-resize-minimize-vert)
  (global-set-key [C-M-up] 'win-resize-enlarge-vert)
  (global-set-key [C-M-up] 'win-resize-enlarge-horiz)
  (global-set-key [C-M-down] 'win-resize-minimize-horiz)

  (global-set-key [C-M-left] 'win-resize-enlarge-vert)
  (global-set-key [C-M-right] 'win-resize-enlarge-vert)
      ;; \"C-h\" (ns/win-resize-left 21)
      ;; \"C-l\" (ns/win-resize-right 21)
      ;; \"C-k\" (ns/win-resize-up 11)
      ;; \"C-j\" (ns/win-resize-down 11)
      )

" . 13715) 16854 (t 26057 17866 258425 391000) nil (17177 . 17179) (17172 . 17177) nil ("minimize" . 17172) nil ("  (global-set-key [C-M-right] 'win-resize-enlarge-horiz)
" . 17187) 17189 nil ("  (global-set-key [C-M-left] 'win-resize-enlarge-vert)
" . 17130) 17132 nil ("  (global-set-key [C-M-left] 'win-resize-minimize-horiz)
" . 17075) 17078 nil (nil rear-nonsticky nil 17076 . 17077) ("
" . -17131) (17074 . 17132) nil ("  (global-set-key [C-M-left] 'win-resize-minimize-horiz)
" . 16963) 16965 nil (nil rear-nonsticky nil 17300 . 17301) ("
" . -17355) (17298 . 17356) 17242 nil ("  (global-set-key [C-M-right] 'win-resize-enlarge-horiz)
" . 17020) nil ("  " . -17188) 17190 (13717 . 13719) (13785 . 13787) (13812 . 13814) (13839 . 13841) (13878 . 13880) (13896 . 13898) (13929 . 13931) (13942 . 13943) (13946 . 13947) (13990 . 13991) (13992 . 13993) (14007 . 14008) (14011 . 14012) (14027 . 14028) (14031 . 14032) (14057 . 14058) (14061 . 14062) (14079 . 14080) (14083 . 14084) (14103 . 14104) (14105 . 14106) (14123 . 14125) (14153 . 14155) (14182 . 14184) (14224 . 14226) (14258 . 14260) (14316 . 14318) (14344 . 14346) (14382 . 14384) (14408 . 14409) (14412 . 14413) (14441 . 14442) (14446 . 14447) (14465 . 14466) (14469 . 14470) (14543 . 14545) (14627 . 14629) (14690 . 14692) (14757 . 14759) (14789 . 14790) (14791 . 14792) (14853 . 14855) (14861 . 14862) (14863 . 14864) (14897 . 14906) ("	" . 14897) (14899 . 14900) (14937 . 14942) ("	" . 14937) (14939 . 14944) (14977 . 14978) ("	" . 14977) (14979 . 14988) (15007 . 15008) (15011 . 15012) (15017 . 15018) (15022 . 15023) (15055 . 15057) (15112 . 15114) (15126 . 15128) (15163 . 15165) (15229 . 15231) (15237 . 15238) (15239 . 15240) (15273 . 15276) ("	" . 15273) (15275 . 15282) (15313 . 15320) ("	" . 15313) (15315 . 15318) (15353 . 15357) ("	" . 15353) (15355 . 15361) (15381 . 15382) (15385 . 15386) (15391 . 15392) (15396 . 15397) (15430 . 15431) (15435 . 15436) (15483 . 15484) (15488 . 15489) (15502 . 15504) (15537 . 15538) (15539 . 15540) (15553 . 15554) (15555 . 15556) (15561 . 15563) (15628 . 15630) (15688 . 15690) (15755 . 15757) (15778 . 15780) (15814 . 15815) (15816 . 15817) (15830 . 15831) (15832 . 15833) (15838 . 15840) (15904 . 15906) (15965 . 15967) (16031 . 16033) (16054 . 16056) (16090 . 16092) (16104 . 16106) (16115 . 16117) (16193 . 16194) (16196 . 16197) (16274 . 16275) (16277 . 16278) (16357 . 16359) (16392 . 16394) (16410 . 16412) (16416 . 16418) (16499 . 16501) (16578 . 16579) (16581 . 16582) (16660 . 16662) (16714 . 16716) (16765 . 16767) (16820 . 16822) (16875 . 16877) (16927 . 16929) (16985 . 16987) (17038 . 17040) (17091 . 17093) (17150 . 17152) (17183 . 17184) (17187 . 17188) (17221 . 17222) (17225 . 17226) (17256 . 17257) (17260 . 17261) (17293 . 17295) 13715 (16981 . 16984) 16927 nil (nil rear-nonsticky nil 17034 . 17035) ("
" . -17087) (17034 . 17088) 16983 (t 26057 17335 565059 608000)) (emacs-undo-equiv-table))