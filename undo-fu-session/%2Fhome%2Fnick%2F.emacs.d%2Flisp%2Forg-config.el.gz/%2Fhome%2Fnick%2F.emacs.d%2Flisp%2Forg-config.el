((buffer-size . 12669) (buffer-checksum . "d86daa990709e77e55f84c600a79f150e5ede87f"))
((emacs-buffer-undo-list nil (apply -3 768 850 undo--wrap-and-run-primitive-undo 768 850 ((770 . 773))) nil (apply 3 847 934 undo--wrap-and-run-primitive-undo 847 934 ((";; " . -849)))) (emacs-pending-undo-list ("    " . 19666) (nil ws-butler-chg delete 19672 . 19673) (19670 . 19672) nil ("  " . -19670) (19666 . 19670) 19765 (t 26101 62595 98280 185000) nil (" " . 34559) nil ("1" . 34560) (t 26101 62582 538281 56000) nil (35507 . 35512) (35496 . 36048) ("
" . 35496) (35491 . 35496) (35490 . 35492) 34541 (t 26101 62190 214974 835000) nil (34253 . 34255) (34253 . 34272) (": efs/org-font-setup
" . 34253) 33399 nil (34253 . 34255) (34242 . 34272) ("
" . 34242) (34241 . 34243) 33399 (t 26101 62185 851641 802000) nil (32510 . 34231) ("  (defun efs/org-font-setup ()
    ;; Replace list hyphen with dot
    (font-lock-add-keywords 'org-mode
                            '((\"^ *\\\\([-]\\\\) \"
                               (0 (prog1 () (compose-region (match-beginning 1) (match-end 1) \"•\"))))))

    ;; Set faces for heading levels
    (dolist (face '((org-level-1 . 1.2)
                    (org-level-2 . 1.1)
                    (org-level-3 . 1.05)
                    (org-level-4 . 1.0)
                    (org-level-5 . 1.1)
                    (org-level-6 . 1.1)
                    (org-level-7 . 1.1)
                    (org-level-8 . 1.1)))
      (set-face-attribute (car face) nil :font \"Cantarell\" :weight 'regular :height (cdr face)))

    ;; Ensure that anything that should be fixed-pitch in Org files appears that way
    (set-face-attribute 'org-block nil    :foreground nil :inherit 'fixed-pitch)
    (set-face-attribute 'org-block nil    :foreground 'unspecified :inherit 'fixed-pitch)
    (set-face-attribute 'org-table nil    :inherit 'fixed-pitch)
    (set-face-attribute 'org-formula nil  :inherit 'fixed-pitch)
    (set-face-attribute 'org-code nil     :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-table nil    :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-verbatim nil :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-special-keyword nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-meta-line nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-checkbox nil  :inherit 'fixed-pitch)
    (set-face-attribute 'line-number nil :inherit 'fixed-pitch)
    (set-face-attribute 'line-number-current-line nil :inherit 'fixed-pitch))
" . 32510) 33398 (t 26101 62169 828309 574000) nil (32510 . 34228) ("  (defun efs/org-font-setup ()
    ;; Replace list hyphen with dot
    (font-lock-add-keywords 'org-mode
                            '((\"^ *\\\\([-]\\\\) \"
                               (0 (prog1 () (compose-region (match-beginning 1) (match-end 1) \"•\"))))))

    ;; Set faces for heading levels
    (dolist (face '((org-level-1 . 1.2)
                    (org-level-2 . 1.1)
                    (org-level-3 . 1.05)
                    (org-level-4 . 1.0)
                    (org-level-5 . 1.1)
                    (org-level-6 . 1.1)
                    (org-level-7 . 1.1)
                    (org-level-8 . 1.1)))
      (set-face-attribute (car face) nil :font \"Cantarell\" :weight 'regular :height (cdr face)))

    ;; Ensure that anything that should be fixed-pitch in Org files appears that way
    ;;(set-face-attribute 'org-block nil    :foreground nil :inherit 'fixed-pitch)
    (set-face-attribute 'org-block nil    :foreground 'unspecified :inherit 'fixed-pitch)
    (set-face-attribute 'org-table nil    :inherit 'fixed-pitch)
    (set-face-attribute 'org-formula nil  :inherit 'fixed-pitch)
    (set-face-attribute 'org-code nil     :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-table nil    :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-verbatim nil :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-special-keyword nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-meta-line nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-checkbox nil  :inherit 'fixed-pitch)
    (set-face-attribute 'line-number nil :inherit 'fixed-pitch)
    (set-face-attribute 'line-number-current-line nil :inherit 'fixed-pitch))
" . 32510) 33315 (t 26101 62148 104977 740000) nil (44381 . 44382) (44370 . 44922) ("
" . 44370) (44369 . 44370) (44368 . 44370) 44205 nil (43430 . 43486) ("| lambda | nil | (interactive) | (org-capture nil jj) |
" . 43430) 41953 (t 26101 61396 901696 265000) nil (3865 . 3867) (3865 . 3972) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3865) 2769 (t 26101 61394 485029 767000) nil (2686 . 3843) ("  ;; Default for fill column should be 80 (not 70 like emacs would have it!!!)
  (setq-default fill-column 80)

  (setq frame-resize-pixelwise t
        frame-inhibit-implied-resize t
        frame-title-format '(\"%b\")
        ring-bell-function 'ignore
        use-dialog-box t ; only for mouse events, which I seldom use
        use-file-dialog nil
        use-short-answers t
        inhibit-splash-screen t
        inhibit-startup-screen t
        inhibit-startup-message t
        initial-scratch-message nil
        inhibit-x-resources t
        inhibit-startup-echo-area-message user-login-name ; read the docstring
        inhibit-startup-buffer-menu t)

  (set-fringe-mode 10) ; Give some breathing room

  (menu-bar-mode -1)   ; Disable the menu bar

  ;; Disable graphical elements
  (menu-bar-mode -1)
  (scroll-bar-mode -1)
  (tool-bar-mode -1)
  (tooltip-mode -1)

  ;; Set frame transparency
  (set-frame-parameter (selected-frame) 'alpha '(100. 100))
  (add-to-list 'default-frame-alist `(alpha . (100 . 100)))
  (set-frame-parameter (selected-frame) 'fullscreen 'maximized)
  (add-to-list 'default-frame-alist '(fullscreen . maximized))
" . 2686) 2768 (t 26101 61352 385032 668000) nil (3862 . 3864) (3862 . 3969) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3862) 2797 (t 26101 61350 461699 469000) nil (3862 . 3864) (3862 . 3969) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3862) 2797 (t 26101 61347 258366 357000) nil ("  " . -2797) 2799 (2796 . 2799) 2765 nil ("
" . 2686) nil (nil rear-nonsticky nil 2688 . 2689) ("
" . -2797) (2686 . 2798) nil ("  " . -2686) 2688 (2686 . 2688) (2686 . 2687) nil ("
  " . 2718) ("      " . 2721) (nil ws-butler-chg delete 2727 . 2728) (2719 . 2727) nil ("        " . -2719) 2727 (2721 . 2727) 2686 (2718 . 2721) 2686 nil ("  ;; Default for fill column should be 80 (not 70 like emacs would have it!!!)
  (setq-default fill-column 80)
" . 3452) 3559 (t 26101 60945 241727 429000) nil (3861 . 3863) (3861 . 3968) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3861) 2928 (t 26098 26547 597716 115000) nil (20070 . 20081) ("
" . 20070) (20069 . 20071) 19410 (t 26098 26533 514383 753000) nil (19129 . 19189) ("| lambda | nil | (interactive) | (ns/toggle-transparency) |
" . 19129) 18893 nil (19129 . 19189) ("| lambda | nil | (interactive) | (ns/toggle-transparency) |
" . 19129) 18893 nil (18408 . 18491) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18408) 17471 nil (18408 . 18491) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18408) 17470 (t 26098 26500 334386 43000) nil (3861 . 3863) (3861 . 3968) (": ((alpha 100 . 100) (fullscreen . maximized) (alpha 90 . 90) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3861) 3667 (t 26098 26484 894387 107000) nil ("
" . 9208) nil ("*** Test
" . 9209) nil ("daw
" . 9218) 9220 nil (9218 . 9221) (9217 . 9218) (9209 . 9217) (9208 . 9209) (9207 . 9208) (t 26098 25731 824439 62000) 9171 nil (18424 . 18507) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18424) 17655 (t 26098 25722 957773 7000) nil (17644 . 17655) ("afternoon" . 17644) nil ("
" . 17594) nil ("  (use-package afternoon-theme
    :ensure t)
" . 17594) 17639 (t 26098 24500 1190 710000) nil (18469 . 18552) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18469) 17581 (t 26098 24491 584524 623000) nil ("  " . -17640) 17642 ("  " . 17418) ("  " . 17436) ("  " . 17470) ("  " . 17484) ("  " . 17503) ("  " . 17528) ("  " . 17548) (" " . 17565) (" " . 17568) (" " . 17594) (" " . 17599) (" " . 17612) (" " . 17615) ("  " . 17645) ("  " . 17667) ("  " . 17689) ("  " . 17732) (" " . 17765) (" " . 17768) (" " . 17791) (" " . 17794) (" " . 17817) (" " . 17820) (" " . 17852) (" " . 17855) (" " . 17905) (" " . 17910) (" " . 17958) (" " . 17963) (" " . 17978) (" " . 17983) ("  " . 18035) ("  " . 18106) ("  " . 18138) ("  " . 18193) (" " . 18218) (" " . 18227) (" " . 18259) (" " . 18262) (" " . 18349) (" " . 18352) ("  " . 18414) 17416 (17661 . 17664) (t 26098 24486 544524 970000) 17660 nil (17638 . 17644) (t 26098 24471 147859 366000) nil (17635 . 17636) ("n" . 17635) (t 26098 24464 617859 817000) nil (17645 . 17654) (17418 . 17420) (17434 . 17436) (17466 . 17468) (17478 . 17480) (17495 . 17497) (17518 . 17520) (17536 . 17538) (17551 . 17553) (17582 . 17584) (17594 . 17596) (17619 . 17625) (17621 . 17623) (17645 . 17647) (17682 . 17683) (17684 . 17685) (17715 . 17716) (17717 . 17718) (17739 . 17740) (17741 . 17742) (17763 . 17764) (17765 . 17766) (17796 . 17797) (17798 . 17799) (17847 . 17848) (17851 . 17852) (17898 . 17899) (17902 . 17903) (17916 . 17917) (17920 . 17921) (17971 . 17972) (17977 . 17978) (18034 . 18035) (18040 . 18041) (18070 . 18071) (18076 . 18077) (18113 . 18114) (18123 . 18124) (18146 . 18147) (18154 . 18155) (18185 . 18186) (18187 . 18188) (18273 . 18274) (18275 . 18276) (18336 . 18338) 17416 (17618 . 17619) (17603 . 17618) ("k" . -17603) ("c" . -17604) 17605 (17597 . 17605) (17596 . 17598) ("(" . -17596) (17596 . 17597) ("  " . 17418) ("  " . 17436) ("  " . 17470) (" " . 17484) (" " . 17487) (" " . 17501) (" " . 17504) (" " . 17528) (" " . 17533) ("  " . 17546) ("  " . 17567) ("  " . 17594) ("  " . 17617) (" " . 17639) (" " . 17642) ("  " . 17680) ("  " . 17717) (" " . 17741) (" " . 17744) (" " . 17767) (" " . 17770) (" " . 17802) (" " . 17805) ("  " . 17855) ("  " . 17912) ("  " . 17928) ("  " . 17991) (" " . 18050) (" " . 18057) (" " . 18088) (" " . 18095) (" " . 18133) (" " . 18144) ("  " . 18168) ("  " . 18211) (" " . 18299) (" " . 18302) ("  " . 18364) 17416 (17611 . 17614) (t 26098 24411 311196 827000) 17611 nil (18476 . 18559) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18476) 17674 (t 26098 24407 757863 739000) nil (17666 . 17675) nil ("badger" . 17666) nil ("-" . 17666) nil ("doom" . 17666) (t 26098 24249 714541 308000)) (emacs-undo-equiv-table (-1 . -3)))