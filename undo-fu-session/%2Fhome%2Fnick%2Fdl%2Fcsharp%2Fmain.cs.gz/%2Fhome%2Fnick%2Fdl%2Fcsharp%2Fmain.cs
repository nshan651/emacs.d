((buffer-size . 130) (buffer-checksum . "b6f94169fadf5c3609b64078cb56c5ff6a958eae"))
((emacs-buffer-undo-list nil (27 . 40) (25 . 27) (4 . 25) ("D" . -4) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 39) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker) . -1) ("o" . -5) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 39) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker) . -1) ("t" . -6) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 39) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker . 4) . -1) ((marker) . -1) 7 (3 . 7) (1 . 3) ("#" . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 39) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) 2 (1 . 2) (1 . 2) nil ("
" . 83) ((marker* . 40) . 1) nil ("	System.Con
" . 83) ((marker* . 40) . 1) ((marker . 39) . -10) ((marker . 39) . -10) ((marker . 130) . -11) 93 nil (84 . 94) (82 . 84) (t 26133 37660 455114 218000) 46 nil ("	" . -83) 84 (82 . 84) (t 26133 37587 91776 395000) 46 nil ("	System
" . 83) 89 nil (84 . 90) (82 . 84) (t 26133 37352 708428 737000) 46 nil (90 . 91) nil (81 . 82) (")" . 81) (80 . 81) ("\"" . 80) (73 . 80) (72 . 74) ("\"" . -72) (72 . 73) (71 . 73) ("(" . -71) (71 . 72) (67 . 71) (47 . 67) (45 . 47) 43 nil (45 . 50) (44 . 46) ("{" . -44) (40 . 44) ("	" . 40) (41 . 42) (39 . 41) (" " . -39) 40 (39 . 40) (")" . 39) (38 . 39) (37 . 39) ("(" . -37) (37 . 38) (33 . 37) (21 . 33) (17 . 21) (17 . 18) nil (16 . 17) (" " . -16) 17 (16 . 17) ("\\" . -16) ("
" . -17) 18 (17 . 18) (16 . 17) (15 . 17) ("{" . -15) ("    " . 15) (19 . 20) (14 . 19) (1 . 14) (t . -1)) (emacs-pending-undo-list (51627 . 51738) ("
" . 51627) (51626 . 51628) 50859 (t 26124 31693 496364 691000) nil (nil rear-nonsticky nil 50917 . 50918) (nil fontified nil 50902 . 50918) (50902 . 50918) 50901 (t 26124 31511 613020 210000) nil ("     #+RESULTS:
     | #[0 \\301\\211\\207 [imenu-create-index-function org-imenu-get-tree] 2] | org-tempo-setup | (lambda nil evil-org-mode) | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-fold-show-all append local] 5] | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-babel-show-result-all append local] 5] | org-babel-result-hide-spec | org-babel-hide-all-hashes | org-appear-mode | efs/org-mode-visual-fill | org-bullets-mode | ns/org-mode-setup | rainbow-delimiters-mode | (lambda nil (display-line-numbers-mode 0)) |
" . 35366) ((marker . 131) . -515) ((marker . 131) . -561) ((marker . 131) . -515) ((marker . 131) . -5) ((marker . 131) . -5) 35371 (t 26124 31227 946336 157000) nil ("
" . 1335) ((marker* . 131) . 1) nil ("#+RESULTS:
: ns-emacs-with-desktop-session
" . 1335) ((marker . 131) . -11) ((marker . 131) . -42) ((marker . 131) . -11) ((marker . 131) . -11) 1346 (t 26124 31057 826325 731000) nil (53664 . 53667) (t 26124 30978 256320 853000) nil (53648 . 53649) (53645 . 53648) ("toggle" . 53645) ((marker . 131) . -5) (t 26124 30956 246319 505000) nil (53646 . 53652) ("o" . -53646) ((marker . 131) . -1) ("g" . -53647) ((marker . 131) . -1) ("g" . -53648) ((marker . 131) . -1) ("l" . -53649) ((marker . 131) . -1) ("e" . -53650) ((marker . 131) . -1) 53651 (53645 . 53651) ("g" . -53645) ((marker . 131) . -1) 53646 (53642 . 53646) nil ("graph " . 53642) ((marker . 131) . -5) (t 26124 30939 146318 456000) nil (53682 . 53693) ("
" . 53682) (53681 . 53683) 53669 nil (53669 . 53670) nil (nil rear-nonsticky nil 53606 . 53607) ("
" . -53621) (53604 . 53622) nil (nil rear-nonsticky nil 53608 . 53609) ("
" . -53652) (53604 . 53653) nil ("  " . -53604) ((marker . 131) . -2) 53606 (53603 . 53606) 53574 nil (50264 . 51227) ("  (use-package org-roam
    :ensure t
    :custom
    (org-roam-directory (file-truename \"~/org\"))
    (org-roam-dailies-directory \"~/org/journal\")
    (org-roam-completion-everywhere t)
    :config
    ;; If you're using a vertical completion framework, you might want a more informative completion interface
    ;; (setq org-roam-node-display-template (concat \"${title:*} \" (propertize \"${tags:10}\" 'face 'org-tag)))
    (org-roam-db-autosync-mode)
    ;; If using org-roam-protocol
    (require 'org-roam-protocol))

  ;; Keybindings
  (ns/leader-spc
    \"n\"  '(:ignore t :wk \"org node selection\")
    \"nl\" '(org-roam-buffer-toggle :wk \"org roam buffer toggle\")
    \"nf\" '(org-roam-node-find :wk \"org roam buffer find\")
    \"ng\" '(org-roam-graph :wk \"org roam graph\")
    \"ni\" '(org-roam-node-insert :wk \"org roam insert\")
    \"nc\" '(org-roam-capture :wk \"org roam capture\")
    \"nj\" '(org-roam-dailies-capture-today :wk \"org roam dailies capture today\"))

" . 50264) ((marker . 131) . -723) ((marker . 131) . -770) ((marker . 131) . -737) 51001 (t 26102 5966 697664 466000) nil (35426 . 35431) (35426 . 35967) ("     | #[0 \\301\\211\\207 [imenu-create-index-function org-imenu-get-tree] 2] | org-tempo-setup | (lambda nil evil-org-mode) | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-fold-show-all append local] 5] | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-babel-show-result-all append local] 5] | org-babel-result-hide-spec | org-babel-hide-all-hashes | org-appear-mode | efs/org-mode-visual-fill | org-bullets-mode | ns/org-mode-setup | rainbow-delimiters-mode | (lambda nil (display-line-numbers-mode 0)) |
" . 35426) 34451 (t 26102 5962 294331 436000) nil (34438 . 34451) (34437 . 34439) ("(" . -34437) (34437 . 34438) (")" . -34437) ("f" . -34438) ("l" . -34439) ("y" . -34440) 34441 (34437 . 34441) (34435 . 34437) 34381 (34432 . 34435) (t 26102 2913 824541 956000) 34415 nil ("
" . 3851) nil ("#+RESULTS:
: ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3851) (t 26101 62869 168261 237000) nil (3862 . 3864) (3862 . 3969) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3862) 2689 (t 26101 62867 318261 366000) nil ("  " . 3452) 2686 nil ("
" . 2686) nil (2686 . 3843) ("
  (setq frame-resize-pixelwise t
        frame-inhibit-implied-resize t
        frame-title-format '(\"%b\")
        ring-bell-function 'ignore
        use-dialog-box t ; only for mouse events, which I seldom use
        use-file-dialog nil
        use-short-answers t
        inhibit-splash-screen t
        inhibit-startup-screen t
        inhibit-startup-message t
        initial-scratch-message nil
        inhibit-x-resources t
        inhibit-startup-echo-area-message user-login-name ; read the docstring
        inhibit-startup-buffer-menu t)

  (set-fringe-mode 10) ; Give some breathing room

  (menu-bar-mode -1)   ; Disable the menu bar

  ;; Disable graphical elements
  (menu-bar-mode -1)
  (scroll-bar-mode -1)
  (tool-bar-mode -1)
  (tooltip-mode -1)
  
  ;; Default for fill column should be 80 (not 70 like emacs would have it!!!)
  ;; (setq-default fill-column 80)

  ;; Set frame transparency
  (set-frame-parameter (selected-frame) 'alpha '(100. 100))
  (add-to-list 'default-frame-alist `(alpha . (100 . 100)))
  (set-frame-parameter (selected-frame) 'fullscreen 'maximized)
  (add-to-list 'default-frame-alist '(fullscreen . maximized))
" . 2686) 3535 nil ("
" . 3453) nil (nil rear-nonsticky nil 3458 . 3459) ("
" . -3570) (3456 . 3571) 3455 nil (3454 . 3456) ("  " . 3453) (3455 . 3456) (3452 . 3455) 3433 nil ("  ;; Default for fill column should be 80 (not 70 like emacs would have it!!!)
  ;; (setq-default fill-column 80)
" . 2686) 2771 (t 26101 62840 44929 919000) nil (35530 . 35535) (35530 . 36071) ("     | #[0 \\301\\211\\207 [imenu-create-index-function org-imenu-get-tree] 2] | org-tempo-setup | (lambda nil evil-org-mode) | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-fold-show-all append local] 5] | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-babel-show-result-all append local] 5] | org-babel-result-hide-spec | org-babel-hide-all-hashes | org-appear-mode | efs/org-mode-visual-fill | org-bullets-mode | ns/org-mode-setup | rainbow-delimiters-mode | (lambda nil (display-line-numbers-mode 0)) |
" . 35530) 34563 (t 26101 62838 64930 56000) nil (34505 . 35503) ("  (defun ns/org-mode-setup ()
    (org-indent-mode)
    (variable-pitch-mode)
    (visual-line-mode 1))

  (use-package org
    :commands (org-capture org-agenda)
    :hook
    (org-mode . ns/org-mode-setup)
    :config
    (setq org-ellipsis \" ▾\"
          org-hide-emphasis-markers t
          org-src-fontify-natively t
          org-fontify-quote-and-verse-blocks t
          ;; org-src-tab-acts-natively t
          ;;org-edit-src-content-indentation 2
          org-hide-block-startup nil
          ;;org-src-preserve-indentation nil
          org-startup-folded 'content
          org-cycle-separator-lines 2
          org-capture-bookmark nil)

    (setq org-modules
          '(org-habit))

    ;; Resize latex figures
    (setq org-format-latex-options
          (plist-put org-format-latex-options :scale 1.5))

    (setq org-habit-graph-column 60)

    ;; Save Org buffers after refiling!
    (advice-add 'org-refile :after 'org-save-all-org-buffers)

    (efs/org-font-setup))
     " . 34505) 34562 (t 26101 62792 98266 567000) nil (35527 . 35532) (35527 . 36068) ("     | #[0 \\301\\211\\207 [imenu-create-index-function org-imenu-get-tree] 2] | org-tempo-setup | (lambda nil evil-org-mode) | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-fold-show-all append local] 5] | #[0 \\300\\301\\302\\303\\304$\\207 [add-hook change-major-mode-hook org-babel-show-result-all append local] 5] | org-babel-result-hide-spec | org-babel-hide-all-hashes | org-appear-mode | efs/org-mode-visual-fill | org-bullets-mode | ns/org-mode-setup | rainbow-delimiters-mode | (lambda nil (display-line-numbers-mode 0)) |
" . 35527) 34564 (t 26101 62781 624933 957000) nil ("  " . 19308) ("  " . 19333) ("  " . 19374) ("  " . 19421) ("  " . 19517) ("  " . 19547) ("  " . 19647) ("  " . 19680) ("  " . 19772) ("  " . 19824) ("  " . 19849) ("  " . 19875) ("  " . 19893) ("  " . 19935) ("  " . 20007) ("  " . 20060) 19306 nil (19308 . 19310) (19331 . 19333) (19370 . 19372) (19415 . 19416) (19417 . 19418) (19507 . 19508) (19509 . 19510) (19537 . 19538) (19539 . 19540) (19633 . 19635) (19668 . 19670) (19734 . 19758) (19784 . 19785) (19786 . 19787) (19805 . 19806) (19807 . 19808) (19831 . 19832) (19835 . 19836) (19843 . 19845) (19891 . 19893) (19953 . 19954) (19957 . 19958) (20008 . 20010) 19306 (" " . 19733) (19734 . 19735) (19733 . 19734) (" " . -19733) 19734 (t 26101 62595 98280 185000) nil ("dawddw" . 19632) ("  " . 20014) ("  " . 19963) ("  " . 19893) ("  " . 19853) ("  " . 19837) ("  " . 19813) ("  " . 19790) ("  " . 19674) ("  " . 19639) ("  " . 19632) ("  " . 19537) ("  " . 19509) ("  " . 19415) ("  " . 19370) ("  " . 19331) ("  " . 19308) nil (19308 . 19310) (19331 . 19333) (19370 . 19372) (19415 . 19417) (19509 . 19511) (19537 . 19539) (19632 . 19634) (19639 . 19641) (19674 . 19676) (19790 . 19792) (19813 . 19815) (19837 . 19839) (19853 . 19855) (19893 . 19895) (19963 . 19965) (20014 . 20016) 19306 (19632 . 19638) (t 26101 62595 98280 185000) nil ("    " . 19666) (nil ws-butler-chg delete 19672 . 19673) (19670 . 19672) nil ("  " . -19670) (19666 . 19670) 19765 (t 26101 62595 98280 185000) nil (" " . 34559) nil ("1" . 34560) (t 26101 62582 538281 56000) nil (35507 . 35512) (35496 . 36048) ("
" . 35496) (35491 . 35496) (35490 . 35492) 34541 (t 26101 62190 214974 835000) nil (34253 . 34255) (34253 . 34272) (": efs/org-font-setup
" . 34253) 33399 nil (34253 . 34255) (34242 . 34272) ("
" . 34242) (34241 . 34243) 33399 (t 26101 62185 851641 802000) nil (32510 . 34231) ("  (defun efs/org-font-setup ()
    ;; Replace list hyphen with dot
    (font-lock-add-keywords 'org-mode
                            '((\"^ *\\\\([-]\\\\) \"
                               (0 (prog1 () (compose-region (match-beginning 1) (match-end 1) \"•\"))))))

    ;; Set faces for heading levels
    (dolist (face '((org-level-1 . 1.2)
                    (org-level-2 . 1.1)
                    (org-level-3 . 1.05)
                    (org-level-4 . 1.0)
                    (org-level-5 . 1.1)
                    (org-level-6 . 1.1)
                    (org-level-7 . 1.1)
                    (org-level-8 . 1.1)))
      (set-face-attribute (car face) nil :font \"Cantarell\" :weight 'regular :height (cdr face)))

    ;; Ensure that anything that should be fixed-pitch in Org files appears that way
    (set-face-attribute 'org-block nil    :foreground nil :inherit 'fixed-pitch)
    (set-face-attribute 'org-block nil    :foreground 'unspecified :inherit 'fixed-pitch)
    (set-face-attribute 'org-table nil    :inherit 'fixed-pitch)
    (set-face-attribute 'org-formula nil  :inherit 'fixed-pitch)
    (set-face-attribute 'org-code nil     :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-table nil    :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-verbatim nil :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-special-keyword nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-meta-line nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-checkbox nil  :inherit 'fixed-pitch)
    (set-face-attribute 'line-number nil :inherit 'fixed-pitch)
    (set-face-attribute 'line-number-current-line nil :inherit 'fixed-pitch))
" . 32510) 33398 (t 26101 62169 828309 574000) nil (32510 . 34228) ("  (defun efs/org-font-setup ()
    ;; Replace list hyphen with dot
    (font-lock-add-keywords 'org-mode
                            '((\"^ *\\\\([-]\\\\) \"
                               (0 (prog1 () (compose-region (match-beginning 1) (match-end 1) \"•\"))))))

    ;; Set faces for heading levels
    (dolist (face '((org-level-1 . 1.2)
                    (org-level-2 . 1.1)
                    (org-level-3 . 1.05)
                    (org-level-4 . 1.0)
                    (org-level-5 . 1.1)
                    (org-level-6 . 1.1)
                    (org-level-7 . 1.1)
                    (org-level-8 . 1.1)))
      (set-face-attribute (car face) nil :font \"Cantarell\" :weight 'regular :height (cdr face)))

    ;; Ensure that anything that should be fixed-pitch in Org files appears that way
    ;;(set-face-attribute 'org-block nil    :foreground nil :inherit 'fixed-pitch)
    (set-face-attribute 'org-block nil    :foreground 'unspecified :inherit 'fixed-pitch)
    (set-face-attribute 'org-table nil    :inherit 'fixed-pitch)
    (set-face-attribute 'org-formula nil  :inherit 'fixed-pitch)
    (set-face-attribute 'org-code nil     :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-table nil    :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-verbatim nil :inherit '(shadow fixed-pitch))
    (set-face-attribute 'org-special-keyword nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-meta-line nil :inherit '(font-lock-comment-face fixed-pitch))
    (set-face-attribute 'org-checkbox nil  :inherit 'fixed-pitch)
    (set-face-attribute 'line-number nil :inherit 'fixed-pitch)
    (set-face-attribute 'line-number-current-line nil :inherit 'fixed-pitch))
" . 32510) 33315 (t 26101 62148 104977 740000) nil (44381 . 44382) (44370 . 44922) ("
" . 44370) (44369 . 44370) (44368 . 44370) 44205 nil (43430 . 43486) ("| lambda | nil | (interactive) | (org-capture nil jj) |
" . 43430) 41953 (t 26101 61396 901696 265000) nil (3865 . 3867) (3865 . 3972) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3865) 2769 (t 26101 61394 485029 767000) nil (2686 . 3843) ("  ;; Default for fill column should be 80 (not 70 like emacs would have it!!!)
  (setq-default fill-column 80)

  (setq frame-resize-pixelwise t
        frame-inhibit-implied-resize t
        frame-title-format '(\"%b\")
        ring-bell-function 'ignore
        use-dialog-box t ; only for mouse events, which I seldom use
        use-file-dialog nil
        use-short-answers t
        inhibit-splash-screen t
        inhibit-startup-screen t
        inhibit-startup-message t
        initial-scratch-message nil
        inhibit-x-resources t
        inhibit-startup-echo-area-message user-login-name ; read the docstring
        inhibit-startup-buffer-menu t)

  (set-fringe-mode 10) ; Give some breathing room

  (menu-bar-mode -1)   ; Disable the menu bar

  ;; Disable graphical elements
  (menu-bar-mode -1)
  (scroll-bar-mode -1)
  (tool-bar-mode -1)
  (tooltip-mode -1)

  ;; Set frame transparency
  (set-frame-parameter (selected-frame) 'alpha '(100. 100))
  (add-to-list 'default-frame-alist `(alpha . (100 . 100)))
  (set-frame-parameter (selected-frame) 'fullscreen 'maximized)
  (add-to-list 'default-frame-alist '(fullscreen . maximized))
" . 2686) 2768 (t 26101 61352 385032 668000) nil (3862 . 3864) (3862 . 3969) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3862) 2797 (t 26101 61350 461699 469000) nil (3862 . 3864) (3862 . 3969) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3862) 2797 (t 26101 61347 258366 357000) nil ("  " . -2797) 2799 (2796 . 2799) 2765 nil ("
" . 2686) nil (nil rear-nonsticky nil 2688 . 2689) ("
" . -2797) (2686 . 2798) nil ("  " . -2686) 2688 (2686 . 2688) (2686 . 2687) nil ("
  " . 2718) ("      " . 2721) (nil ws-butler-chg delete 2727 . 2728) (2719 . 2727) nil ("        " . -2719) 2727 (2721 . 2727) 2686 (2718 . 2721) 2686 nil ("  ;; Default for fill column should be 80 (not 70 like emacs would have it!!!)
  (setq-default fill-column 80)
" . 3452) 3559 (t 26101 60945 241727 429000) nil (3861 . 3863) (3861 . 3968) (": ((fullscreen . maximized) (alpha 100 . 100) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3861) 2928 (t 26098 26547 597716 115000) nil (20070 . 20081) ("
" . 20070) (20069 . 20071) 19410 (t 26098 26533 514383 753000) nil (19129 . 19189) ("| lambda | nil | (interactive) | (ns/toggle-transparency) |
" . 19129) 18893 nil (19129 . 19189) ("| lambda | nil | (interactive) | (ns/toggle-transparency) |
" . 19129) 18893 nil (18408 . 18491) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18408) 17471 nil (18408 . 18491) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18408) 17470 (t 26098 26500 334386 43000) nil (3861 . 3863) (3861 . 3968) (": ((alpha 100 . 100) (fullscreen . maximized) (alpha 90 . 90) (left-fringe . 10) (right-fringe . 10) (vertical-scroll-bars))
" . 3861) 3667 (t 26098 26484 894387 107000) nil ("
" . 9208) nil ("*** Test
" . 9209) nil ("daw
" . 9218) 9220 nil (9218 . 9221) (9217 . 9218) (9209 . 9217) (9208 . 9209) (9207 . 9208) (t 26098 25731 824439 62000) 9171 nil (18424 . 18507) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18424) 17655 (t 26098 25722 957773 7000) nil (17644 . 17655) ("afternoon" . 17644) nil ("
" . 17594) nil ("  (use-package afternoon-theme
    :ensure t)
" . 17594) 17639 (t 26098 24500 1190 710000) nil (18469 . 18552) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18469) 17581 (t 26098 24491 584524 623000) nil ("  " . -17640) 17642 ("  " . 17418) ("  " . 17436) ("  " . 17470) ("  " . 17484) ("  " . 17503) ("  " . 17528) ("  " . 17548) (" " . 17565) (" " . 17568) (" " . 17594) (" " . 17599) (" " . 17612) (" " . 17615) ("  " . 17645) ("  " . 17667) ("  " . 17689) ("  " . 17732) (" " . 17765) (" " . 17768) (" " . 17791) (" " . 17794) (" " . 17817) (" " . 17820) (" " . 17852) (" " . 17855) (" " . 17905) (" " . 17910) (" " . 17958) (" " . 17963) (" " . 17978) (" " . 17983) ("  " . 18035) ("  " . 18106) ("  " . 18138) ("  " . 18193) (" " . 18218) (" " . 18227) (" " . 18259) (" " . 18262) (" " . 18349) (" " . 18352) ("  " . 18414) 17416 (17661 . 17664) (t 26098 24486 544524 970000) 17660 nil (17638 . 17644) (t 26098 24471 147859 366000) nil (17635 . 17636) ("n" . 17635) (t 26098 24464 617859 817000) nil (17645 . 17654) (17418 . 17420) (17434 . 17436) (17466 . 17468) (17478 . 17480) (17495 . 17497) (17518 . 17520) (17536 . 17538) (17551 . 17553) (17582 . 17584) (17594 . 17596) (17619 . 17625) (17621 . 17623) (17645 . 17647) (17682 . 17683) (17684 . 17685) (17715 . 17716) (17717 . 17718) (17739 . 17740) (17741 . 17742) (17763 . 17764) (17765 . 17766) (17796 . 17797) (17798 . 17799) (17847 . 17848) (17851 . 17852) (17898 . 17899) (17902 . 17903) (17916 . 17917) (17920 . 17921) (17971 . 17972) (17977 . 17978) (18034 . 18035) (18040 . 18041) (18070 . 18071) (18076 . 18077) (18113 . 18114) (18123 . 18124) (18146 . 18147) (18154 . 18155) (18185 . 18186) (18187 . 18188) (18273 . 18274) (18275 . 18276) (18336 . 18338) 17416 (17618 . 17619) (17603 . 17618) ("k" . -17603) ("c" . -17604) 17605 (17597 . 17605) (17596 . 17598) ("(" . -17596) (17596 . 17597) ("  " . 17418) ("  " . 17436) ("  " . 17470) (" " . 17484) (" " . 17487) (" " . 17501) (" " . 17504) (" " . 17528) (" " . 17533) ("  " . 17546) ("  " . 17567) ("  " . 17594) ("  " . 17617) (" " . 17639) (" " . 17642) ("  " . 17680) ("  " . 17717) (" " . 17741) (" " . 17744) (" " . 17767) (" " . 17770) (" " . 17802) (" " . 17805) ("  " . 17855) ("  " . 17912) ("  " . 17928) ("  " . 17991) (" " . 18050) (" " . 18057) (" " . 18088) (" " . 18095) (" " . 18133) (" " . 18144) ("  " . 18168) ("  " . 18211) (" " . 18299) (" " . 18302) ("  " . 18364) 17416 (17611 . 17614) (t 26098 24411 311196 827000) 17611 nil (18476 . 18559) ("| lambda | nil | (interactive) | (ns/toggle-theme ns/default-theme ns/alt-theme) |
" . 18476) 17674 (t 26098 24407 757863 739000) nil (17666 . 17675) nil ("badger" . 17666) nil ("-" . 17666) nil ("doom" . 17666) (t 26098 24249 714541 308000)) (emacs-undo-equiv-table))