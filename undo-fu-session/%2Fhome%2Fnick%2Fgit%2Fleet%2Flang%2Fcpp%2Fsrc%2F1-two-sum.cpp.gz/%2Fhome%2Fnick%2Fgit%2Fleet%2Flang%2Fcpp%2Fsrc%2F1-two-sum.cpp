((buffer-size . 660) (buffer-checksum . "87273b095574df172b6bd8bfc5a25ca7f2aacc3d"))
((emacs-buffer-undo-list nil ("#inc
" . 24) ((marker* . 24) . 1) ((marker . 24) . -3) ((marker . 24) . -4) 27 nil (24 . 28) (t 26051 58163 843897 196000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))