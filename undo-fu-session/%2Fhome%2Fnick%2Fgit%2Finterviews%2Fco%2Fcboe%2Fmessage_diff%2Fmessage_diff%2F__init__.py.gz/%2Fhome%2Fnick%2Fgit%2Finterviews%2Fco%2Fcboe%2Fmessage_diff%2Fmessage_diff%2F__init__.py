((buffer-size . 3545) (buffer-checksum . "31fbfc300c54c4ccb95084736a92e1c564167cf1"))
((emacs-buffer-undo-list nil (97 . 100) (84 . 97) (" " . -84) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) 85 nil ("line" . 85) ((marker . 84) . -3) ((marker* . 100) . 4) ((marker*) . 4) ((marker) . -4) nil ("-" . 85) ((marker* . 100) . 1) ((marker*) . 1) ((marker) . -1) nil ("by" . 85) ((marker . 84) . -1) ((marker* . 100) . 2) ((marker*) . 2) ((marker) . -2) nil ("-" . 85) ((marker* . 100) . 1) ((marker*) . 1) ((marker) . -1) nil ("line" . 85) ((marker . 84) . -3) ((marker* . 100) . 4) ((marker*) . 4) ((marker) . -4) (t 26087 46256 682728 567000) nil (76 . 85) nil ("dictionaries " . 76) ((marker . 84) . -12) ((marker) . -13) nil ("message " . 76) ((marker . 84) . -7) ((marker) . -8) (t 26087 46141 829388 212000) nil (122 . 134) (112 . 122) (111 . 112) (t 26087 46128 292720 718000) nil ("Assumptions:
- Messages may have any number of fields.
- The inbound data does not necessarily conform to any one python data
  structure.
- Each key-value pair consists of exactly one key and exactly one value
  (1 to 1), both of type string. All other datatypes will be serialized as
  strings.
  - None => \"None\"
  - []   => \"[]\"
  - \"\"   => \"\" # Identity function, use escape chars to represent a string.
- Aside from the above, inbound messages are unstructured, which means
  collisions may occur (duplicate keys in the same message)

Constraints:
- Although this implementation tries to generalize with how the data is
  interpreted, one constraint had to be added.
- The input can be a dictionary or nested sequence of pairs, but the pairs may
  not be greater than 2 (one key and one value).

Design Choices:
- I'll be following the Google Python Style Guide in order to keep the code
  clean and consistent.
- Pytest for my testing framework for its compatibility with unittest and
  automatic test discovery.
- I'll be making use of python's typing module to allow for static analysis
  tools, to improve readability, and to facilitate easier code maintenance.
- Flake8 for static analysis.
- This was coded using Python 3.11.7, but should be compatible with
  versions >= 3.11.

Further Considerations:
- The inputs and outputs should be fairly generic in order to easily allow for
future extensions. Some useful enhancements could include one or more of the
following:
    - Python Module: The assumed case. I/O as in-memory python data structures.
    - CLI: utilize command-line arguments for redirection of data.
    - Files: Read and write to some sort of data file (e.g. json).
    - DB: Manipulating queries from some sort of python ORM (e.g. sqlite3).
    - Pretty-printing: Output as a unified or split diff with proper
      colorization.
    - Any combination of the above.
" . 112) ((marker . 3523) . -1862) ((marker . 84) . -1896) ((marker . 126) . -1) ((marker . 126) . -1862) ((marker* . 100) . 1241) ((marker . 126) . -13) ((marker . 126) . -55) ((marker . 126) . -1897) ((marker . 126) . -1021) ((marker . 126) . -1025) ((marker . 126) . -1025) ((marker . 126) . -801) ((marker . 126) . -1290) ((marker . 126) . -1290) ((marker . 126) . -801) ((marker . 1) . -13) ((marker . 126) . -1861) ((marker . 99) . -1862) 1974 (t 26087 45398 976009 470000) nil (" " . 753) nil ("a" . 753) nil ("on " . -770) ((marker . 99) . -2) ((marker . 99) . -3) 773 ("the " . -773) ((marker . 99) . -4) 777 (772 . 777) (771 . 772) (770 . 771) nil (769 . 770) ("s" . -769) ((marker . 99) . -1) (" " . -770) ((marker . 99) . -1) 771 nil (756 . 759) (755 . 756) nil ("couple " . 755) ((marker . 84) . -6) (t 26087 45339 826005 856000) nil (1110 . 1112) (" " . 1109) ((marker . 99) . -1) (1110 . 1111) nil (" " . 1096) ("
" . 1096) (t 26087 45310 902670 753000) nil (917 . 918) nil (911 . 916) (908 . 911) (899 . 908) (896 . 899) (895 . 896) (894 . 896) ("(" . -894) (879 . 895) (878 . 879) (876 . 878) (873 . 876) (870 . 873) (869 . 870) (" " . -869) ((marker . 99) . -1) ("n" . -870) ((marker . 99) . -1) ("o" . -871) ((marker . 99) . -1) 872 (866 . 872) ("m" . -866) ((marker . 99) . -1) ("u" . -867) ((marker . 99) . -1) ("s" . -868) ((marker . 99) . -1) ("t" . -869) ((marker . 99) . -1) ("
" . -870) ((marker . 99) . -1) (" " . -871) ((marker . 99) . -1) (" " . -872) ((marker . 99) . -1) (" " . -873) ((marker . 99) . -1) 874 (871 . 874) ("-" . -871) ((marker . 99) . -1) (" " . -872) ((marker . 99) . -1) 873 (872 . 873) (t 26087 45284 609335 811000) nil (" " . 872) nil ("
" . 251) ((marker* . 100) . 1) nil (250 . 251) 239 nil (871 . 873) (870 . 871) (860 . 870) (848 . 860) (841 . 848) ("," . -841) ((marker . 99) . -1) (" " . -842) ((marker . 99) . -1) 843 ("but " . -843) ((marker . 99) . -4) 847 ("the " . -847) ((marker . 99) . -4) 851 (846 . 851) ("n" . -846) ((marker . 99) . -1) (" " . -847) ((marker . 99) . -1) 848 (841 . 848) (826 . 841) ("l" . -826) ((marker . 99) . -1) (" " . -827) ((marker . 99) . -1) 828 (810 . 828) (794 . 810) ("H" . -794) ((marker . 99) . -1) ("e" . -795) ((marker . 99) . -1) (" " . -796) ((marker . 99) . -1) 797 (791 . 797) (790 . 791) (t 26087 45110 875991 859000) 789 nil (789 . 790) (776 . 789) (755 . 776) (751 . 755) (t 26087 45103 572658 79000) nil (738 . 740) (" " . 737) ((marker . 99) . -1) (738 . 739) nil (747 . 749) (743 . 747) ("p" . -743) ((marker . 99) . -1) ("r" . -744) ((marker . 99) . -1) 745 (738 . 745) (717 . 738) (699 . 717) ("y" . -699) ((marker . 99) . -1) 700 (691 . 700) (670 . 691) ("r" . -670) ((marker . 99) . -1) 671 (669 . 671) ("L" . -669) ((marker . 99) . -1) 670 (668 . 670) (666 . 668) (665 . 666) (t 26087 45073 725989 589000) 654 nil ("- This implementation generalizes
" . 1155) ((marker . 3523) . -32) ((marker . 84) . -33) ((marker . 126) . -32) ((marker . 99) . -32) ((marker . 99) . -12) 1167 nil (664 . 665) (658 . 664) ("a" . -658) ((marker . 99) . -1) ("r" . -659) ((marker . 99) . -1) 660 (653 . 660) (652 . 653) (651 . 652) 593 nil ("
" . 112) ((marker* . 100) . 1) nil (111 . 112) (t 26087 45056 919321 893000) nil (1173 . 1174) ("d" . -1173) ((marker . 99) . -1) 1174 (1162 . 1174) (1141 . 1162) (1140 . 1141) (t 26087 45021 539319 730000) 1124 nil ("- Assume that the inputs comes from an external,
  in-memory python program.
" . 652) ((marker . 3523) . -55) ((marker . 84) . -76) ((marker . 126) . -6) ((marker . 126) . -55) ((marker . 99) . -5) ((marker . 99) . -55) 707 (t 26087 45012 925985 868000) nil (" " . 654) nil ("[TODO: ask about this.]" . 654) ((marker . 84) . -22) ((marker . 99) . -2) 656 (t 26087 44860 922643 248000) nil ("l" . 2750) nil ("k" . -2751) ((marker . 99) . -1) ("j" . -2752) ((marker . 99) . -1) 2753 (2750 . 2753) (2736 . 2750) ("s" . -2736) (2736 . 2737) ("serialized_msg" . -2736) ((marker . 99) . -14) (2736 . 2750) ("seria" . -2736) ((marker . 99) . -5) ((marker . 99) . -5) 2741 (2736 . 2741) ("result" . 2736) ((marker . 3523) . -3) ((marker . 84) . -5) ((marker . 126) . -3) nil (2672 . 2686) ("i" . -2672) ((marker . 99) . -1) ((marker . 99) . -1) 2673 (2672 . 2673) ("result" . 2672) ((marker . 84) . -5) nil (2531 . 2545) ("result" . 2531) ((marker . 84) . -5) (t 26087 44811 769306 909000) nil ("s" . 2651) (t 26087 44806 989306 617000) nil (2627 . 2629) (" " . -2627) ((marker . 99) . -1) 2628 (t 26087 44789 412638 876000) nil ("    # return [(str(pair[0]), str(pair[1])) for pair in msg]
" . 2527) ((marker . 84) . -59) ((marker . 126) . -60) ((marker . 99) . -14) 2541 (t 26087 44669 492631 547000) nil (2648 . 2649) ("1" . 2648) (t 26087 44657 839297 500000) nil (2648 . 2649) ("2" . 2648) (t 26087 44643 722629 968000) nil (2703 . 2704) nil (2700 . 2702) (2698 . 2700) (2697 . 2699) ("{" . -2697) (2697 . 2698) (t 26087 44624 565962 130000) nil (2680 . 2681) (t 26087 44614 325961 503000) nil ("        print(pair)
" . 2625) ((marker . 84) . -19) ((marker* . 100) . 2) ((marker . 850) . -14) ((marker . 99) . -1) 2626 (t 26087 44494 115954 154000) nil (2724 . 2725) ("1" . 2724) (t 26087 44401 925948 519000) nil ("]" . 2643) ((marker* . 100) . 1) nil ("1" . 2643) nil ("[" . 2643) (t 26087 44399 372615 29000) nil (2671 . 2672) ("3" . 2671) (t 26087 44397 105948 223000) nil ("]" . 2667) nil ("1" . 2667) nil ("[" . 2667) (t 26087 44367 965946 444000) nil (2644 . 2645) (2643 . 2645) ("[" . -2643) (2639 . 2644) (2638 . 2640) ("(" . -2638) (2634 . 2639) (2633 . 2634) (2624 . 2633) (t 26087 44353 612612 235000) 2623 nil (2651 . 2652) ("2" . 2651) (t 26087 44338 899278 3000) nil (2651 . 2652) ("1" . 2651) (t 26087 44334 455944 398000) nil ("f" . 2683) nil (":" . -2709) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) (" " . -2710) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) 2711 nil ("}" . 2711) nil ("]" . 2711) nil ("1" . 2711) nil ("[" . 2711) nil ("pair" . 2711) ((marker . 84) . -3) nil ("{" . 2711) (t 26087 44321 125943 581000) nil (2647 . 2648) nil (")" . 2640) ((marker* . 100) . 1) nil (2639 . 2641) ("(" . -2639) (2636 . 2640) (t 26087 44301 329275 704000) nil (")" . 2643) nil ("(" . 2636) (t 26087 44291 749275 117000) nil ("
" . 2587) nil (2792 . 2793) (t 26087 44283 775941 297000) 2792 nil (apply -2 2527 2587 undo--wrap-and-run-primitive-undo 2527 2587 ((2531 . 2533))) nil (nil rear-nonsticky nil 2589 . 2590) ("
" . -2789) (2585 . 2790) nil ("    result = []

    for pair in msg:
        if (pair[1]) > 1:
            raise ValueError(f\"Value in tuple exceeds 1: {pair[1]}\")
        result.append((str(pair[0]), str(pair[1])))

    return result
" . 3197) ((marker . 3523) . -200) ((marker . 84) . -203) ((marker . 126) . -14) ((marker . 126) . -200) ((marker* . 100) . 155) ((marker . 99) . -49) ((marker . 99) . -200) 3397 nil (apply 2 3131 3196 undo--wrap-and-run-primitive-undo 3131 3196 (("# " . -3135) 3150)) nil ("len" . 3248) ((marker . 99) . -2) (t 26087 44240 299271 971000) nil (3248 . 3251) nil (3256 . 3257) nil (")" . 3249) ((marker* . 100) . 1) nil (3248 . 3250) ("(" . -3248) (3248 . 3249) (t 26087 44207 462603 298000) nil (" " . -3203) (3199 . 3203) 3210 nil (apply -2 3131 3199 undo--wrap-and-run-primitive-undo 3131 3199 ((3135 . 3137) 3147)) nil (nil rear-nonsticky nil 3394 . 3395) (nil fontified nil 3197 . 3395) (3197 . 3395) nil (3196 . 3197) (t 26087 44178 512601 530000) 3160 nil ("            if len(value) > 2:
                raise IndexError(\"Nested tuples may only have one key and one \"
                                 \"value.\")
" . 3690) ((marker . 3523) . -135) ((marker . 84) . -153) ((marker . 126) . -24) ((marker . 126) . -135) ((marker* . 100) . 130) ((marker . 2133) . -31) ((marker . 2133) . -31) ((marker . 99) . -29) ((marker . 99) . -135) 3825 (t 26087 44118 432597 860000) nil (3718 . 3719) ("1" . 3718) (t 26087 44106 952597 157000) nil (" " . -2567) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) ("i" . -2568) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) ("f" . -2569) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) (" " . -2570) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) ("l" . -2571) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) ("e" . -2572) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) ("n" . -2573) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ((marker . 99) . -1) ("(" . -2574) ((marker . 84) . -1) ((marker . 84) . -1) ((marker . 99) . -1) ("p" . -2575) ((marker* . 100) . 1) ((marker . 99) . -1) ("a" . -2576) ((marker . 99) . -1) ("i" . -2577) ((marker . 99) . -1) ("r" . -2578) ((marker . 99) . -1) ("[" . -2579) ((marker . 99) . -1) ("1" . -2580) ((marker . 99) . -1) ("]" . -2581) ((marker . 99) . -1) (")" . -2582) ((marker . 99) . -1) (" " . -2583) ((marker . 99) . -1) ("<" . -2584) ((marker . 99) . -1) 2585 (2582 . 2585)) (emacs-pending-undo-list) (emacs-undo-equiv-table (80 . 82)))