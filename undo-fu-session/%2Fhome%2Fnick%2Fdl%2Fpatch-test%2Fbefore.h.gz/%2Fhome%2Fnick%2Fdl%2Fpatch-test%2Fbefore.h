((buffer-size . 205) (buffer-checksum . "5baec7ee5c1d3c53cad3fe8af87c248351a8d129"))
((emacs-buffer-undo-list nil ("  /** static bool m_loggingEnabled; */

  /** static void enableDebugLogging(); */
  /** static void disableDebugLogging(); */
" . 145) ((marker . 145) . -84) ((marker . 145) . -1) ((marker . 145) . -84) ((marker . 145) . -84) ((marker . 206) . -126) 229 (t 26070 29574 535913 392000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))