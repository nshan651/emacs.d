((buffer-size . 876) (buffer-checksum . "75d29a54a07794a4661847f9a5b2e70a4e3c5681"))
((emacs-buffer-undo-list nil ("
Debug" . 877) ((marker . 877) . -1) ((marker . 877) . -5) ((marker . 877) . -5) ((marker . 877) . -5) 882 nil (880 . 883) ("d" . -880) ((marker . 877) . -1) ("b" . -881) ((marker . 877) . -1) 882 (878 . 882) (877 . 878) nil ("
DebugLogging" . 877) ((marker . 877) . -3) ((marker . 877) . -12) ((marker . 877) . -1) ((marker . 877) . -12) 889 nil (":" . -890) ((marker . 877) . -1) 891 (890 . 891) nil (881 . 890) (878 . 881) (877 . 878) (t 26070 29908 15914 721000) 877 nil (876 . 877) nil ("
" . 876) (t 26070 29765 462580 813000) nil (699 . 700) ("s" . 699) nil (699 . 700) ("s" . 699) (t 26070 29765 462580 813000) nil (876 . 877) nil ("
" . -876) 877 nil ("
" . 877) nil ("/**
void DebugLogging::enableDebugLogging()
{
  m_loggingEnabled = true;
}
*/

/**
void DebugLogging::disableDebugLogging()
{
  m_loggingEnabled = false;
}
*/
" . 878) 1034 nil ("  /** } */
" . 875) 877 nil ("  /** if (m_loggingenabled) */
  /** { */
" . 805) 836 nil ("/** bool Debuglogging::m_loggingEnabled = false;*/
" . 583) nil ("  /** } */
" . 821) nil ("  /** if (m_loggingenabled) */
  /** { */
" . 748) 779 nil (apply -14 748 789 undo--wrap-and-run-primitive-undo 748 789 ((750 . 754) (771 . 774) (774 . 778) (775 . 778) 778)) nil (nil ws-butler-chg delete 778 . 779) (776 . 778) ("    " . 776) nil (nil ws-butler-chg delete 808 . 809) (806 . 808) ("    " . 806) nil (nil ws-butler-chg delete 841 . 842) (839 . 841) ("    " . 839) nil (839 . 843) ("  " . 839) 845 nil (806 . 810) ("  " . 806) 810 nil (776 . 780) ("  " . -776) 778 nil (apply 14 748 775 undo--wrap-and-run-primitive-undo 748 775 ((" */" . 775) ((marker) . -3) ("/** " . -774) (" */" . 771) ("/** " . -750) 790)) nil (apply 7 484 522 undo--wrap-and-run-primitive-undo 484 522 ((" */" . 522) ((marker) . -3) ("/** " . -486) 484)) nil ("  /** Debuglogging::enableDebugLogging(); */
" . 103) 104 (t 26070 29380 349245 958000)) (emacs-pending-undo-list ("
" . -876) ((marker . 876) . -1) ((marker . 876) . -1) ((marker . 3) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 876) . -1) ((marker . 875) . -1) 877 nil ("
" . 877) ((marker . 3) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 876) . -1) nil ("/**
void DebugLogging::enableDebugLogging()
{
  m_loggingEnabled = true;
}
*/

/**
void DebugLogging::disableDebugLogging()
{
  m_loggingEnabled = false;
}
*/
" . 878) ((marker . 876) . -158) ((marker . 3) . -156) ((marker . 699) . -156) ((marker . 875) . -156) 1034 nil ("  /** } */
" . 875) ((marker . 876) . -10) ((marker . 875) . -2) 877 nil ("  /** if (m_loggingenabled) */
  /** { */
" . 805) ((marker . 876) . -41) ((marker . 3) . -31) ((marker . 699) . -31) ((marker . 875) . -31) 836 nil ("/** bool Debuglogging::m_loggingEnabled = false;*/
" . 583) ((marker . 876) . -50) nil ("  /** } */
" . 821) ((marker . 876) . -10) nil ("  /** if (m_loggingenabled) */
  /** { */
" . 748) ((marker . 876) . -41) ((marker . 3) . -31) ((marker . 699) . -31) ((marker . 875) . -31) 779 nil (apply -14 748 789 undo--wrap-and-run-primitive-undo 748 789 ((750 . 754) (771 . 774) (774 . 778) (775 . 778) 778)) nil (nil ws-butler-chg delete 778 . 779) (776 . 778) ("    " . 776) nil (nil ws-butler-chg delete 808 . 809) (806 . 808) ("    " . 806) nil (nil ws-butler-chg delete 841 . 842) (839 . 841) ("    " . 839) nil (839 . 843) ("  " . 839) 845 nil (806 . 810) ("  " . 806) 810 nil (776 . 780) ("  " . -776) ((marker* . 700) . 2) ((marker . 875) . -2) 778 nil (apply 14 748 775 undo--wrap-and-run-primitive-undo 748 775 ((" */" . 775) ((marker) . -3) ("/** " . -774) (" */" . 771) ("/** " . -750) 790)) nil (apply 7 484 522 undo--wrap-and-run-primitive-undo 484 522 ((" */" . 522) ((marker) . -3) ("/** " . -486) 484)) nil ("  /** Debuglogging::enableDebugLogging(); */
" . 103) ((marker . 875) . -1) ((marker . 876) . -44) 104 (t 26070 29380 349245 958000)) (emacs-undo-equiv-table (-9 . -17) (8 . 10) (-11 . -15) (-10 . -16) (-12 . -14) (7 . -1)))