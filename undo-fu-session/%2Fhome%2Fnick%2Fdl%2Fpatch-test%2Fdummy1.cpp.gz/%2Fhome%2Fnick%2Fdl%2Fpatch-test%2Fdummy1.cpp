((buffer-size . 937) (buffer-checksum . "1f644c74f1aff28da05f95730db96da1c0f03902"))
((emacs-buffer-undo-list nil (380 . 381) (367 . 380) ("x" . -367) ((marker . 380) . -1) ((marker . 380) . -1) 368 (367 . 368) (364 . 367) (363 . 364) (353 . 363) (350 . 353) (349 . 350) (340 . 349) (338 . 340) ("  " . 338) nil (324 . 325) nil (nil rear-nonsticky nil 323 . 324) ("
" . -341) (324 . 342) (nil face (rainbow-delimiters-depth-1-face) 323 . 324) (nil fontified t 323 . 324) (323 . 324) 322 nil ("Foo::Bar()
{
  
}
" . 44) ((marker* . 381) . 3) ((marker . 44) . -17) ((marker . 44) . -1) ((marker . 44) . -17) ((marker . 380) . -15) ((marker . 380) . -17) ((marker . 383) . -17) 61 nil ("F" . -59) ((marker . 380) . -1) ((marker . 380) . -1) 60 (59 . 60) (57 . 59) (56 . 58) (55 . 57) ("{" . -55) (55 . 56) (54 . 55) (")" . 54) (53 . 54) (53 . 54) (nil fontified nil 52 . 53) (nil ws-butler-chg chg 52 . 53) (52 . 53) ("(" . -52) (52 . 53) (":" . -52) ((marker . 380) . -1) (":" . -53) ((marker . 380) . -1) ("b" . -54) ((marker . 380) . -1) ("a" . -55) ((marker . 380) . -1) ("z" . -56) ((marker . 380) . -1) 57 (54 . 57) (52 . 54) (49 . 52) (47 . 49) (44 . 47) (43 . 44) (42 . 43) (t 26070 30287 732582 909000) 23) (emacs-pending-undo-list ("
" . -876) ((marker . 877) . -1) ((marker . 877) . -1) ((marker . 8) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 876) . -1) ((marker . 380) . -1) 877 nil ("
" . 877) ((marker . 8) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 699) . -1) ((marker . 876) . -1) nil ("/**
void DebugLogging::enableDebugLogging()
{
  m_loggingEnabled = true;
}
*/

/**
void DebugLogging::disableDebugLogging()
{
  m_loggingEnabled = false;
}
*/
" . 878) ((marker . 877) . -158) ((marker . 8) . -156) ((marker . 699) . -156) ((marker . 380) . -156) 1034 nil ("  /** } */
" . 875) ((marker . 877) . -10) ((marker . 380) . -2) 877 nil ("  /** if (m_loggingenabled) */
  /** { */
" . 805) ((marker . 877) . -41) ((marker . 8) . -31) ((marker . 699) . -31) ((marker . 380) . -31) 836 nil ("/** bool Debuglogging::m_loggingEnabled = false;*/
" . 583) ((marker . 877) . -50) nil ("  /** } */
" . 821) ((marker . 877) . -10) nil ("  /** if (m_loggingenabled) */
  /** { */
" . 748) ((marker . 877) . -41) ((marker . 8) . -31) ((marker . 699) . -31) ((marker . 380) . -31) 779 nil (apply -14 748 789 undo--wrap-and-run-primitive-undo 748 789 ((750 . 754) (771 . 774) (774 . 778) (775 . 778) 778)) nil (nil ws-butler-chg delete 778 . 779) (776 . 778) ("    " . 776) nil (nil ws-butler-chg delete 808 . 809) (806 . 808) ("    " . 806) nil (nil ws-butler-chg delete 841 . 842) (839 . 841) ("    " . 839) nil (839 . 843) ("  " . 839) 845 nil (806 . 810) ("  " . 806) 810 nil (776 . 780) ("  " . -776) ((marker* . 700) . 2) ((marker . 380) . -2) 778 nil (apply 14 748 775 undo--wrap-and-run-primitive-undo 748 775 ((" */" . 775) ((marker) . -3) ("/** " . -774) (" */" . 771) ("/** " . -750) 790)) nil (apply 7 484 522 undo--wrap-and-run-primitive-undo 484 522 ((" */" . 522) ((marker) . -3) ("/** " . -486) 484)) nil ("  /** Debuglogging::enableDebugLogging(); */
" . 103) ((marker . 380) . -1) ((marker . 877) . -44) 104 (t 26070 29380 349245 958000)) (emacs-undo-equiv-table (-12 . -14) (-10 . -16) (-11 . -15) (-9 . -17)))